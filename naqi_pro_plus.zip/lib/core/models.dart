enum Platform { youtube, tiktok, instagram, facebook, unknown }

Platform detectPlatform(String url) {
  final u = url.toLowerCase();
  if (u.contains('youtube.com') || u.contains('youtu.be')) return Platform.youtube;
  if (u.contains('tiktok.com')) return Platform.tiktok;
  if (u.contains('instagram.com')) return Platform.instagram;
  if (u.contains('facebook.com') || u.contains('fb.watch')) return Platform.facebook;
  return Platform.unknown;
}

String platformName(Platform p) => switch (p) {
      Platform.youtube => 'YouTube',
      Platform.tiktok => 'TikTok',
      Platform.instagram => 'Instagram',
      Platform.facebook => 'Facebook',
      Platform.unknown => 'Unknown',
    };

class MediaOption {
  final String id;
  final String label; // e.g. "720p" or "AAC 128kbps"
  final bool audioOnly;
  final String container; // mp4 / m4a / webm
  final int? sizeBytes;
  final String url;
  const MediaOption({
    required this.id,
    required this.label,
    required this.audioOnly,
    required this.container,
    required this.url,
    this.sizeBytes,
  });
}

class MediaInfo {
  final String sourceUrl;
  final Platform platform;
  final String title;
  final String? author;
  final String? thumbnail;
  final Duration? duration;
  final List<MediaOption> options;
  const MediaInfo({
    required this.sourceUrl,
    required this.platform,
    required this.title,
    required this.options,
    this.author,
    this.thumbnail,
    this.duration,
  });
}

enum TaskState { queued, running, paused, done, failed, cancelled }

class DownloadTask {
  final String id;
  final MediaInfo info;
  final MediaOption option;
  final TaskState state;
  final int received;
  final int? total;
  final String? filePath;
  final String? error;
  const DownloadTask({
    required this.id,
    required this.info,
    required this.option,
    this.state = TaskState.queued,
    this.received = 0,
    this.total,
    this.filePath,
    this.error,
  });

  double? get progress =>
      (total == null || total == 0) ? null : (received / total!).clamp(0, 1).toDouble();

  DownloadTask copyWith({
    TaskState? state,
    int? received,
    int? total,
    String? filePath,
    String? error,
  }) =>
      DownloadTask(
        id: id,
        info: info,
        option: option,
        state: state ?? this.state,
        received: received ?? this.received,
        total: total ?? this.total,
        filePath: filePath ?? this.filePath,
        error: error ?? this.error,
      );
}

String fmtBytes(int? b) {
  if (b == null) return '—';
  const u = ['B', 'KB', 'MB', 'GB'];
  var v = b.toDouble();
  var i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return '${v.toStringAsFixed(i == 0 ? 0 : 1)} ${u[i]}';
}

String fmtDuration(Duration? d) {
  if (d == null) return '';
  String two(int n) => n.toString().padLeft(2, '0');
  final h = d.inHours;
  return h > 0 ? '$h:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}' : '${d.inMinutes}:${two(d.inSeconds % 60)}';
}
