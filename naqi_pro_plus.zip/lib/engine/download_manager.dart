import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../core/models.dart';

/// Download manager: queue + parallel limit + pause/resume (HTTP Range) + cancel.
/// Files are saved under <app external dir>/Naqi/<Platform>/ (needs no permission).
class DownloadManager extends StateNotifier<List<DownloadTask>> {
  DownloadManager({this.maxParallel = 2}) : super(const []);

  int maxParallel;
  final _dio = Dio();
  final _cancel = <String, CancelToken>{};
  final _pausing = <String>{};

  Future<void> enqueue(MediaInfo info, MediaOption opt) async {
    final t = DownloadTask(id: DateTime.now().microsecondsSinceEpoch.toString(), info: info, option: opt);
    state = [...state, t];
    _pump();
  }

  void _update(String id, DownloadTask Function(DownloadTask) f) {
    state = [for (final t in state) t.id == id ? f(t) : t];
  }

  void _pump() {
    final running = state.where((t) => t.state == TaskState.running).length;
    var free = maxParallel - running;
    for (final t in state.where((t) => t.state == TaskState.queued)) {
      if (free-- <= 0) break;
      _run(t.id);
    }
  }

  Future<File> _target(DownloadTask t) async {
    final base = (await getExternalStorageDirectory()) ?? await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/Naqi/${platformName(t.info.platform)}');
    await dir.create(recursive: true);
    final safe = t.info.title.replaceAll(RegExp(r'[\\/:*?"<>|\n\r]'), '_');
    final short = safe.length > 80 ? safe.substring(0, 80) : safe;
    return File('${dir.path}/$short.${t.option.container}');
  }

  Future<void> _run(String id) async {
    final t = state.firstWhere((e) => e.id == id);
    _update(id, (e) => e.copyWith(state: TaskState.running));
    final token = CancelToken();
    _cancel[id] = token;
    try {
      final file = await _target(t);
      var start = await file.exists() ? await file.length() : 0;
      if (t.state == TaskState.queued && start > 0 && t.received == 0) {
        await file.delete(); // stale file from older run
        start = 0;
      }
      final res = await _dio.get<ResponseBody>(
        t.option.url,
        cancelToken: token,
        options: Options(
          responseType: ResponseType.stream,
          headers: start > 0 ? {'Range': 'bytes=$start-'} : null,
        ),
      );
      final partial = res.statusCode == 206;
      if (!partial) start = 0;
      final len = int.tryParse(res.headers.value(Headers.contentLengthHeader) ?? '');
      final total = len == null ? t.option.sizeBytes : len + start;
      final sink = file.openSync(mode: partial ? FileMode.append : FileMode.write);
      var got = start;
      try {
        await for (final chunk in res.data!.stream) {
          sink.writeFromSync(chunk);
          got += chunk.length;
          _update(id, (e) => e.copyWith(received: got, total: total));
        }
      } finally {
        sink.closeSync();
      }
      _update(id, (e) => e.copyWith(state: TaskState.done, filePath: file.path, received: got));
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) {
        if (_pausing.remove(id)) {
          _update(id, (x) => x.copyWith(state: TaskState.paused));
        }
      } else {
        _update(id, (x) => x.copyWith(state: TaskState.failed, error: 'Network error'));
      }
    } catch (e) {
      _update(id, (x) => x.copyWith(state: TaskState.failed, error: '$e'));
    } finally {
      _cancel.remove(id);
      _pump();
    }
  }

  void pause(String id) {
    _pausing.add(id);
    _cancel[id]?.cancel('pause');
  }

  void resume(String id) {
    _update(id, (e) => e.copyWith(state: TaskState.queued));
    _pump();
  }

  Future<void> cancel(String id) async {
    final t = state.firstWhere((e) => e.id == id);
    _cancel[id]?.cancel('cancel');
    _update(id, (e) => e.copyWith(state: TaskState.cancelled));
    try {
      final f = await _target(t);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}

final downloadManagerProvider =
    StateNotifierProvider<DownloadManager, List<DownloadTask>>((ref) => DownloadManager());
