import 'package:flutter/services.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart' as yt;
import '../core/models.dart';

class ExtractorException implements Exception {
  final String message;
  ExtractorException(this.message);
  @override
  String toString() => message;
}

/// Core interface: any engine (pure Dart, yt-dlp native, remote) implements this.
abstract class Extractor {
  bool supports(Platform p);
  Future<MediaInfo> analyze(String url);
}

/// YouTube via pure Dart (public streams only; muxed streams max ~720p).
class YoutubeExtractor implements Extractor {
  final _yt = yt.YoutubeExplode();

  @override
  bool supports(Platform p) => p == Platform.youtube;

  @override
  Future<MediaInfo> analyze(String url) async {
    try {
      final v = await _yt.videos.get(url);
      final m = await _yt.videos.streamsClient.getManifest(v.id);
      final opts = <MediaOption>[];
      for (final s in m.muxed.sortByVideoQuality().reversed) {
        opts.add(MediaOption(
          id: 'v${s.tag}',
          label: s.videoQualityLabel,
          audioOnly: false,
          container: s.container.name,
          sizeBytes: s.size.totalBytes,
          url: s.url.toString(),
        ));
      }
      final audio = m.audioOnly.sortByBitrate().reversed.toList();
      for (final a in audio.take(2)) {
        opts.add(MediaOption(
          id: 'a${a.tag}',
          label: '${a.container.name.toUpperCase()} ${a.bitrate.kiloBitsPerSecond.round()}kbps',
          audioOnly: true,
          container: a.container.name == 'mp4' ? 'm4a' : a.container.name,
          sizeBytes: a.size.totalBytes,
          url: a.url.toString(),
        ));
      }
      return MediaInfo(
        sourceUrl: url,
        platform: Platform.youtube,
        title: v.title,
        author: v.author,
        thumbnail: v.thumbnails.highResUrl,
        duration: v.duration,
        options: opts,
      );
    } catch (e) {
      throw ExtractorException('Could not analyze this YouTube link (it may be private or restricted).');
    }
  }
}

/// TikTok / Instagram / Facebook via a native yt-dlp module (Kotlin side,
/// MethodChannel "naqi/ytdlp"). Until that module is installed this reports
/// a clear message instead of crashing. Public content only, no DRM bypass.
class YtDlpChannelExtractor implements Extractor {
  static const _ch = MethodChannel('naqi/ytdlp');

  @override
  bool supports(Platform p) =>
      p == Platform.tiktok || p == Platform.instagram || p == Platform.facebook;

  @override
  Future<MediaInfo> analyze(String url) async {
    try {
      final r = await _ch.invokeMapMethod<String, dynamic>('analyze', {'url': url});
      if (r == null) throw ExtractorException('Empty response from engine.');
      final formats = (r['formats'] as List? ?? []).cast<Map>();
      return MediaInfo(
        sourceUrl: url,
        platform: detectPlatform(url),
        title: (r['title'] ?? 'Untitled') as String,
        author: r['uploader'] as String?,
        thumbnail: r['thumbnail'] as String?,
        duration: r['duration'] == null ? null : Duration(seconds: (r['duration'] as num).round()),
        options: [
          for (final f in formats)
            MediaOption(
              id: '${f['id']}',
              label: '${f['label']}',
              audioOnly: f['audioOnly'] == true,
              container: '${f['ext'] ?? 'mp4'}',
              sizeBytes: (f['size'] as num?)?.toInt(),
              url: '${f['url']}',
            ),
        ],
      );
    } on MissingPluginException {
      throw ExtractorException(
          'The yt-dlp engine is not installed yet (roadmap step 2). YouTube works now.');
    } on PlatformException catch (e) {
      throw ExtractorException(e.message ?? 'Extraction failed.');
    }
  }
}

class ExtractorRegistry {
  final List<Extractor> _all = [YoutubeExtractor(), YtDlpChannelExtractor()];

  Future<MediaInfo> analyze(String url) {
    final p = detectPlatform(url);
    if (p == Platform.unknown) {
      throw ExtractorException('Unsupported link. Use YouTube, TikTok, Instagram or Facebook.');
    }
    return _all.firstWhere((e) => e.supports(p)).analyze(url);
  }
}
