import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../engine/download_manager.dart';
import '../engine/extractor.dart';
import 'glass.dart';

final extractorProvider = Provider((_) => ExtractorRegistry());

final analysisProvider =
    StateNotifierProvider<AnalysisNotifier, AsyncValue<MediaInfo?>>((ref) => AnalysisNotifier(ref));

class AnalysisNotifier extends StateNotifier<AsyncValue<MediaInfo?>> {
  AnalysisNotifier(this.ref) : super(const AsyncData(null));
  final Ref ref;

  Future<void> analyze(String url) async {
    state = const AsyncLoading();
    try {
      state = AsyncData(await ref.read(extractorProvider).analyze(url.trim()));
    } catch (e, s) {
      state = AsyncError(e, s);
    }
  }
}

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> with WidgetsBindingObserver {
  final _ctrl = TextEditingController();
  String? _clipUrl;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkClipboard();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ctrl.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _checkClipboard();
  }

  Future<void> _checkClipboard() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim();
    if (t != null && t.startsWith('http') && detectPlatform(t) != Platform.unknown && t != _ctrl.text) {
      if (mounted) setState(() => _clipUrl = t);
    }
  }

  void _usePasted(String url) {
    HapticFeedback.lightImpact();
    _ctrl.text = url;
    setState(() => _clipUrl = null);
    ref.read(analysisProvider.notifier).analyze(url);
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim();
    if (t != null && t.isNotEmpty) _usePasted(t);
  }

  @override
  Widget build(BuildContext context) {
    final analysis = ref.watch(analysisProvider);
    final tasks = ref.watch(downloadManagerProvider);
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [cs.primaryContainer, cs.surface, cs.tertiaryContainer.withOpacity(0.5)],
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const SizedBox(height: 8),
              Text('نقي Pro Plus', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
              Text('Download Pure... With Professional Quality.', style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 20),
              Glass(
                child: Column(children: [
                  Row(children: [
                    Expanded(
                      child: TextField(
                        controller: _ctrl,
                        keyboardType: TextInputType.url,
                        textInputAction: TextInputAction.go,
                        onSubmitted: (v) => ref.read(analysisProvider.notifier).analyze(v),
                        decoration: const InputDecoration(
                          hintText: 'الصق الرابط هنا — Paste link',
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.link),
                        ),
                      ),
                    ),
                    Semantics(
                      label: 'Paste from clipboard',
                      child: IconButton(
                        constraints: const BoxConstraints(minWidth: 48, minHeight: 48),
                        icon: const Icon(Icons.content_paste_rounded),
                        onPressed: _paste,
                      ),
                    ),
                  ]),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton.icon(
                      onPressed: () => ref.read(analysisProvider.notifier).analyze(_ctrl.text),
                      icon: const Icon(Icons.search),
                      label: const Text('تحليل — Analyze'),
                    ),
                  ),
                ]),
              ),
              if (_clipUrl != null) ...[
                const SizedBox(height: 12),
                Glass(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(children: [
                    Expanded(child: Text('${platformName(detectPlatform(_clipUrl!))} link copied — Paste?')),
                    TextButton(onPressed: () => _usePasted(_clipUrl!), child: const Text('Paste')),
                    IconButton(onPressed: () => setState(() => _clipUrl = null), icon: const Icon(Icons.close)),
                  ]),
                ),
              ],
              const SizedBox(height: 16),
              analysis.when(
                loading: () => const _Skeleton(),
                error: (e, _) => Glass(child: Row(children: [
                  Icon(Icons.info_outline, color: cs.error),
                  const SizedBox(width: 12),
                  Expanded(child: Text('$e')),
                ])),
                data: (info) => info == null ? const SizedBox.shrink() : _InfoCard(info: info),
              ),
              if (tasks.isNotEmpty) ...[
                const SizedBox(height: 24),
                Text('التنزيلات — Downloads', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                for (final t in tasks.reversed) _TaskTile(task: t),
              ],
              const SizedBox(height: 24),
              Text(
                'يحمّل التطبيق الملفات المتاحة للعامة والمسموح بها فقط، ولا يتجاوز DRM أو الحماية أو المحتوى الخاص. '
                'You are responsible for respecting copyright and platform terms.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Skeleton extends StatefulWidget {
  const _Skeleton();
  @override
  State<_Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<_Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context).colorScheme.onSurface;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        Widget bar(double w, double h) => Container(
            width: w, height: h,
            decoration: BoxDecoration(
                color: base.withOpacity(0.06 + 0.08 * _c.value), borderRadius: BorderRadius.circular(8)));
        return Glass(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            bar(double.infinity, 160), const SizedBox(height: 12),
            bar(240, 16), const SizedBox(height: 8), bar(140, 12),
          ]),
        );
      },
    );
  }
}

class _InfoCard extends ConsumerWidget {
  final MediaInfo info;
  const _InfoCard({required this.info});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Glass(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (info.thumbnail != null)
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.network(info.thumbnail!, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const ColoredBox(color: Colors.black12)),
            ),
          ),
        const SizedBox(height: 12),
        Text(info.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 4),
        Text([platformName(info.platform), if (info.author != null) info.author!, fmtDuration(info.duration)]
            .where((s) => s.isNotEmpty).join(' • ')),
        const Divider(height: 24),
        for (final o in info.options)
          ListTile(
            contentPadding: EdgeInsets.zero,
            minVerticalPadding: 12,
            leading: Icon(o.audioOnly ? Icons.music_note_rounded : Icons.videocam_rounded),
            title: Text(o.label),
            subtitle: Text('${o.container.toUpperCase()} • ${fmtBytes(o.sizeBytes)}'),
            trailing: const Icon(Icons.download_rounded),
            onTap: () {
              HapticFeedback.mediumImpact();
              ref.read(downloadManagerProvider.notifier).enqueue(info, o);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أُضيف إلى قائمة التنزيل')));
            },
          ),
      ]),
    );
  }
}

class _TaskTile extends ConsumerWidget {
  final DownloadTask task;
  const _TaskTile({required this.task});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final m = ref.read(downloadManagerProvider.notifier);
    final s = task.state;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Glass(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        child: Row(children: [
          SizedBox(
            width: 44, height: 44,
            child: s == TaskState.done
                ? const Icon(Icons.check_circle, color: Colors.green)
                : CircularProgressIndicator(value: task.progress, strokeWidth: 4),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(task.info.title, maxLines: 1, overflow: TextOverflow.ellipsis),
              Text(
                switch (s) {
                  TaskState.failed => task.error ?? 'Failed',
                  TaskState.done => 'Saved: ${task.filePath}',
                  _ => '${s.name} • ${fmtBytes(task.received)} / ${fmtBytes(task.total)}',
                },
                style: Theme.of(context).textTheme.bodySmall,
                maxLines: 2, overflow: TextOverflow.ellipsis,
              ),
            ]),
          ),
          if (s == TaskState.running)
            IconButton(onPressed: () => m.pause(task.id), icon: const Icon(Icons.pause)),
          if (s == TaskState.paused || s == TaskState.failed)
            IconButton(onPressed: () => m.resume(task.id), icon: const Icon(Icons.play_arrow)),
          if (s != TaskState.done && s != TaskState.cancelled)
            IconButton(onPressed: () => m.cancel(task.id), icon: const Icon(Icons.close)),
        ]),
      ),
    );
  }
}
