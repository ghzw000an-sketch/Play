# Naqi Pro Plus — Roadmap

**Done in this build (MVP-0):** Glass UI, RTL/Dark/Light, smart clipboard prompt, YouTube analysis (pure Dart),
queue + parallel + pause/resume/cancel (HTTP Range), skeleton loading, haptics, legal disclaimer.

1. MVP: Share-target intent (AndroidManifest), foreground-service notification (Pause/Resume/Cancel), MediaStore save to Gallery.
2. yt-dlp engine: Kotlin/Chaquopy module behind MethodChannel `naqi/ytdlp` (analyze/download) for TikTok/Instagram/Facebook, secure auto-update.
3. FFmpeg: mux video+audio (copy, no re-encode) for >720p YouTube DASH, MP3/M4A extraction.
4. Persistence: Drift DB (history), settings, thumbnail dynamic color (palette).
5. Pro Plus: 4K/8K, subtitles/chapters, conversion, playlists, scheduling (WorkManager), vault (biometrics), AI summary, E2E cloud sync, Expert mode.
