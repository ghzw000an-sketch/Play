import 'dart:convert';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class LibraryNotifier extends StateNotifier<List<LibraryItem>> {
  LibraryNotifier(this._p) : super(_load(_p));
  final SharedPreferences _p;
  static const _key = 'library_v1';

  static List<LibraryItem> _load(SharedPreferences p) {
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final l = jsonDecode(raw) as List;
      return [for (final e in l) LibraryItem.fromJson(Map<String, dynamic>.from(e as Map))];
    } catch (_) {
      return [];
    }
  }

  void _save() => _p.setString(_key, jsonEncode([for (final i in state) i.toJson()]));

  void add(LibraryItem i) {
    state = [i, ...state];
    _save();
  }

  void update(LibraryItem i) {
    state = [for (final x in state) x.id == i.id ? i : x];
    _save();
  }

  Future<void> _deleteFiles(LibraryItem i) async {
    for (final p in [i.filePath, i.thumbPath]) {
      if (p == null) continue;
      try {
        final f = File(p);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  Future<void> removeMany(Iterable<String> ids) async {
    final set = ids.toSet();
    for (final i in state.where((x) => set.contains(x.id))) {
      await _deleteFiles(i);
    }
    state = state.where((x) => !set.contains(x.id)).toList();
    _save();
  }

  Future<void> clearAll() async {
    for (final i in state) {
      await _deleteFiles(i);
    }
    state = [];
    _save();
  }

  /// نقل إلى السلة (الملفات تبقى حتى التفريغ).
  void trashMany(Iterable<String> ids) {
    final set = ids.toSet();
    state = [for (final x in state) set.contains(x.id) ? x.copyWith(trashed: true) : x];
    _save();
  }

  void restoreMany(Iterable<String> ids) {
    final set = ids.toSet();
    state = [for (final x in state) set.contains(x.id) ? x.copyWith(trashed: false) : x];
    _save();
  }

  Future<void> emptyTrash() => removeMany(state.where((x) => x.trashed).map((x) => x.id).toList());
}
