import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'design.dart';

/// متصفح خفي: بلا سجل ولا كوكيز محفوظة. زر التحميل يعيد الرابط الحالي للتحليل.
class BrowserPage extends StatefulWidget {
  final String initialUrl;
  const BrowserPage({super.key, required this.initialUrl});
  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> {
  late final WebViewController _c;
  final _addr = TextEditingController();
  int _progress = 0;
  String _url = '';

  @override
  void initState() {
    super.initState();
    _url = widget.initialUrl;
    _addr.text = _url;
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (p) => setState(() => _progress = p),
        onUrlChange: (c) {
          if (c.url != null && mounted) {
            setState(() => _url = c.url!);
            _addr.text = c.url!;
          }
        },
      ))
      ..loadRequest(Uri.parse(widget.initialUrl));
    // وضع خفي: لا نحتفظ بكوكيز/ذاكرة بعد الإغلاق.
    _c.clearCache();
    _c.clearLocalStorage();
  }

  @override
  void dispose() {
    _c.clearCache();
    _c.clearLocalStorage();
    WebViewCookieManager().clearCookies();
    _addr.dispose();
    super.dispose();
  }

  void _go(String v) {
    var t = v.trim();
    if (t.isEmpty) return;
    if (!t.startsWith('http')) {
      t = t.contains('.') && !t.contains(' ') ? 'https://$t' : 'https://www.google.com/search?q=${Uri.encodeComponent(t)}';
    }
    _c.loadRequest(Uri.parse(t));
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        if (await _c.canGoBack()) {
          _c.goBack();
        } else if (context.mounted) {
          Navigator.pop(context);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0,
          title: TextField(
            controller: _addr,
            keyboardType: TextInputType.url,
            textInputAction: TextInputAction.go,
            onSubmitted: _go,
            decoration: const InputDecoration(border: InputBorder.none, hintText: 'ابحث أو اكتب عنوانًا', prefixIcon: Icon(Icons.theater_comedy_rounded, color: kCyan)),
          ),
          actions: [IconButton(onPressed: () => _c.reload(), icon: const Icon(Icons.refresh_rounded))],
          bottom: _progress < 100 ? PreferredSize(preferredSize: const Size.fromHeight(3), child: LinearProgressIndicator(value: _progress / 100)) : null,
        ),
        body: WebViewWidget(controller: _c),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: kCyan,
          foregroundColor: Colors.black87,
          onPressed: () => Navigator.pop(context, _url),
          icon: const Icon(Icons.download_rounded),
          label: const Text('تحميل هذه الصفحة'),
        ),
      ),
    );
  }
}
