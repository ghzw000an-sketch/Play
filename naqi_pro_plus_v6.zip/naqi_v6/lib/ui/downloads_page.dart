import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import 'design.dart';
import 'glass.dart';
import 'player_page.dart';

class DownloadsPage extends ConsumerWidget {
  const DownloadsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasks = ref.watch(downloadManagerProvider);
    final m = ref.read(downloadManagerProvider.notifier);
    final hasFinished = tasks.any((t) => t.state == TaskState.done || t.state == TaskState.cancelled);
    final active = tasks.where((t) => t.state == TaskState.running || t.state == TaskState.queued).length;
    final speed = tasks.where((t) => t.state == TaskState.running).fold<double>(0, (a, t) => a + t.speed);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      children: [
        PageTitle('التنزيلات الجارية',
            icon: Icons.downloading_rounded,
            sub: active > 0 ? '$active نشطة${speed > 1 ? ' • ${fmtSpeed(speed)}' : ''}' : 'لا توجد تنزيلات نشطة'),
        if (hasFinished)
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: TextButton.icon(onPressed: m.clearFinished, icon: const Icon(Icons.clear_all), label: const Text('مسح المنتهية')),
          ),
        if (tasks.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 80),
            child: Column(children: [
              Icon(Icons.cloud_download_outlined, size: 72, color: Theme.of(context).colorScheme.outline),
              const SizedBox(height: 12),
              const Text('لا توجد تنزيلات حاليًا'),
            ]),
          ),
        for (final t in tasks.reversed) _TaskCard(task: t),
      ],
    );
  }
}

class _TaskCard extends ConsumerWidget {
  final DownloadTask task;
  const _TaskCard({required this.task});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final m = ref.read(downloadManagerProvider.notifier);
    final tt = Theme.of(context).textTheme;
    final s = task.state;
    final pct = task.progress;
    final site = siteName(task.info.site);

    String barLabel;
    if (s == TaskState.done) {
      barLabel = 'اكتمل';
    } else if (s == TaskState.failed) {
      barLabel = 'فشل';
    } else if (s == TaskState.cancelled) {
      barLabel = 'أُلغي';
    } else if (s == TaskState.paused) {
      barLabel = 'متوقف مؤقتًا${pct != null ? ' • ${(pct * 100).round()}%' : ''}';
    } else if (s == TaskState.queued) {
      barLabel = 'بالانتظار';
    } else {
      barLabel = pct == null ? 'جارٍ التنزيل…' : '${(pct * 100).round()}%';
    }

    String sub;
    if (s == TaskState.failed) {
      sub = (task.error == null || task.error!.isEmpty) ? 'فشل التنزيل' : task.error!;
    } else if (s == TaskState.done) {
      sub = 'اكتمل • ${fmtBytes(task.received)} — الملف في المكتبة';
    } else {
      final extra = (s == TaskState.running && task.speed > 1)
          ? ' • ${fmtSpeed(task.speed)}${task.etaSec != null ? ' • متبقي ${fmtDuration(Duration(seconds: task.etaSec!))}' : ''}'
          : '';
      sub = '${fmtBytes(task.received)} / ${fmtBytes(task.total)}$extra';
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Glass(
        accent: s == TaskState.running ? kBlue : null,
        padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            PlatformBadge(site, size: 42),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(task.info.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                Text('$site • ${task.option.label}', style: tt.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
              ]),
            ),
            if (s == TaskState.running) IconButton(tooltip: 'إيقاف مؤقت', onPressed: () => m.pause(task.id), icon: const Icon(Icons.pause_rounded)),
            if (s == TaskState.paused || s == TaskState.failed)
              IconButton(tooltip: 'استئناف', onPressed: () => m.resume(task.id), icon: const Icon(Icons.play_arrow_rounded)),
            if (s == TaskState.done)
              IconButton(
                tooltip: 'تشغيل',
                icon: const Icon(Icons.play_circle_fill_rounded, color: kMint),
                onPressed: () {
                  final items = ref.read(libraryProvider).where((i) => i.id == task.id);
                  if (items.isNotEmpty) {
                    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerPage(item: items.first)));
                  }
                },
              ),
            if (s == TaskState.queued || s == TaskState.running || s == TaskState.paused)
              IconButton(
                tooltip: 'إلغاء',
                onPressed: () async {
                  final ok = await confirmSheet(context, message: 'إلغاء هذا التنزيل وحذف الملف الجزئي؟', action: 'إلغاء التنزيل');
                  if (ok) m.cancel(task.id);
                },
                icon: const Icon(Icons.close_rounded),
              ),
            if (s == TaskState.done || s == TaskState.failed || s == TaskState.cancelled)
              IconButton(tooltip: 'إزالة من القائمة', onPressed: () => m.remove(task.id), icon: const Icon(Icons.delete_outline)),
          ]),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 6),
            child: GradientBar(value: s == TaskState.done ? 1 : pct, label: barLabel, done: s == TaskState.done),
          ),
          const SizedBox(height: 6),
          Text(sub, style: tt.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
        ]),
      ),
    );
  }
}
