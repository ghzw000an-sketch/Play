import 'package:flutter/material.dart';
import '../core/models.dart';

const kCyan = Color(0xFF22D3EE);
const kBlue = Color(0xFF3B82F6);
const kPurple = Color(0xFFB620E0);
const kMint = Color(0xFF86E3C0);

/// ألوان وأيقونات المنصات (أيقونات Material بدل شعارات العلامات التجارية).
class PlatformStyle {
  final String name;
  final String sub;
  final Color color;
  final IconData icon;
  const PlatformStyle(this.name, this.sub, this.color, this.icon);
}

const platformStyles = <String, PlatformStyle>{
  'YouTube': PlatformStyle('YouTube', 'فيديو وشورتس', Color(0xFFFF2D2D), Icons.play_arrow_rounded),
  'TikTok': PlatformStyle('TikTok', 'بدون علامة مائية', Color(0xFF22D3EE), Icons.music_note_rounded),
  'Instagram': PlatformStyle('Instagram', 'القصص والريلز', Color(0xFFC13584), Icons.camera_alt_rounded),
  'WhatsApp': PlatformStyle('WhatsApp', 'الحالات والقصص', Color(0xFF25D366), Icons.chat_rounded),
  'Snapchat': PlatformStyle('Snapchat', 'القصص والفيديو', Color(0xFFFFD60A), Icons.emoji_emotions_rounded),
  'Facebook': PlatformStyle('Facebook', 'فيديو وريلز', Color(0xFF3B82F6), Icons.facebook_rounded),
  'Pinterest': PlatformStyle('Pinterest', 'صور وفيديو', Color(0xFFE60023), Icons.push_pin_rounded),
  'X': PlatformStyle('X', 'فيديو وصور', Color(0xFF9CA3AF), Icons.close_rounded),
};

PlatformStyle styleFor(String site) =>
    platformStyles[site] ?? const PlatformStyle('Other', 'مواقع أخرى', Color(0xFF8B8FA8), Icons.public_rounded);

class PlatformBadge extends StatelessWidget {
  final String site;
  final double size;
  const PlatformBadge(this.site, {super.key, this.size = 56});

  @override
  Widget build(BuildContext context) {
    final st = styleFor(site);
    final dark = st.color.computeLuminance() > 0.6; // خلفية فاتحة (أصفر) → أيقونة داكنة
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: site == 'Instagram'
            ? const LinearGradient(colors: [Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF)])
            : null,
        color: site == 'Instagram' ? null : (site == 'TikTok' ? Colors.black : st.color),
        border: site == 'TikTok' ? Border.all(color: kCyan, width: 2) : null,
        boxShadow: [BoxShadow(color: st.color.withOpacity(0.55), blurRadius: size / 3)],
      ),
      child: Icon(st.icon, color: dark ? Colors.black87 : Colors.white, size: size * 0.55),
    );
  }
}

/// زر بتدرّج لوني (أزرق → سماوي).
class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool busy;
  const GradientButton({super.key, required this.label, this.icon, this.onPressed, this.busy = false});

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !busy;
    return Opacity(
      opacity: enabled ? 1 : 0.6,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(28),
          onTap: enabled ? onPressed : null,
          child: Ink(
            height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(colors: [Color(0xFF1E6BFF), Color(0xFF12D8FA)]),
              boxShadow: [BoxShadow(color: kCyan.withOpacity(0.35), blurRadius: 16)],
            ),
            child: Center(
              child: busy
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.black87))
                  : Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(label, style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w800, fontSize: 17)),
                      if (icon != null) ...[const SizedBox(width: 8), Icon(icon, color: Colors.black87)],
                    ]),
            ),
          ),
        ),
      ),
    );
  }
}

/// شريط تقدم بتدرّج (بنفسجي → أزرق → أخضر) مع نص داخله.
class GradientBar extends StatelessWidget {
  final double? value; // 0..1 أو null لغير محدد
  final String label;
  final bool done;
  const GradientBar({super.key, required this.value, required this.label, this.done = false});

  @override
  Widget build(BuildContext context) {
    final v = (value ?? 0.0).clamp(0.0, 1.0);
    return Container(
      height: 34,
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.28), borderRadius: BorderRadius.circular(17)),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(17),
        child: Stack(children: [
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: FractionallySizedBox(
              widthFactor: value == null ? 0.25 : (v < 0.06 ? 0.06 : v),
              child: Container(
                decoration: BoxDecoration(
                  gradient: done
                      ? const LinearGradient(colors: [kMint, kMint])
                      : const LinearGradient(colors: [Color(0xFFE040FB), Color(0xFF3B82F6), Color(0xFF34D399)]),
                ),
              ),
            ),
          ),
          Center(
            child: Text(label,
                maxLines: 1,
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: done ? Colors.black87 : Colors.white)),
          ),
        ]),
      ),
    );
  }
}

/// عنوان قسم.
class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 16, 4, 10),
        child: Row(children: [
          Expanded(child: Text(text, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
          if (trailing != null) trailing!,
        ]),
      );
}

/// عنوان صفحة بسهم.
class PageTitle extends StatelessWidget {
  final String text;
  final String? sub;
  final IconData? icon;
  const PageTitle(this.text, {super.key, this.sub, this.icon});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            if (icon != null) ...[Icon(icon, color: kMint, size: 30), const SizedBox(width: 10)],
            Text(text, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
          ]),
          if (sub != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(sub!, style: Theme.of(context).textTheme.bodyMedium)),
        ]),
      );
}

/// شريط التنقل السفلي العائم.
class NeonNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  final int activeBadge;
  const NeonNav({super.key, required this.index, required this.onTap, this.activeBadge = 0});

  static const _items = [
    (Icons.search_rounded, 'الرئيسية'),
    (Icons.downloading_rounded, 'الجارية'),
    (Icons.video_library_rounded, 'المكتبة'),
    (Icons.shield_rounded, 'الخزنة'),
    (Icons.settings_rounded, 'الإعدادات'),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        child: Container(
          height: 72,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: cs.surfaceContainerHigh.withOpacity(0.92),
            border: Border.all(color: Colors.white.withOpacity(0.14)),
          ),
          child: Row(children: [
            for (var i = 0; i < _items.length; i++)
              Expanded(
                child: InkWell(
                  borderRadius: BorderRadius.circular(26),
                  onTap: () => onTap(i),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(
                      width: 56,
                      height: 34,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(17),
                        color: i == index ? kCyan.withOpacity(0.18) : Colors.transparent,
                        border: i == index ? Border.all(color: kCyan.withOpacity(0.7)) : null,
                        boxShadow: i == index ? [BoxShadow(color: kCyan.withOpacity(0.35), blurRadius: 12)] : null,
                      ),
                      child: Badge(
                        isLabelVisible: i == 1 && activeBadge > 0,
                        label: Text('+$activeBadge'),
                        backgroundColor: kMint,
                        textColor: Colors.black,
                        child: Icon(_items[i].$1, color: i == index ? kCyan : cs.onSurface.withOpacity(0.6), size: 24),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(_items[i].$2,
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: i == index ? FontWeight.w800 : FontWeight.w500,
                            color: i == index ? kCyan : cs.onSurface.withOpacity(0.6))),
                  ]),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}

String platformFolderTitle(String site) => switch (site) {
      'YouTube' => 'مجلد يوتيوب',
      'TikTok' => 'مجلد تيك توك',
      'Instagram' => 'مجلد إنستغرام',
      'WhatsApp' => 'مجلد واتساب',
      'Snapchat' => 'مجلد سناب شات',
      'Facebook' => 'مجلد فيسبوك',
      'Pinterest' => 'مجلد بنتريست',
      'X' => 'مجلد إكس',
      _ => 'مجلد أخرى',
    };

String itemsLabel(int n, int bytes) => '$n عنصرًا • ${fmtBytes(bytes)}';
