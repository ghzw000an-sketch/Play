import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';
import '../core/models.dart';

class PlayerPage extends StatefulWidget {
  final LibraryItem item;
  const PlayerPage({super.key, required this.item});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  VideoPlayerController? _c;
  bool _error = false;
  double _speed = 1;

  @override
  void initState() {
    super.initState();
    if (!widget.item.isImage) _init();
  }

  Future<void> _init() async {
    final c = VideoPlayerController.file(File(widget.item.filePath));
    _c = c;
    try {
      await c.initialize();
      await c.play();
    } catch (_) {
      _error = true;
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  void _seekBy(VideoPlayerController c, int seconds) {
    final v = c.value;
    var t = v.position + Duration(seconds: seconds);
    if (t < Duration.zero) t = Duration.zero;
    if (t > v.duration) t = v.duration;
    c.seekTo(t);
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.item;
    final c = _c;
    const white = TextStyle(color: Colors.white70);

    Widget body;
    if (i.isImage) {
      body = InteractiveViewer(child: Center(child: Image.file(File(i.filePath))));
    } else if (_error) {
      body = const Center(child: Text('تعذّر تشغيل هذا الملف', style: TextStyle(color: Colors.white)));
    } else if (c == null || !c.value.isInitialized) {
      body = const Center(child: CircularProgressIndicator());
    } else {
      body = Column(children: [
        Expanded(
          child: Center(
            child: i.audioOnly
                ? const Icon(Icons.music_note_rounded, size: 120, color: Colors.white54)
                : AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
          ),
        ),
        ValueListenableBuilder<VideoPlayerValue>(
          valueListenable: c,
          builder: (_, v, __) => Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              VideoProgressIndicator(c, allowScrubbing: true, padding: const EdgeInsets.symmetric(vertical: 12)),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(fmtDuration(v.position), style: white),
                Text(fmtDuration(v.duration), style: white),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(
                  color: Colors.white,
                  iconSize: 34,
                  icon: const Icon(Icons.replay_10_rounded),
                  onPressed: () => _seekBy(c, -10),
                ),
                IconButton(
                  color: Colors.white,
                  iconSize: 64,
                  icon: Icon(v.isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded),
                  onPressed: () => v.isPlaying ? c.pause() : c.play(),
                ),
                IconButton(
                  color: Colors.white,
                  iconSize: 34,
                  icon: const Icon(Icons.forward_10_rounded),
                  onPressed: () => _seekBy(c, 10),
                ),
                PopupMenuButton<double>(
                  tooltip: 'السرعة',
                  initialValue: _speed,
                  icon: const Icon(Icons.speed_rounded, color: Colors.white),
                  onSelected: (s) {
                    setState(() => _speed = s);
                    c.setPlaybackSpeed(s);
                  },
                  itemBuilder: (_) => [
                    for (final s in const [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]) PopupMenuItem(value: s, child: Text('${s}x')),
                  ],
                ),
              ]),
            ]),
          ),
        ),
      ]);
    }

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(i.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'مشاركة',
            icon: const Icon(Icons.share_rounded),
            onPressed: () => Share.shareXFiles([XFile(i.filePath)], text: i.title),
          ),
        ],
      ),
      body: SafeArea(child: body),
    );
  }
}
