import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../core/vault.dart';
import '../engine/native_engine.dart';
import 'design.dart';
import 'downloads_page.dart';
import 'glass.dart';
import 'home_page.dart';
import 'library_page.dart';
import 'player_page.dart';
import 'settings_page.dart';
import 'vault_page.dart';

class Shell extends ConsumerStatefulWidget {
  const Shell({super.key});
  @override
  ConsumerState<Shell> createState() => _ShellState();
}

class _ShellState extends ConsumerState<Shell> {
  @override
  void initState() {
    super.initState();
    ShareIn.start((url) {
      if (!mounted) return;
      ref.read(tabProvider.notifier).state = 0;
      ref.read(incomingLinkProvider.notifier).state = url;
    });
    _maybeUpdateEngine();
  }

  Future<void> _maybeUpdateEngine() async {
    if (!ref.read(settingsProvider).autoUpdateEngine) return;
    final prefs = ref.read(prefsProvider);
    final last = prefs.getInt('engineUpdatedAt') ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - last < 24 * 3600 * 1000) return;
    if (!await NativeEngine.available) return;
    try {
      await NativeEngine.update();
      await prefs.setInt('engineUpdatedAt', now);
    } catch (_) {}
  }

  void _setTab(int i) {
    // مغادرة تبويب الخزنة تقفلها من جديد.
    if (ref.read(tabProvider) == 3 && i != 3) ref.read(vaultUnlockedProvider.notifier).state = false;
    ref.read(tabProvider.notifier).state = i;
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<LibraryItem?>(justFinishedProvider, (prev, next) {
      if (next == null) return;
      ref.read(justFinishedProvider.notifier).state = null;
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerPage(item: next)));
    });
    final index = ref.watch(tabProvider);
    final active = ref
        .watch(downloadManagerProvider)
        .where((t) => t.state == TaskState.running || t.state == TaskState.queued || t.state == TaskState.paused)
        .length;

    return Scaffold(
      extendBody: true,
      body: AppBackground(
        child: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: index,
            children: const [HomePage(), DownloadsPage(), LibraryPage(), VaultPage(), SettingsPage()],
          ),
        ),
      ),
      bottomNavigationBar: NeonNav(index: index, onTap: _setTab, activeBadge: active),
    );
  }
}
