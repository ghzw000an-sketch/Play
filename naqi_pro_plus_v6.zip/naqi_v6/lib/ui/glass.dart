import 'dart:ui';
import 'package:flutter/material.dart';

/// بطاقة زجاجية بحدّ نيون اختياريّ (accent).
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color? accent;
  const Glass({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.radius = 24, this.accent});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final border = accent != null
        ? accent!.withOpacity(dark ? 0.7 : 0.8)
        : Colors.white.withOpacity(dark ? 0.16 : 0.6);
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: accent == null
            ? null
            : [BoxShadow(color: accent!.withOpacity(dark ? 0.25 : 0.18), blurRadius: 14, spreadRadius: 0.5)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withOpacity(dark ? 0.10 : 0.55),
                  Colors.white.withOpacity(dark ? 0.03 : 0.25),
                ],
              ),
              border: Border.all(color: border, width: accent != null ? 1.4 : 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

/// خلفية التطبيق: تدرّج داكن مع توهّج ملوّن على الحافتين (أسود خالص عند AMOLED).
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final black = cs.surface == Colors.black;
    if (!dark) {
      return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [cs.primaryContainer, cs.surface, cs.tertiaryContainer.withOpacity(0.5)],
          ),
        ),
        child: child,
      );
    }
    return Container(
      decoration: BoxDecoration(
        color: black ? Colors.black : null,
        gradient: black
            ? null
            : const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF0B2A4A), Color(0xFF101428), Color(0xFF241238)],
              ),
      ),
      child: Stack(children: [
        // توهّج الحافة اليسرى (سماوي) واليمنى (بنفسجي)
        Positioned(
          left: 0,
          top: 0,
          bottom: 0,
          width: 6,
          child: DecoratedBox(
              decoration: BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [
            const Color(0xFF22D3EE).withOpacity(0.8),
            Colors.transparent,
            const Color(0xFFB620E0).withOpacity(0.8),
          ]))),
        ),
        Positioned(
          right: 0,
          top: 0,
          bottom: 0,
          width: 6,
          child: DecoratedBox(
              decoration: BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [
            const Color(0xFF3B82F6).withOpacity(0.7),
            Colors.transparent,
            const Color(0xFFB620E0).withOpacity(0.7),
          ]))),
        ),
        child,
      ]),
    );
  }
}

/// نافذة سفلية زجاجية.
Future<T?> showGlassSheet<T>(BuildContext context, WidgetBuilder builder) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      final cs = Theme.of(ctx).colorScheme;
      return Padding(
        padding: EdgeInsets.fromLTRB(10, 0, 10, 10 + MediaQuery.of(ctx).viewInsets.bottom),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(
              color: cs.surfaceContainerHigh.withOpacity(0.94),
              child: SafeArea(
                top: false,
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.85),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      margin: const EdgeInsets.only(top: 10, bottom: 6),
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(color: cs.onSurface.withOpacity(0.25), borderRadius: BorderRadius.circular(2)),
                    ),
                    Flexible(child: builder(ctx)),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

Future<bool> confirmSheet(BuildContext context, {required String message, required String action, String? title}) async {
  final r = await showGlassSheet<bool>(
    context,
    (ctx) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (title != null) Text(title, style: Theme.of(ctx).textTheme.titleLarge, textAlign: TextAlign.center),
        if (title != null) const SizedBox(height: 8),
        Text(message, style: Theme.of(ctx).textTheme.bodyLarge, textAlign: TextAlign.center),
        const SizedBox(height: 20),
        SizedBox(
          height: 48,
          child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(action),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(height: 48, child: TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء'))),
      ]),
    ),
  );
  return r ?? false;
}

Future<String?> inputSheet(BuildContext context, {required String title, String initial = '', String action = 'حفظ', String? hint}) {
  final ctrl = TextEditingController(text: initial);
  return showGlassSheet<String>(
    context,
    (ctx) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(title, style: Theme.of(ctx).textTheme.titleMedium),
        const SizedBox(height: 12),
        TextField(
          controller: ctrl,
          autofocus: true,
          decoration: InputDecoration(hintText: hint),
          textInputAction: TextInputAction.done,
          onSubmitted: (v) => Navigator.pop(ctx, v),
        ),
        const SizedBox(height: 16),
        SizedBox(height: 48, child: FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: Text(action))),
      ]),
    ),
  );
}
