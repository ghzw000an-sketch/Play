import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../core/vault.dart';
import 'design.dart';
import 'glass.dart';
import 'lock_screen.dart';
import 'player_page.dart';

class VaultPage extends ConsumerStatefulWidget {
  const VaultPage({super.key});
  @override
  ConsumerState<VaultPage> createState() => _VaultPageState();
}

class _VaultPageState extends ConsumerState<VaultPage> {
  late bool _hasPin = PinStore.has(ref.read(prefsProvider));

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _biometricUnlock() async {
    if (await Biometric.authenticate('افتح الخزنة الآمنة')) {
      ref.read(vaultUnlockedProvider.notifier).state = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final prefs = ref.watch(prefsProvider);
    final unlocked = ref.watch(vaultUnlockedProvider);
    final settings = ref.watch(settingsProvider);

    if (!_hasPin) {
      return PinSetup(onCreate: (pin) async {
        await PinStore.set(prefs, pin);
        if (!mounted) return;
        setState(() => _hasPin = true);
        ref.read(vaultUnlockedProvider.notifier).state = true;
      });
    }
    if (!unlocked) {
      return LockPad(
        title: 'الخزنة الآمنة',
        subtitle: 'أدخل الرمز لفتح الخزنة',
        onBiometric: settings.biometric ? _biometricUnlock : null,
        onSubmit: (pin) async {
          if (await PinStore.verify(prefs, pin)) {
            ref.read(vaultUnlockedProvider.notifier).state = true;
            return null;
          }
          return 'رمز غير صحيح';
        },
      );
    }
    return _content(settings);
  }

  Widget _content(AppSettings settings) {
    final items = ref.watch(vaultProvider);
    int count(int k) => items.where((i) => i.kind == k).length;
    final tt = Theme.of(context).textTheme;

    Widget folder(int kind, String title, String desc, String unit, IconData ic, Color color) => Expanded(
          child: InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: () => _openFolder(kind, title),
            child: Glass(
              accent: color,
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                height: 150,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(ic, color: color, size: 34),
                  const Spacer(),
                  Text(title, style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                  Text(desc, style: tt.bodySmall, maxLines: 2),
                  const SizedBox(height: 8),
                  Text('${count(kind)} $unit • مشفرة', style: tt.bodyMedium),
                ]),
              ),
            ),
          ),
        );

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 110),
      children: [
        const PageTitle('الخزنة الآمنة', sub: 'الملفات هنا مشفرة ومحمية بالكامل', icon: Icons.lock_rounded),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: ActionChip(
            avatar: const Icon(Icons.admin_panel_settings_outlined, size: 18),
            label: const Text('إعدادات الأمان'),
            onPressed: () {
              ref.read(settingsTabProvider.notifier).state = 2;
              ref.read(tabProvider.notifier).state = 4;
            },
          ),
        ),
        const SectionTitle('المجلدات الآمنة'),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          folder(0, 'مجلد الصور', 'إضافة وحفظ الصور الخاصة', 'صورة', Icons.image_rounded, kBlue),
          const SizedBox(width: 12),
          folder(1, 'مجلد مقاطع الفيديو', 'إضافة وحفظ مقاطع الفيديو الخاصة', 'فيديو', Icons.videocam_rounded, kPurple),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          folder(2, 'مجلد ملفات أخرى', 'إضافة المستندات والملفات المتنوعة', 'ملف', Icons.description_rounded, const Color(0xFFFF8A3D)),
          const SizedBox(width: 12),
          const Expanded(child: SizedBox()),
        ]),
        const SectionTitle('أمان التطبيق'),
        Glass(
          accent: const Color(0xFF34D399),
          child: Column(children: [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const CircleAvatar(backgroundColor: Color(0xFF22C55E), child: Icon(Icons.lock_person_rounded, color: Colors.white)),
              title: const Text('قفل التطبيقات'),
              subtitle: const Text('حماية التطبيق برمز مرور أو بصمة الإصبع'),
              value: settings.appLock,
              onChanged: (v) => ref.read(settingsProvider.notifier).change(appLock: v),
            ),
            FutureBuilder<bool>(
              future: Biometric.available(),
              builder: (_, snap) => snap.data == true
                  ? SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('استخدام البصمة'),
                      value: settings.biometric,
                      onChanged: (v) => ref.read(settingsProvider.notifier).change(biometric: v),
                    )
                  : const SizedBox.shrink(),
            ),
          ]),
        ),
        const SizedBox(height: 20),
        GradientButton(label: 'إضافة ملف جديد للخزنة', icon: Icons.add_rounded, onPressed: _addFlow),
      ],
    );
  }

  // ───────────────────────── إضافة ملفات ─────────────────────────
  void _addFlow() {
    final lib = ref.read(libraryProvider).where((i) => !i.trashed && File(i.filePath).existsSync()).toList();
    showGlassSheet<void>(context, (ctx) {
      if (lib.isEmpty) {
        return const Padding(padding: EdgeInsets.all(28), child: Text('لا توجد ملفات في المكتبة لإضافتها.'));
      }
      return ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
          child: Text('اختر ملفًا لنقله إلى الخزنة (يُشفَّر ويُحذف الأصل)', style: Theme.of(ctx).textTheme.titleSmall),
        ),
        for (final i in lib)
          ListTile(
            leading: Icon(i.audioOnly ? Icons.music_note_rounded : (i.isImage ? Icons.image_rounded : Icons.movie_rounded)),
            title: Text(i.title, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text('${i.site} • ${fmtBytes(i.sizeBytes)}'),
            onTap: () {
              Navigator.pop(ctx);
              _moveToVault(i);
            },
          ),
      ]);
    });
  }

  Future<void> _moveToVault(LibraryItem i) async {
    _snack('جارٍ التشفير…');
    try {
      final v = await ref.read(vaultProvider.notifier).addFile(i.filePath, i.title);
      if (v == null) {
        _snack('الملف غير موجود');
        return;
      }
      await ref.read(libraryProvider.notifier).removeMany([i.id]);
      _snack('تم نقل الملف إلى الخزنة وتشفيره');
    } catch (_) {
      _snack('تعذّر التشفير على هذا الجهاز');
    }
  }

  // ───────────────────────── محتوى المجلد ─────────────────────────
  void _openFolder(int kind, String title) {
    showGlassSheet<void>(context, (ctx) => Consumer(builder: (ctx, ref, _) {
          final items = ref.watch(vaultProvider).where((i) => i.kind == kind).toList();
          if (items.isEmpty) {
            return const Padding(padding: EdgeInsets.all(28), child: Text('المجلد فارغ. أضف ملفات بزر "إضافة ملف جديد للخزنة".'));
          }
          return ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
            Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 8), child: Text(title, style: Theme.of(ctx).textTheme.titleMedium)),
            for (final i in items)
              ListTile(
                leading: const Icon(Icons.lock_rounded, color: kMint),
                title: Text(i.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${fmtBytes(i.size)} • ${fmtDate(DateTime.fromMillisecondsSinceEpoch(i.createdAt))}'),
                trailing: PopupMenuButton<String>(
                  onSelected: (a) {
                    Navigator.pop(ctx);
                    if (a == 'view') _view(i);
                    if (a == 'restore') _restore(i);
                    if (a == 'delete') _delete(i);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'view', child: Text('عرض')),
                    PopupMenuItem(value: 'restore', child: Text('استعادة إلى التطبيق')),
                    PopupMenuItem(value: 'delete', child: Text('حذف نهائي')),
                  ],
                ),
                onTap: () {
                  Navigator.pop(ctx);
                  _view(i);
                },
              ),
          ]);
        }));
  }

  Future<void> _view(VaultItem i) async {
    try {
      final tmp = await ref.read(vaultProvider.notifier).decryptToTemp(i);
      if (!mounted) return;
      final temp = LibraryItem(
        id: i.id,
        title: i.title,
        site: '',
        filePath: tmp,
        audioOnly: i.kind == 2,
        sizeBytes: i.size,
        label: '',
        createdAt: DateTime.fromMillisecondsSinceEpoch(i.createdAt),
      );
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerPage(item: temp)));
      await VaultNative.wipe(tmp); // لا نترك نسخة مفكوكة على الجهاز
    } catch (_) {
      _snack('تعذّر فتح الملف');
    }
  }

  Future<void> _restore(VaultItem i) async {
    try {
      final path = await ref.read(vaultProvider.notifier).restore(i);
      final size = await File(path).length();
      ref.read(libraryProvider.notifier).add(LibraryItem(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            title: i.title,
            site: 'Other',
            filePath: path,
            audioOnly: i.kind == 2,
            sizeBytes: size,
            label: 'مستعاد',
            createdAt: DateTime.now(),
          ));
      _snack('أُعيد الملف إلى المكتبة');
    } catch (_) {
      _snack('تعذّرت الاستعادة');
    }
  }

  Future<void> _delete(VaultItem i) async {
    final ok = await confirmSheet(context,
        title: 'حذف نهائي', message: 'سيُحذف الملف المشفّر نهائيًا ولا يمكن استرجاعه.', action: 'حذف');
    if (!ok) return;
    await ref.read(vaultProvider.notifier).remove(i);
    _snack('تم الحذف');
  }
}
