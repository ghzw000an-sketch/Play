import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/settings.dart';
import 'core/vault.dart';
import 'ui/lock_screen.dart';
import 'ui/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [prefsProvider.overrideWithValue(prefs)],
    child: const NaqiApp(),
  ));
}

class NaqiApp extends ConsumerWidget {
  const NaqiApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);

    ThemeData theme(Brightness b) {
      var cs = ColorScheme.fromSeed(seedColor: Color(s.seed), brightness: b);
      if (b == Brightness.dark && s.amoled) cs = cs.copyWith(surface: Colors.black);
      return ThemeData(
        useMaterial3: true,
        colorScheme: cs,
        materialTapTargetSize: MaterialTapTargetSize.padded,
      );
    }

    return MaterialApp(
      title: 'نقي Pro Plus',
      debugShowCheckedModeBanner: false,
      theme: theme(Brightness.light),
      darkTheme: theme(Brightness.dark),
      themeMode: s.themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const AppLockGate(child: Shell()),
    );
  }
}

/// يغطي التطبيق بشاشة القفل عند التشغيل والعودة من الخلفية (إن فُعّل القفل).
class AppLockGate extends ConsumerStatefulWidget {
  final Widget child;
  const AppLockGate({super.key, required this.child});
  @override
  ConsumerState<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends ConsumerState<AppLockGate> with WidgetsBindingObserver {
  bool _locked = false;
  DateTime? _pausedAt;

  bool get _enabled {
    final p = ref.read(prefsProvider);
    return ref.read(settingsProvider).appLock && PinStore.has(p);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _locked = _enabled;
    if (_locked) WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (s == AppLifecycleState.resumed && _enabled && !_locked) {
      // تجاهل التنقل القصير (منتقي ملفات، مشاركة…)
      if (_pausedAt != null && DateTime.now().difference(_pausedAt!).inSeconds > 20) {
        setState(() => _locked = true);
        _bio();
      }
    }
  }

  Future<void> _bio() async {
    if (!ref.read(settingsProvider).biometric) return;
    if (await Biometric.authenticate('افتح نقي Pro Plus') && mounted) setState(() => _locked = false);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      widget.child,
      if (_locked)
        Positioned.fill(
          child: AppLockScreen(
            onBiometric: ref.read(settingsProvider).biometric ? _bio : null,
            verify: (pin) async {
              if (await PinStore.verify(ref.read(prefsProvider), pin)) {
                if (mounted) setState(() => _locked = false);
                return null;
              }
              return 'الرمز غير صحيح';
            },
          ),
        ),
    ]);
  }
}
