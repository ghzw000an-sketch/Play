import 'package:gal/gal.dart';

/// يحفظ الملف في استوديو الهاتف (ألبوم Naqi). يرجع true عند النجاح.
Future<bool> saveToGallery(String path, {bool image = false}) async {
  try {
    if (!await Gal.hasAccess(toAlbum: true)) {
      if (!await Gal.requestAccess(toAlbum: true)) return false;
    }
    if (image) {
      await Gal.putImage(path, album: 'Naqi');
    } else {
      await Gal.putVideo(path, album: 'Naqi');
    }
    return true;
  } catch (_) {
    return false;
  }
}
