import 'dart:async';
import 'dart:collection';
import 'dart:io' hide Platform;
import 'dart:math' as math;
import 'package:dio/dio.dart';

/// Multi-connection downloader: the file is cut into chunks, N workers pull
/// chunks from a queue (each a separate HTTP Range request) and write them at
/// their offset. Falls back to a single stream if the server has no Range support.
/// Pause = stop(); run() again resumes with completed chunks kept.
class SegmentedDownload {
  SegmentedDownload({
    required this.dio,
    required this.url,
    required this.file,
    this.headers,
    this.fallbackTotal,
    this.connections = 8,
  });

  final Dio dio;
  final String url;
  final File file;
  final Map<String, String>? headers;
  final int? fallbackTotal;
  int connections;

  int? total;
  int received = 0;

  bool _probed = false;
  bool _ranged = false;
  bool _stopped = false;
  int _chunk = 2 * 1024 * 1024;
  final Set<int> _done = {};
  RandomAccessFile? _raf;
  CancelToken? _token;
  Future<void>? _prev;
  Object? _error;

  /// true = finished, false = stopped (pause/cancel). Throws on real failure.
  Future<bool> run() {
    final prev = _prev;
    final f = _runInner(prev);
    _prev = f.then((_) {}, onError: (_) {});
    return f;
  }

  void stop() {
    _stopped = true;
    _token?.cancel('stop');
  }

  void dispose({bool deleteFile = false}) {
    stop();
    try {
      _raf?.closeSync();
    } catch (_) {}
    _raf = null;
    if (deleteFile) {
      try {
        if (file.existsSync()) file.deleteSync();
      } catch (_) {}
    }
  }

  Future<bool> _runInner(Future<void>? prev) async {
    if (prev != null) await prev;
    _stopped = false;
    _error = null;
    _token = CancelToken();
    try {
      if (!_probed) await _probe();
      if (!_ranged) return await _runSingle();

      _raf ??= _open();
      final n = (total! / _chunk).ceil();
      final pending = Queue<int>.from([
        for (var i = 0; i < n; i++)
          if (!_done.contains(i)) i
      ]);

      Future<void> worker() async {
        while (!_stopped && pending.isNotEmpty) {
          final i = pending.removeFirst();
          try {
            await _fetchChunk(i);
          } catch (e) {
            if (_stopped) return;
            _error = e;
            stop();
            return;
          }
        }
      }

      final workers = math.max(1, math.min(connections, pending.length));
      await Future.wait([for (var w = 0; w < workers; w++) worker()]);

      if (_error != null) throw _error!;
      if (_stopped) return false;
      _raf?.closeSync();
      _raf = null;
      return true;
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) return false;
      rethrow;
    }
  }

  Options _opts(Map<String, String> extra) =>
      Options(responseType: ResponseType.stream, headers: {...?headers, ...extra});

  /// يفحص دعم Range وحجم الملف دون تنزيل الجسم (نقطع الاتصال بعد الترويسات).
  Future<void> _probe() async {
    final probe = CancelToken();
    try {
      final r = await dio.get<ResponseBody>(
        url,
        cancelToken: probe,
        options: Options(
          responseType: ResponseType.stream,
          headers: {...?headers, 'Range': 'bytes=0-0'},
          validateStatus: (s) => s != null && s < 400,
        ),
      );
      final status = r.statusCode;
      final cr = r.headers.value('content-range'); // bytes 0-0/12345
      final cl = int.tryParse(r.headers.value(Headers.contentLengthHeader) ?? '');
      probe.cancel('probe done');
      if (status == 206) {
        final t = cr == null ? null : int.tryParse(cr.split('/').last);
        if (t != null && t > 0) {
          total = t;
          _ranged = true;
        }
      } else {
        total = cl ?? fallbackTotal;
      }
    } on DioException catch (e) {
      if (CancelToken.isCancel(e) && !probe.isCancelled) rethrow;
      if (_stopped) rethrow;
      total = fallbackTotal;
    }
    _probed = true;
    if (_ranged) {
      _chunk = (total! ~/ (connections * 3)).clamp(512 * 1024, 8 * 1024 * 1024).toInt();
    }
  }

  RandomAccessFile _open() {
    file.parent.createSync(recursive: true);
    final raf = file.openSync(mode: FileMode.write);
    raf.truncateSync(total!);
    return raf;
  }

  Future<void> _fetchChunk(int i) async {
    final s = i * _chunk;
    final e = math.min(s + _chunk, total!) - 1;
    for (var attempt = 0;; attempt++) {
      var pos = s;
      try {
        final res = await dio.get<ResponseBody>(
          url,
          cancelToken: _token,
          options: _opts({'Range': 'bytes=$s-$e'}),
        );
        if (res.statusCode != 206) throw StateError('Server ignored Range request');
        await for (final data in res.data!.stream) {
          final raf = _raf;
          if (raf == null) throw StateError('closed');
          raf.setPositionSync(pos);
          raf.writeFromSync(data);
          pos += data.length;
          received += data.length;
        }
        if (pos - 1 != e) throw StateError('Short chunk');
        _done.add(i);
        return;
      } catch (err) {
        received -= (pos - s);
        if (_stopped || (err is DioException && CancelToken.isCancel(err)) || attempt >= 3) rethrow;
        await Future.delayed(Duration(milliseconds: 400 * (attempt + 1)));
      }
    }
  }

  Future<bool> _runSingle() async {
    received = 0;
    file.parent.createSync(recursive: true);
    final raf = file.openSync(mode: FileMode.write);
    try {
      final res = await dio.get<ResponseBody>(url, cancelToken: _token, options: _opts({}));
      total ??= int.tryParse(res.headers.value(Headers.contentLengthHeader) ?? '') ?? fallbackTotal;
      await for (final d in res.data!.stream) {
        raf.writeFromSync(d);
        received += d.length;
      }
      return true;
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) return false;
      rethrow;
    } finally {
      raf.closeSync();
    }
  }
}
