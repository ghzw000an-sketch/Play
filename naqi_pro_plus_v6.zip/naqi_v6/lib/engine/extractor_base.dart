import '../core/models.dart';

class ExtractorException implements Exception {
  final String message;
  ExtractorException(this.message);
  @override
  String toString() => message;
}

abstract class Extractor {
  bool supports(Site s);
  Future<MediaInfo> analyze(String url);
}
