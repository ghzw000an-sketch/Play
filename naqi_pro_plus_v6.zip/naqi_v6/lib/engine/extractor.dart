import 'package:youtube_explode_dart/youtube_explode_dart.dart' as yt;
import '../core/models.dart';
import 'extractor_base.dart';
import 'native_engine.dart';
import 'native_extractor.dart';
import 'social_extractors.dart';

export 'extractor_base.dart';

/// YouTube بلغة Dart الخالصة (الملفات العامة فقط).
class YoutubeExtractor implements Extractor {
  final _yt = yt.YoutubeExplode();

  @override
  bool supports(Site s) => s == Site.youtube;

  @override
  Future<MediaInfo> analyze(String url) async {
    try {
      final v = await _yt.videos.get(url);
      final m = await _yt.videos.streamsClient.getManifest(v.id);
      final opts = <MediaOption>[];
      for (final s in m.muxed.sortByVideoQuality().reversed) {
        opts.add(MediaOption(
          id: 'v${s.tag}',
          label: s.videoQualityLabel,
          audioOnly: false,
          container: s.container.name,
          sizeBytes: s.size.totalBytes,
          url: s.url.toString(),
        ));
      }
      final audio = m.audioOnly.sortByBitrate().reversed.toList();
      for (final a in audio.take(2)) {
        opts.add(MediaOption(
          id: 'a${a.tag}',
          label: '${a.container.name.toUpperCase()} ${a.bitrate.kiloBitsPerSecond.round()}kbps',
          audioOnly: true,
          container: a.container.name == 'mp4' ? 'm4a' : a.container.name,
          sizeBytes: a.size.totalBytes,
          url: a.url.toString(),
        ));
      }
      if (opts.isEmpty) throw ExtractorException('لا توجد صيغ متاحة لهذا الفيديو.');
      return MediaInfo(
        sourceUrl: url,
        site: Site.youtube,
        title: v.title,
        author: v.author,
        thumbnail: v.thumbnails.highResUrl,
        duration: v.duration,
        options: opts,
      );
    } on ExtractorException {
      rethrow;
    } catch (e) {
      throw ExtractorException('تعذّر تحليل رابط يوتيوب (قد يكون خاصًا أو مقيّدًا).');
    }
  }
}

class ExtractorRegistry {
  final _youtube = YoutubeExtractor();
  final _native = NativeExtractor();
  // احتياطي إذا لم يتوفر المحرك الأصلي أو فشل (صفحات عامة فقط).
  final List<Extractor> _fallbacks = [TikTokExtractor(), InstagramExtractor(), FacebookExtractor()];

  Future<MediaInfo> analyze(String url) async {
    final s = detectSite(url);
    final hasEngine = await NativeEngine.available;

    if (s == Site.youtube) {
      try {
        return await _youtube.analyze(url);
      } catch (e) {
        if (!hasEngine) rethrow;
        return _native.analyze(url);
      }
    }

    if (hasEngine) {
      try {
        return await _native.analyze(url);
      } on ExtractorException catch (nativeErr) {
        if (s == Site.unknown) rethrow;
        // جرّب المستخرجات الاحتياطية، وإن فشلت أظهر سبب المحرك الحقيقي.
        for (final f in _fallbacks.where((e) => e.supports(s))) {
          try {
            return await f.analyze(url);
          } catch (_) {}
        }
        throw nativeErr;
      }
    }

    if (s == Site.unknown) {
      throw ExtractorException('رابط غير مدعوم. المدعوم: يوتيوب، تيك توك، إنستغرام، فيسبوك ومواقع أخرى عبر المحرك.');
    }
    return _fallbacks.firstWhere((e) => e.supports(s)).analyze(url);
  }
}
