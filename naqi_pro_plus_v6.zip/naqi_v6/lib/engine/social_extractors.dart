import 'dart:convert';
import 'package:dio/dio.dart';
import '../core/models.dart';
import 'extractor_base.dart';

// ملاحظة: هذه المستخرجات تعتمد على صفحات عامة وخدمات خارجية، وقد تتوقف عند تغيير
// المنصات لتصميمها. الروابط العامة فقط، بدون تسجيل دخول وبدون تجاوز أي حماية.

const _ua =
    'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';
const _desktopUa =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
const _botUa = 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)';

final _http = Dio(BaseOptions(
  connectTimeout: const Duration(seconds: 15),
  receiveTimeout: const Duration(seconds: 25),
  followRedirects: true,
  maxRedirects: 8,
  validateStatus: (s) => s != null && s < 500,
));

Future<Response<String>> _get(String url, {String ua = _ua}) => _http.get<String>(
      url,
      options: Options(
        responseType: ResponseType.plain,
        headers: {
          'User-Agent': ua,
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept': 'text/html,application/json,*/*',
        },
      ),
    );

String _htmlDecode(String s) => s
    .replaceAll('&amp;', '&')
    .replaceAll('&quot;', '"')
    .replaceAll('&#39;', "'")
    .replaceAll('&#x27;', "'")
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>');

/// قيمة وسم <meta property="prop" content="...">
String? _meta(String html, String prop) {
  final a = RegExp(
      r'''<meta[^>]+(?:property|name)=["']''' + prop + r'''["'][^>]*?content=["']([^"']*)["']''',
      caseSensitive: false);
  final b = RegExp(
      r'''<meta[^>]+content=["']([^"']*)["'][^>]*?(?:property|name)=["']''' + prop + r'''["']''',
      caseSensitive: false);
  final v = (a.firstMatch(html) ?? b.firstMatch(html))?.group(1);
  return (v == null || v.isEmpty) ? null : _htmlDecode(v);
}

String _clean(String v) => _htmlDecode(v
    .replaceAll(RegExp(r'\\+u0026'), '&')
    .replaceAll(RegExp(r'\\+u0025'), '%')
    .replaceAll(RegExp(r'\\+u003d', caseSensitive: false), '=')
    .replaceAll(RegExp(r'\\+/'), '/')
    .replaceAll('\\', ''));

/// يبحث عن "key":"value" داخل JSON مضمّن (سواء كان مهرّبًا أو لا).
String? _loose(String h, String key) {
  final m = RegExp(r'(?<![A-Za-z_])' + key + r'\\*"\s*:\s*\\*"(.*?)\\*"\s*[,}\]]').firstMatch(h);
  final v = m?.group(1);
  if (v == null || v.isEmpty) return null;
  final c = _clean(v);
  return c.startsWith('http') ? c : null;
}

String? _looseText(String h, String key) {
  final m = RegExp(r'(?<![A-Za-z_])' + key + r'\\*"\s*:\s*\\*"(.*?)\\*"\s*[,}\]]').firstMatch(h);
  final v = m?.group(1);
  return (v == null || v.isEmpty) ? null : _clean(v);
}

Future<int?> _size(String url) async {
  try {
    final r = await _http.head(
      url,
      options: Options(
        headers: {'User-Agent': _ua},
        receiveTimeout: const Duration(seconds: 6),
      ),
    );
    final v = r.headers.value(Headers.contentLengthHeader);
    return v == null ? null : int.tryParse(v);
  } catch (_) {
    return null;
  }
}

int? _int(Object? v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}');

String _oneLine(String s, {int max = 100}) {
  final t = s.replaceAll(RegExp(r'\s+'), ' ').trim();
  return t.length > max ? '${t.substring(0, max).trim()}…' : t;
}

// ───────────────────────── TikTok ─────────────────────────
class TikTokExtractor implements Extractor {
  @override
  bool supports(Site s) => s == Site.tiktok;

  @override
  Future<MediaInfo> analyze(String url) async {
    var link = url.trim();
    if (RegExp(r'(vm|vt)\.tiktok\.com|tiktok\.com/t/').hasMatch(link)) {
      try {
        final r = await _get(link);
        link = r.realUri.toString();
      } catch (_) {}
    }

    Map? data;
    try {
      final r = await _http.get<dynamic>(
        'https://www.tikwm.com/api/',
        queryParameters: {'url': link, 'hd': 1},
        options: Options(headers: {'User-Agent': _ua}),
      );
      var body = r.data;
      if (body is String) body = jsonDecode(body);
      if (body is Map && body['code'] == 0 && body['data'] is Map) data = body['data'] as Map;
    } catch (_) {}

    if (data == null) {
      throw ExtractorException('تعذّر تحليل رابط تيك توك (قد يكون خاصًا أو محذوفًا، أو الخدمة مشغولة). حاول بعد قليل.');
    }

    String abs(Object? u) {
      final s = '${u ?? ''}';
      if (s.isEmpty) return '';
      return s.startsWith('http') ? s : 'https://www.tikwm.com$s';
    }

    final hd = abs(data['hdplay']);
    final sd = abs(data['play']);
    final music = abs(data['music']);
    final opts = <MediaOption>[];
    if (hd.isNotEmpty) {
      opts.add(MediaOption(
          id: 'hd', label: 'HD بدون علامة مائية', audioOnly: false, container: 'mp4', url: hd, sizeBytes: _int(data['hd_size'])));
    }
    if (sd.isNotEmpty && sd != hd) {
      opts.add(MediaOption(
          id: 'sd', label: 'SD بدون علامة مائية', audioOnly: false, container: 'mp4', url: sd, sizeBytes: _int(data['size'])));
    }
    if (music.isNotEmpty) {
      opts.add(MediaOption(id: 'mp3', label: 'MP3 الصوت الأصلي', audioOnly: true, container: 'mp3', url: music));
    }
    if (opts.isEmpty) {
      throw ExtractorException('هذا المنشور لا يحتوي فيديو قابلًا للتنزيل (ربما صور فقط).');
    }

    final author = data['author'];
    final title = _oneLine('${data['title'] ?? ''}');
    return MediaInfo(
      sourceUrl: url,
      site: Site.tiktok,
      title: title.isEmpty ? 'TikTok ${data['id'] ?? ''}'.trim() : title,
      author: author is Map ? '${author['nickname'] ?? author['unique_id'] ?? ''}' : null,
      thumbnail: abs(data['cover']),
      duration: data['duration'] is num ? Duration(seconds: (data['duration'] as num).round()) : null,
      options: opts,
    );
  }
}

// ───────────────────────── Instagram ─────────────────────────
class InstagramExtractor implements Extractor {
  @override
  bool supports(Site s) => s == Site.instagram;

  @override
  Future<MediaInfo> analyze(String url) async {
    final m = RegExp(r'instagram\.com/(?:[A-Za-z0-9_.]+/)?(p|reel|reels|tv)/([A-Za-z0-9_-]+)').firstMatch(url);
    if (m == null) {
      throw ExtractorException('استخدم رابط منشور أو ريلز (القصص والحسابات غير مدعومة).');
    }
    final code = m.group(2)!;
    final kind = m.group(1) == 'reels' ? 'reel' : m.group(1)!;

    String? video, image, title, author;

    try {
      final r = await _get('https://www.instagram.com/$kind/$code/embed/captioned/');
      final h = r.data ?? '';
      video = _loose(h, 'video_url');
      image = _loose(h, 'display_url') ?? _loose(h, 'thumbnail_src');
      author = _looseText(h, 'username');
      final embedImg = RegExp(r'EmbeddedMediaImage"[^>]*?src="([^"]+)"').firstMatch(h)?.group(1);
      if (image == null && embedImg != null) image = _htmlDecode(embedImg);
    } catch (_) {}

    if (video == null) {
      try {
        final r = await _get('https://www.instagram.com/$kind/$code/', ua: _botUa);
        final h = r.data ?? '';
        video = _meta(h, 'og:video') ?? _meta(h, 'og:video:secure_url');
        image ??= _meta(h, 'og:image');
        title = _meta(h, 'og:title');
      } catch (_) {}
    }

    final name = _oneLine(title ?? (author != null ? 'Instagram - $author' : 'Instagram $code'));
    final opts = <MediaOption>[];
    if (video != null) {
      opts.add(MediaOption(
        id: 'ig',
        label: 'أعلى جودة متاحة',
        audioOnly: false,
        container: 'mp4',
        url: video,
        sizeBytes: await _size(video),
      ));
    } else if (kind == 'p' && image != null) {
      opts.add(MediaOption(
        id: 'ig-img',
        label: 'الصورة / الغلاف',
        audioOnly: false,
        container: 'jpg',
        url: image,
        sizeBytes: await _size(image),
      ));
    }
    if (opts.isEmpty) {
      throw ExtractorException(
          'تعذّر استخراج الوسائط. غالبًا الحساب خاص أو المنشور يتطلب تسجيل الدخول، أو غيّرت إنستغرام صفحتها.');
    }
    return MediaInfo(
      sourceUrl: url,
      site: Site.instagram,
      title: name,
      author: author,
      thumbnail: image,
      options: opts,
    );
  }
}

// ───────────────────────── Facebook ─────────────────────────
class _Try {
  final String url;
  final String ua;
  const _Try(this.url, this.ua);
}

class FacebookExtractor implements Extractor {
  @override
  bool supports(Site s) => s == Site.facebook;

  @override
  Future<MediaInfo> analyze(String url) async {
    var link = url.trim();
    if (link.contains('fb.watch') || link.contains('/share/')) {
      try {
        final r = await _get(link, ua: _desktopUa);
        link = r.realUri.toString();
      } catch (_) {}
    }

    String? hd, sd, title, thumb;
    final tries = <_Try>[
      _Try(link, _desktopUa),
      _Try(link, _ua),
      _Try(link, _botUa),
      _Try(link.replaceFirst(RegExp(r'//(www|web)\.facebook\.com'), '//mbasic.facebook.com'), _ua),
    ];

    for (final t in tries) {
      try {
        final r = await _get(t.url, ua: t.ua);
        final h = r.data ?? '';
        hd ??= _loose(h, 'browser_native_hd_url') ?? _loose(h, 'playable_url_quality_hd') ?? _loose(h, 'hd_src');
        sd ??= _loose(h, 'browser_native_sd_url') ??
            _loose(h, 'playable_url') ??
            _loose(h, 'sd_src') ??
            _meta(h, 'og:video') ??
            _meta(h, 'og:video:secure_url');
        title ??= _meta(h, 'og:title');
        thumb ??= _meta(h, 'og:image');
        if (hd != null || sd != null) break;
      } catch (_) {}
    }

    final opts = <MediaOption>[];
    if (hd != null) {
      opts.add(MediaOption(
          id: 'fb-hd', label: 'HD', audioOnly: false, container: 'mp4', url: hd, sizeBytes: await _size(hd)));
    }
    if (sd != null && sd != hd) {
      opts.add(MediaOption(
          id: 'fb-sd', label: 'SD', audioOnly: false, container: 'mp4', url: sd, sizeBytes: await _size(sd)));
    }
    if (opts.isEmpty) {
      throw ExtractorException('تعذّر استخراج الفيديو. غالبًا المنشور خاص أو يتطلب تسجيل الدخول، أو الرابط ليس فيديو.');
    }
    return MediaInfo(
      sourceUrl: url,
      site: Site.facebook,
      title: _oneLine(title ?? 'Facebook video'),
      thumbnail: thumb,
      options: opts,
    );
  }
}
