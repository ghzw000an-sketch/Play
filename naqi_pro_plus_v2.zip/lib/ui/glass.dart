import 'dart:ui';
import 'package:flutter/material.dart';

/// Lightweight "liquid glass": backdrop blur + translucent gradient + hairline border.
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const Glass({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.radius = 24});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(dark ? 0.12 : 0.55),
                Colors.white.withOpacity(dark ? 0.04 : 0.25),
              ],
            ),
            border: Border.all(color: Colors.white.withOpacity(dark ? 0.18 : 0.6), width: 1),
          ),
          child: child,
        ),
      ),
    );
  }
}

/// خلفية التطبيق: تدرّج لوني، أو أسود خالص عند تفعيل AMOLED.
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final black = cs.surface == Colors.black;
    return Container(
      decoration: BoxDecoration(
        color: black ? Colors.black : null,
        gradient: black
            ? null
            : LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [cs.primaryContainer, cs.surface, cs.tertiaryContainer.withOpacity(0.5)],
              ),
      ),
      child: child,
    );
  }
}
