import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import 'downloads_page.dart';
import 'glass.dart';
import 'home_page.dart';
import 'library_page.dart';
import 'settings_page.dart';

class Shell extends ConsumerWidget {
  const Shell({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = ref.watch(tabProvider);
    final active = ref
        .watch(downloadManagerProvider)
        .where((t) => t.state == TaskState.running || t.state == TaskState.queued || t.state == TaskState.paused)
        .length;

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: IndexedStack(
            index: index,
            children: const [HomePage(), DownloadsPage(), LibraryPage(), SettingsPage()],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => ref.read(tabProvider.notifier).state = i,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.download_rounded), label: 'تنزيل'),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: active > 0,
              label: Text('$active'),
              child: const Icon(Icons.downloading_rounded),
            ),
            label: 'الجارية',
          ),
          const NavigationDestination(icon: Icon(Icons.video_library_rounded), label: 'المكتبة'),
          const NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
