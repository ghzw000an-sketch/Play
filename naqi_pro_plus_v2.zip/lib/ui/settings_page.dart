import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import 'glass.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    final lib = ref.watch(libraryProvider);
    final total = lib.fold<int>(0, (a, i) => a + i.sizeBytes);
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    Widget section(String title, List<Widget> children) => Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Glass(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
                child: Text(title, style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              ),
              ...children,
            ]),
          ),
        );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('الإعدادات', style: tt.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        section('المظهر', [
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('تلقائي')),
                ButtonSegment(value: ThemeMode.light, label: Text('فاتح')),
                ButtonSegment(value: ThemeMode.dark, label: Text('داكن')),
              ],
              selected: {s.themeMode},
              onSelectionChanged: (v) => n.change(themeMode: v.first),
            ),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('وضع AMOLED الأسود'),
            subtitle: const Text('خلفية سوداء خالصة في الوضع الداكن'),
            value: s.amoled,
            onChanged: (v) => n.change(amoled: v),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
            child: Wrap(spacing: 12, runSpacing: 12, children: [
              for (final c in accentSeeds)
                GestureDetector(
                  onTap: () => n.change(seed: c),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Color(c),
                      shape: BoxShape.circle,
                      border: Border.all(color: s.seed == c ? cs.onSurface : Colors.transparent, width: 3),
                    ),
                    child: s.seed == c ? const Icon(Icons.check, color: Colors.white) : null,
                  ),
                ),
            ]),
          ),
        ]),
        section('التنزيل', [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text('عدد التنزيلات المتزامنة', style: tt.bodyLarge),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 1, label: Text('1')),
                ButtonSegment(value: 2, label: Text('2')),
                ButtonSegment(value: 3, label: Text('3')),
                ButtonSegment(value: 4, label: Text('4')),
              ],
              selected: {s.maxParallel},
              onSelectionChanged: (v) => n.change(maxParallel: v.first),
            ),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('تنزيل تلقائي بأعلى جودة'),
            subtitle: const Text('يبدأ التنزيل فور تحليل الرابط دون اختيار'),
            value: s.bestQuality,
            onChanged: (v) => n.change(bestQuality: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('تحليل الروابط المنسوخة تلقائيًا'),
            subtitle: const Text('عند فتح التطبيق وفي الحافظة رابط مدعوم'),
            value: s.autoAnalyze,
            onChanged: (v) => n.change(autoAnalyze: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('حفظ تلقائي في الاستوديو'),
            subtitle: const Text('ينسخ كل فيديو مكتمل إلى ألبوم Naqi'),
            value: s.autoGallery,
            onChanged: (v) => n.change(autoGallery: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('الاهتزاز عند اللمس'),
            value: s.haptics,
            onChanged: (v) => n.change(haptics: v),
          ),
        ]),
        section('التخزين', [
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: const Icon(Icons.storage_rounded),
            title: Text('${lib.length} ملف • ${fmtBytes(total)}'),
            subtitle: const Text('داخل مجلد التطبيق (Naqi)'),
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: Icon(Icons.delete_sweep_outlined, color: cs.error),
            title: Text('حذف كل الملفات المحمّلة', style: TextStyle(color: cs.error)),
            enabled: lib.isNotEmpty,
            onTap: () async {
              final yes = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('حذف الكل'),
                  content: const Text('سيتم حذف جميع الملفات المحمّلة من الجهاز نهائيًا.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                    FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف الكل')),
                  ],
                ),
              );
              if (yes == true) await ref.read(libraryProvider.notifier).clearAll();
            },
          ),
        ]),
        section('حول التطبيق', [
          const ListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 4),
            leading: Icon(Icons.info_outline),
            title: Text('نقي Pro Plus'),
            subtitle: Text('الإصدار 0.2.0'),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              'المنصات المدعومة: يوتيوب، تيك توك، إنستغرام، فيسبوك (الروابط العامة فقط). '
              'قد تتوقف بعض المنصات عن العمل مؤقتًا إذا غيّرت تصميم صفحاتها. '
              'يُمنع استخدام التطبيق لانتهاك حقوق النشر أو خصوصية الآخرين.',
              style: tt.bodySmall,
            ),
          ),
        ]),
      ],
    );
  }
}
