import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../core/models.dart';

const _ua =
    'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';

typedef DoneCallback = Future<void> Function(DownloadTask task, String? thumbPath);

/// مدير التنزيل: طابور + عدد متوازٍ + إيقاف/استئناف (HTTP Range) + إلغاء + إعادة محاولة.
/// تُحفظ الملفات في <مجلد التطبيق>/Naqi/<المنصة>/ (لا يحتاج صلاحيات).
class DownloadManager extends StateNotifier<List<DownloadTask>> {
  DownloadManager({required this.maxParallel, required this.onDone}) : super(const []);

  final int Function() maxParallel;
  final DoneCallback onDone;
  final _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 20),
    receiveTimeout: const Duration(seconds: 60),
  ));
  final _cancel = <String, CancelToken>{};
  final _pausing = <String>{};

  Future<void> enqueue(MediaInfo info, MediaOption opt) async {
    final t = DownloadTask(id: DateTime.now().microsecondsSinceEpoch.toString(), info: info, option: opt);
    state = [...state, t];
    _pump();
  }

  void _update(String id, DownloadTask Function(DownloadTask) f) {
    state = [for (final t in state) t.id == id ? f(t) : t];
  }

  void _pump() {
    final running = state.where((t) => t.state == TaskState.running).length;
    var free = maxParallel() - running;
    for (final t in state.where((t) => t.state == TaskState.queued)) {
      if (free-- <= 0) break;
      _run(t.id);
    }
  }

  Future<String> _uniquePath(DownloadTask t) async {
    final base = (await getExternalStorageDirectory()) ?? await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/Naqi/${siteName(t.info.site)}');
    await dir.create(recursive: true);
    var safe = t.info.title.replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (safe.isEmpty) safe = 'naqi';
    if (safe.length > 70) safe = safe.substring(0, 70).trim();
    final ext = t.option.container;
    var path = '${dir.path}/$safe.$ext';
    var n = 2;
    while (await File(path).exists()) {
      path = '${dir.path}/$safe ($n).$ext';
      n++;
    }
    await File(path).create(); // نحجز الاسم حتى لا يتعارض مع تنزيل متوازٍ
    return path;
  }

  Future<void> _run(String id) async {
    final t = state.firstWhere((e) => e.id == id);
    _update(id, (e) => e.copyWith(state: TaskState.running, error: ''));
    final token = CancelToken();
    _cancel[id] = token;
    try {
      final path = t.targetPath ?? await _uniquePath(t);
      if (t.targetPath == null) _update(id, (e) => e.copyWith(targetPath: path));
      final file = File(path);
      var start = await file.exists() ? await file.length() : 0;

      final res = await _dio.get<ResponseBody>(
        t.option.url,
        cancelToken: token,
        options: Options(
          responseType: ResponseType.stream,
          headers: {
            'User-Agent': _ua,
            ...t.option.headers,
            if (start > 0) 'Range': 'bytes=$start-',
          },
        ),
      );
      final partial = res.statusCode == 206;
      if (!partial) start = 0;
      final len = int.tryParse(res.headers.value(Headers.contentLengthHeader) ?? '');
      final total = len == null ? t.option.sizeBytes : len + start;
      final sink = file.openSync(mode: partial ? FileMode.append : FileMode.write);
      var got = start;
      try {
        await for (final chunk in res.data!.stream) {
          sink.writeFromSync(chunk);
          got += chunk.length;
          _update(id, (e) => e.copyWith(received: got, total: total));
        }
      } finally {
        sink.closeSync();
      }
      if (got == 0) throw Exception('الملف فارغ (قد يكون الرابط منتهي الصلاحية).');
      _update(id, (e) => e.copyWith(state: TaskState.done, filePath: path, received: got));

      final thumb = await _fetchThumb(t, path);
      try {
        await onDone(state.firstWhere((e) => e.id == id), thumb);
      } catch (_) {}
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) {
        if (_pausing.remove(id)) {
          _update(id, (x) => x.copyWith(state: TaskState.paused));
        }
      } else {
        _update(id, (x) => x.copyWith(state: TaskState.failed, error: 'خطأ في الشبكة، حاول مجددًا.'));
      }
    } catch (e) {
      _update(id, (x) => x.copyWith(state: TaskState.failed, error: '$e'));
    } finally {
      _cancel.remove(id);
      _pump();
    }
  }

  Future<String?> _fetchThumb(DownloadTask t, String path) async {
    final u = t.info.thumbnail;
    if (u == null || u.isEmpty) return null;
    try {
      final p = '$path.jpg';
      await _dio.download(u, p,
          options: Options(headers: {'User-Agent': _ua}, receiveTimeout: const Duration(seconds: 15)));
      return p;
    } catch (_) {
      return null;
    }
  }

  void pause(String id) {
    _pausing.add(id);
    _cancel[id]?.cancel('pause');
  }

  void resume(String id) {
    _update(id, (e) => e.copyWith(state: TaskState.queued));
    _pump();
  }

  Future<void> cancel(String id) async {
    final t = state.firstWhere((e) => e.id == id);
    _cancel[id]?.cancel('cancel');
    _update(id, (e) => e.copyWith(state: TaskState.cancelled));
    final p = t.targetPath;
    if (p != null) {
      try {
        final f = File(p);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  void remove(String id) {
    state = state.where((t) => t.id != id).toList();
  }

  void clearFinished() {
    state = state.where((t) => t.state != TaskState.done && t.state != TaskState.cancelled).toList();
  }
}
