import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/settings.dart';
import 'ui/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [prefsProvider.overrideWithValue(prefs)],
    child: const NaqiApp(),
  ));
}

class NaqiApp extends ConsumerWidget {
  const NaqiApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);

    ThemeData theme(Brightness b) {
      var cs = ColorScheme.fromSeed(seedColor: Color(s.seed), brightness: b);
      if (b == Brightness.dark && s.amoled) cs = cs.copyWith(surface: Colors.black);
      return ThemeData(
        useMaterial3: true,
        colorScheme: cs,
        materialTapTargetSize: MaterialTapTargetSize.padded,
      );
    }

    return MaterialApp(
      title: 'نقي Pro Plus',
      debugShowCheckedModeBanner: false,
      theme: theme(Brightness.light),
      darkTheme: theme(Brightness.dark),
      themeMode: s.themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const Shell(),
    );
  }
}
