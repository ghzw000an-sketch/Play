enum Site { youtube, tiktok, instagram, facebook, unknown }

Site detectSite(String url) {
  final u = url.toLowerCase();
  if (u.contains('youtube.com') || u.contains('youtu.be')) return Site.youtube;
  if (u.contains('tiktok.com')) return Site.tiktok;
  if (u.contains('instagram.com') || u.contains('instagr.am')) return Site.instagram;
  if (u.contains('facebook.com') || u.contains('fb.watch') || u.contains('fb.com') || u.contains('fb.me')) {
    return Site.facebook;
  }
  return Site.unknown;
}

String siteName(Site s) => switch (s) {
      Site.youtube => 'YouTube',
      Site.tiktok => 'TikTok',
      Site.instagram => 'Instagram',
      Site.facebook => 'Facebook',
      Site.unknown => 'Other',
    };

class MediaOption {
  final String id;
  final String label;
  final bool audioOnly;
  final String container; // mp4 / m4a / mp3 / jpg
  final int? sizeBytes;
  final String url;
  final Map<String, String> headers;
  const MediaOption({
    required this.id,
    required this.label,
    required this.audioOnly,
    required this.container,
    required this.url,
    this.sizeBytes,
    this.headers = const {},
  });
}

class MediaInfo {
  final String sourceUrl;
  final Site site;
  final String title;
  final String? author;
  final String? thumbnail;
  final Duration? duration;
  final List<MediaOption> options;
  const MediaInfo({
    required this.sourceUrl,
    required this.site,
    required this.title,
    required this.options,
    this.author,
    this.thumbnail,
    this.duration,
  });

  /// أعلى جودة فيديو (أو أول خيار إن لم يوجد فيديو).
  MediaOption get best => options.firstWhere((o) => !o.audioOnly, orElse: () => options.first);
}

enum TaskState { queued, running, paused, done, failed, cancelled }

class DownloadTask {
  final String id;
  final MediaInfo info;
  final MediaOption option;
  final TaskState state;
  final int received;
  final int? total;
  final String? targetPath;
  final String? filePath;
  final String? error;
  const DownloadTask({
    required this.id,
    required this.info,
    required this.option,
    this.state = TaskState.queued,
    this.received = 0,
    this.total,
    this.targetPath,
    this.filePath,
    this.error,
  });

  double? get progress =>
      (total == null || total == 0) ? null : (received / total!).clamp(0, 1).toDouble();

  DownloadTask copyWith({
    TaskState? state,
    int? received,
    int? total,
    String? targetPath,
    String? filePath,
    String? error,
  }) =>
      DownloadTask(
        id: id,
        info: info,
        option: option,
        state: state ?? this.state,
        received: received ?? this.received,
        total: total ?? this.total,
        targetPath: targetPath ?? this.targetPath,
        filePath: filePath ?? this.filePath,
        error: error ?? this.error,
      );
}

/// عنصر محفوظ في المكتبة (بعد اكتمال التنزيل).
class LibraryItem {
  final String id;
  final String title;
  final String site;
  final String filePath;
  final bool audioOnly;
  final int sizeBytes;
  final String label;
  final String? thumbPath;
  final String? sourceUrl;
  final String? author;
  final DateTime createdAt;
  final bool favorite;
  final int? durationSec;

  const LibraryItem({
    required this.id,
    required this.title,
    required this.site,
    required this.filePath,
    required this.audioOnly,
    required this.sizeBytes,
    required this.label,
    required this.createdAt,
    this.thumbPath,
    this.sourceUrl,
    this.author,
    this.favorite = false,
    this.durationSec,
  });

  bool get isImage {
    final p = filePath.toLowerCase();
    return p.endsWith('.jpg') || p.endsWith('.jpeg') || p.endsWith('.png') || p.endsWith('.webp');
  }

  LibraryItem copyWith({String? title, String? filePath, bool? favorite}) => LibraryItem(
        id: id,
        title: title ?? this.title,
        site: site,
        filePath: filePath ?? this.filePath,
        audioOnly: audioOnly,
        sizeBytes: sizeBytes,
        label: label,
        createdAt: createdAt,
        thumbPath: thumbPath,
        sourceUrl: sourceUrl,
        author: author,
        favorite: favorite ?? this.favorite,
        durationSec: durationSec,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'site': site,
        'filePath': filePath,
        'audioOnly': audioOnly,
        'sizeBytes': sizeBytes,
        'label': label,
        'thumbPath': thumbPath,
        'sourceUrl': sourceUrl,
        'author': author,
        'createdAt': createdAt.millisecondsSinceEpoch,
        'favorite': favorite,
        'durationSec': durationSec,
      };

  factory LibraryItem.fromJson(Map<String, dynamic> j) => LibraryItem(
        id: j['id'] as String,
        title: (j['title'] ?? '') as String,
        site: (j['site'] ?? '') as String,
        filePath: j['filePath'] as String,
        audioOnly: j['audioOnly'] == true,
        sizeBytes: (j['sizeBytes'] as num?)?.toInt() ?? 0,
        label: (j['label'] ?? '') as String,
        thumbPath: j['thumbPath'] as String?,
        sourceUrl: j['sourceUrl'] as String?,
        author: j['author'] as String?,
        createdAt: DateTime.fromMillisecondsSinceEpoch((j['createdAt'] as num?)?.toInt() ?? 0),
        favorite: j['favorite'] == true,
        durationSec: (j['durationSec'] as num?)?.toInt(),
      );
}

String fmtBytes(int? b) {
  if (b == null) return '—';
  const u = ['B', 'KB', 'MB', 'GB'];
  var v = b.toDouble();
  var i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return '${v.toStringAsFixed(i == 0 ? 0 : 1)} ${u[i]}';
}

String fmtDuration(Duration? d) {
  if (d == null) return '';
  String two(int n) => n.toString().padLeft(2, '0');
  final h = d.inHours;
  return h > 0
      ? '$h:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}'
      : '${d.inMinutes}:${two(d.inSeconds % 60)}';
}

String fmtDate(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}/${two(d.month)}/${two(d.day)}';
}

String stateAr(TaskState s) => switch (s) {
      TaskState.queued => 'في الانتظار',
      TaskState.running => 'جارٍ التنزيل',
      TaskState.paused => 'متوقف مؤقتًا',
      TaskState.done => 'اكتمل',
      TaskState.failed => 'فشل',
      TaskState.cancelled => 'أُلغي',
    };
