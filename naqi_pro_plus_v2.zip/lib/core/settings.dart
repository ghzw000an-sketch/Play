import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

final prefsProvider = Provider<SharedPreferences>((ref) => throw UnimplementedError('prefs not loaded'));

const accentSeeds = <int>[0xFF6C4CF5, 0xFF0E7C86, 0xFFE4572E, 0xFF2E9E5B, 0xFFD6336C, 0xFF1C7ED6];

class AppSettings {
  final ThemeMode themeMode;
  final int seed;
  final bool amoled;
  final int maxParallel;
  final bool autoGallery;
  final bool autoAnalyze;
  final bool haptics;
  final bool bestQuality;
  const AppSettings({
    this.themeMode = ThemeMode.system,
    this.seed = 0xFF6C4CF5,
    this.amoled = false,
    this.maxParallel = 2,
    this.autoGallery = false,
    this.autoAnalyze = false,
    this.haptics = true,
    this.bestQuality = false,
  });

  AppSettings copyWith({
    ThemeMode? themeMode,
    int? seed,
    bool? amoled,
    int? maxParallel,
    bool? autoGallery,
    bool? autoAnalyze,
    bool? haptics,
    bool? bestQuality,
  }) =>
      AppSettings(
        themeMode: themeMode ?? this.themeMode,
        seed: seed ?? this.seed,
        amoled: amoled ?? this.amoled,
        maxParallel: maxParallel ?? this.maxParallel,
        autoGallery: autoGallery ?? this.autoGallery,
        autoAnalyze: autoAnalyze ?? this.autoAnalyze,
        haptics: haptics ?? this.haptics,
        bestQuality: bestQuality ?? this.bestQuality,
      );
}

class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier(this._p) : super(_load(_p));
  final SharedPreferences _p;

  static AppSettings _load(SharedPreferences p) => AppSettings(
        themeMode: ThemeMode.values[(p.getInt('themeMode') ?? 0).clamp(0, 2)],
        seed: p.getInt('seed') ?? 0xFF6C4CF5,
        amoled: p.getBool('amoled') ?? false,
        maxParallel: (p.getInt('maxParallel') ?? 2).clamp(1, 4),
        autoGallery: p.getBool('autoGallery') ?? false,
        autoAnalyze: p.getBool('autoAnalyze') ?? false,
        haptics: p.getBool('haptics') ?? true,
        bestQuality: p.getBool('bestQuality') ?? false,
      );

  void change({
    ThemeMode? themeMode,
    int? seed,
    bool? amoled,
    int? maxParallel,
    bool? autoGallery,
    bool? autoAnalyze,
    bool? haptics,
    bool? bestQuality,
  }) {
    state = state.copyWith(
      themeMode: themeMode,
      seed: seed,
      amoled: amoled,
      maxParallel: maxParallel,
      autoGallery: autoGallery,
      autoAnalyze: autoAnalyze,
      haptics: haptics,
      bestQuality: bestQuality,
    );
    _p.setInt('themeMode', state.themeMode.index);
    _p.setInt('seed', state.seed);
    _p.setBool('amoled', state.amoled);
    _p.setInt('maxParallel', state.maxParallel);
    _p.setBool('autoGallery', state.autoGallery);
    _p.setBool('autoAnalyze', state.autoAnalyze);
    _p.setBool('haptics', state.haptics);
    _p.setBool('bestQuality', state.bestQuality);
  }
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, AppSettings>((ref) => SettingsNotifier(ref.watch(prefsProvider)));

void haptic(WidgetRef ref, {bool strong = false}) {
  if (!ref.read(settingsProvider).haptics) return;
  strong ? HapticFeedback.mediumImpact() : HapticFeedback.lightImpact();
}
