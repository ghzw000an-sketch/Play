# Naqi Pro Plus — Roadmap

**Done (v0.2.0):** 4 tabs (Download / Active / Library / Settings), TikTok + Instagram + Facebook + YouTube extractors (pure Dart),
batch links, library (play, share, save to gallery, rename, favorite, delete, multi-select, search, sort, details),
settings (theme, AMOLED, accent colors, parallel downloads, auto best quality, auto clipboard analyze, auto gallery, haptics, storage).

Next:
1. Share-target intent (share from Instagram/TikTok straight into Naqi) + foreground-service notification (Pause/Resume/Cancel).
2. yt-dlp engine (Kotlin/Chaquopy, MethodChannel `naqi/ytdlp`) as a robust fallback when page scraping breaks.
3. FFmpeg: mux video+audio for >720p YouTube, MP3/M4A extraction.
4. Playlists/profiles, scheduling (WorkManager), vault (biometrics), subtitles, Wi-Fi-only mode, speed/ETA in queue.
