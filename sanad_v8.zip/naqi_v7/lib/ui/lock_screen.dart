import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'design.dart';
import 'glass.dart';

/// لوحة إدخال رمز PIN (4 أرقام) مع زر بصمة اختياري.
class LockPad extends StatefulWidget {
  final String title;
  final String? subtitle;
  final int length;
  final Future<String?> Function(String pin) onSubmit; // يرجع رسالة خطأ أو null عند النجاح
  final VoidCallback? onBiometric;
  final VoidCallback? onForgot;
  const LockPad({super.key, required this.title, required this.onSubmit, this.subtitle, this.length = 4, this.onBiometric, this.onForgot});

  @override
  State<LockPad> createState() => _LockPadState();
}

class _LockPadState extends State<LockPad> {
  String _pin = '';
  String? _err;
  bool _busy = false;

  Future<void> _tap(String d) async {
    if (_busy || _pin.length >= widget.length) return;
    HapticFeedback.selectionClick();
    setState(() {
      _pin += d;
      _err = null;
    });
    if (_pin.length == widget.length) {
      _busy = true;
      final e = await widget.onSubmit(_pin);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _pin = '';
        _err = e;
      });
      if (e != null) HapticFeedback.heavyImpact();
    }
  }

  void _back() {
    if (_busy || _pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  Widget _key(Widget child, VoidCallback? onTap) => Padding(
        padding: const EdgeInsets.all(6),
        child: SizedBox(
          width: 76,
          height: 76,
          child: Material(
            color: Colors.white.withOpacity(onTap == null ? 0 : 0.08),
            shape: const CircleBorder(),
            child: InkWell(customBorder: const CircleBorder(), onTap: onTap, child: Center(child: child)),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    Widget digit(String d) => _key(Text(d, style: tt.headlineSmall?.copyWith(fontWeight: FontWeight.w700)), () => _tap(d));
    // الأرقام من اليسار لليمين (1 2 3 …) حتى في الواجهة العربية.
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.lock_rounded, size: 44, color: kMint),
          const SizedBox(height: 12),
          Text(widget.title, style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800), textAlign: TextAlign.center),
          if (widget.subtitle != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(widget.subtitle!, textAlign: TextAlign.center)),
          const SizedBox(height: 20),
          Row(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < widget.length; i++)
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                width: 16,
                height: 16,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _pin.length ? kCyan : Colors.transparent,
                  border: Border.all(color: kCyan, width: 2),
                ),
              ),
          ]),
          SizedBox(
            height: 32,
            child: Center(child: Text(_err ?? '', style: TextStyle(color: Theme.of(context).colorScheme.error))),
          ),
          for (final row in const [
            ['1', '2', '3'],
            ['4', '5', '6'],
            ['7', '8', '9']
          ])
            Row(mainAxisSize: MainAxisSize.min, children: [for (final d in row) digit(d)]),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _key(widget.onBiometric == null ? const SizedBox.shrink() : const Icon(Icons.fingerprint_rounded, size: 32, color: kCyan),
                widget.onBiometric),
            digit('0'),
            _key(const Icon(Icons.backspace_outlined), _back),
          ]),
          if (widget.onForgot != null) TextButton(onPressed: widget.onForgot, child: const Text('نسيت الرمز؟')),
        ]),
      ),
      ),
    );
  }
}

/// إنشاء رمز جديد (إدخالان متطابقان).
class PinSetup extends StatefulWidget {
  final Future<void> Function(String pin) onCreate;
  const PinSetup({super.key, required this.onCreate});
  @override
  State<PinSetup> createState() => _PinSetupState();
}

class _PinSetupState extends State<PinSetup> {
  String? _first;

  @override
  Widget build(BuildContext context) {
    return LockPad(
      key: ValueKey(_first == null),
      title: _first == null ? 'أنشئ رمز الخزنة' : 'أعد إدخال الرمز للتأكيد',
      subtitle: 'رمز من 4 أرقام يحمي الخزنة وقفل التطبيق',
      onSubmit: (pin) async {
        if (_first == null) {
          setState(() => _first = pin);
          return null;
        }
        if (_first != pin) {
          setState(() => _first = null);
          return 'الرمزان غير متطابقين، حاول من جديد';
        }
        await widget.onCreate(pin);
        return null;
      },
    );
  }
}

/// شاشة قفل التطبيق (تغطي كامل الشاشة).
class AppLockScreen extends StatelessWidget {
  final Future<String?> Function(String pin) verify;
  final VoidCallback? onBiometric;
  const AppLockScreen({super.key, required this.verify, this.onBiometric});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: SafeArea(child: LockPad(title: 'سند', subtitle: 'أدخل الرمز لفتح التطبيق', onSubmit: verify, onBiometric: onBiometric)),
      ),
    );
  }
}
