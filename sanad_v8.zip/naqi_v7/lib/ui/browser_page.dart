import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import '../browser/adblock.dart';
import '../browser/browser_store.dart';
import '../core/settings.dart';
import 'design.dart';

class _Tab {
  final String key = UniqueKey().toString();
  InAppWebViewController? c;
  FindInteractionController? find;
  String url;
  String title = '';
  int progress = 0;
  bool incognito;
  final List<String> media = [];
  _Tab(this.url, this.incognito);
}

/// متصفح سند: تبويبات، وضع خفي، حظر إعلانات ونوافذ منبثقة، سكربتات مستخدم، بحث في الصفحة…
/// يعيد (pop) رابط الصفحة عند الضغط على «تحميل» ما لم يُمرَّر onDownload.
class BrowserPage extends ConsumerStatefulWidget {
  final String initialUrl;
  final void Function(String url)? onDownload;
  const BrowserPage({super.key, required this.initialUrl, this.onDownload});
  @override
  ConsumerState<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends ConsumerState<BrowserPage> {
  final List<_Tab> _tabs = [];
  int _cur = 0;
  final _addr = TextEditingController();
  final _addrFocus = FocusNode();
  bool _finding = false;
  final _findCtl = TextEditingController();
  late bool _incognitoDefault;

  _Tab get _t => _tabs[_cur];

  @override
  void initState() {
    super.initState();
    _incognitoDefault = ref.read(settingsProvider).browserIncognito;
    _tabs.add(_Tab(widget.initialUrl, _incognitoDefault));
    _addr.text = widget.initialUrl;
    _addrFocus.addListener(() {
      if (_addrFocus.hasFocus) _addr.selection = TextSelection(baseOffset: 0, extentOffset: _addr.text.length);
    });
  }

  @override
  void dispose() {
    if (_tabs.any((t) => t.incognito)) {
      CookieManager.instance().deleteAllCookies();
      InAppWebViewController.clearAllCache();
    }
    _addr.dispose();
    _addrFocus.dispose();
    _findCtl.dispose();
    super.dispose();
  }

  // ───── التنقل ─────
  String _resolve(String v) {
    final t = v.trim();
    if (t.isEmpty) return '';
    final st = ref.read(settingsProvider);
    if (RegExp(r'^[a-z][a-z0-9+.-]*://', caseSensitive: false).hasMatch(t)) return t;
    if (t.contains('.') && !t.contains(' ')) return '${st.httpsOnly ? 'https' : 'https'}://$t';
    final eng = searchEngines[st.searchEngine.clamp(0, searchEngines.length - 1)];
    return eng.$2 + Uri.encodeComponent(t);
  }

  void _go(String v) {
    final u = _resolve(v);
    if (u.isEmpty) return;
    _addrFocus.unfocus();
    setState(() => _t.url = u);
    _t.c?.loadUrl(urlRequest: URLRequest(url: WebUri(u)));
  }

  void _newTab({String url = '', bool? incognito}) {
    setState(() {
      _tabs.add(_Tab(url, incognito ?? _incognitoDefault));
      _cur = _tabs.length - 1;
      _addr.text = url;
    });
  }

  void _closeTab(int i) {
    if (_tabs.length == 1) {
      Navigator.pop(context);
      return;
    }
    setState(() {
      _tabs.removeAt(i);
      if (_cur >= _tabs.length) _cur = _tabs.length - 1;
      _addr.text = _t.url;
    });
  }

  void _download() {
    final u = _t.url;
    if (u.isEmpty) return;
    if (widget.onDownload != null) {
      widget.onDownload!(u);
      Navigator.pop(context);
    } else {
      Navigator.pop(context, u);
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  // ───── إعدادات صفحة الويب ─────
  InAppWebViewSettings _settings(_Tab t) {
    final st = ref.read(settingsProvider);
    return InAppWebViewSettings(
      javaScriptEnabled: true,
      javaScriptCanOpenWindowsAutomatically: !st.popupBlock,
      supportMultipleWindows: true,
      useShouldOverrideUrlLoading: true,
      mediaPlaybackRequiresUserGesture: false,
      allowsInlineMediaPlayback: true,
      incognito: t.incognito,
      cacheEnabled: !t.incognito,
      domStorageEnabled: true,
      databaseEnabled: !t.incognito,
      textZoom: st.browserTextZoom,
      useWideViewPort: true,
      builtInZoomControls: true,
      displayZoomControls: false,
      supportZoom: true,
      userAgent: st.desktopMode ? desktopUa : null,
      preferredContentMode: st.desktopMode ? UserPreferredContentMode.DESKTOP : UserPreferredContentMode.RECOMMENDED,
      useOnDownloadStart: true,
      useOnLoadResource: false,
      contentBlockers: st.adBlock ? _blockers() : null,
      transparentBackground: false,
    );
  }

  List<ContentBlocker> _blockers() {
    final hosts = adHosts.where((h) => !h.contains('/')).map(RegExp.escape).join('|');
    return [
      ContentBlocker(
        trigger: ContentBlockerTrigger(urlFilter: '.*://([^/]*\\.)?($hosts)(:[0-9]+)?(/.*)?'),
        action: ContentBlockerAction(type: ContentBlockerActionType.BLOCK),
      ),
      ContentBlocker(
        trigger: ContentBlockerTrigger(urlFilter: '.*(/pagead/|/adserver/|/popunder|/popads|/clickunder|/prebid).*'),
        action: ContentBlockerAction(type: ContentBlockerActionType.BLOCK),
      ),
    ];
  }

  Future<void> _injectPageTweaks(InAppWebViewController c, String url) async {
    final st = ref.read(settingsProvider);
    if (st.popupBlock) await c.evaluateJavascript(source: popupGuardJs);
    if (st.adBlock) await c.evaluateJavascript(source: styleInjectJs(cosmeticAdCss, 'sanad-ad'));
    if (st.hideCookieBanners) await c.evaluateJavascript(source: styleInjectJs(cookieBannerCss, 'sanad-cookie'));
    if (st.forceDarkWeb) await c.evaluateJavascript(source: styleInjectJs(darkWebCss, 'sanad-dark'));
    await c.evaluateJavascript(source: mediaSnifferJs);
    for (final s in ref.read(userScriptsProvider)) {
      if (s.appliesTo(url)) await c.evaluateJavascript(source: s.wrapped());
    }
  }

  Future<NavigationActionPolicy> _override(NavigationAction a) async {
    final u = a.request.url;
    if (u == null) return NavigationActionPolicy.ALLOW;
    final scheme = u.scheme.toLowerCase();
    final st = ref.read(settingsProvider);
    if (scheme == 'http' || scheme == 'https') {
      if (st.adBlock && a.isForMainFrame && isAdHost(u.host) && a.hasGesture != true) return NavigationActionPolicy.CANCEL;
      if (st.httpsOnly && scheme == 'http') {
        final https = u.toString().replaceFirst('http://', 'https://');
        _t.c?.loadUrl(urlRequest: URLRequest(url: WebUri(https)));
        return NavigationActionPolicy.CANCEL;
      }
      return NavigationActionPolicy.ALLOW;
    }
    if (scheme == 'about' || scheme == 'blob' || scheme == 'data' || scheme == 'javascript' || scheme == 'file') {
      return NavigationActionPolicy.ALLOW;
    }
    // intent:/market:/تطبيقات خارجية: نمنعها (إعلانات تفتح متاجر) ونبلغ المستخدم.
    _toast('مُنع فتح تطبيق خارجي: $scheme');
    return NavigationActionPolicy.CANCEL;
  }

  // ───── الواجهة ─────
  @override
  Widget build(BuildContext context) {
    final st = ref.watch(settingsProvider);
    final bms = ref.watch(bookmarksProvider);
    final marked = bms.any((b) => b.url == _t.url);
    final dark = Theme.of(context).brightness == Brightness.dark;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (_finding) {
          setState(() => _finding = false);
          _t.find?.clearMatches();
          return;
        }
        if (await _t.c?.canGoBack() ?? false) {
          _t.c!.goBack();
        } else if (_tabs.length > 1) {
          _closeTab(_cur);
        } else if (context.mounted) {
          Navigator.pop(context);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0,
          toolbarHeight: 52,
          leading: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(context)),
          title: Container(
            height: 38,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(dark ? 0.08 : 0.5),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: (_t.incognito ? kPurple : kCyan).withOpacity(0.6)),
            ),
            child: TextField(
              controller: _addr,
              focusNode: _addrFocus,
              keyboardType: TextInputType.url,
              textInputAction: TextInputAction.go,
              textDirection: TextDirection.ltr,
              onSubmitted: _go,
              style: const TextStyle(fontSize: 14),
              decoration: InputDecoration(
                isDense: true,
                border: InputBorder.none,
                hintText: 'ابحث أو اكتب عنوانًا',
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                prefixIcon: Icon(_t.incognito ? Icons.theater_comedy_rounded : (_t.url.startsWith('https') ? Icons.lock_rounded : Icons.public_rounded),
                    size: 18, color: _t.incognito ? kPurple : kCyan),
                suffixIcon: IconButton(
                  padding: EdgeInsets.zero,
                  icon: Icon(marked ? Icons.star_rounded : Icons.star_border_rounded, size: 20, color: marked ? Colors.amber : null),
                  onPressed: _t.url.isEmpty ? null : () => ref.read(bookmarksProvider.notifier).toggle(_t.title, _t.url),
                ),
              ),
            ),
          ),
          actions: [
            IconButton(
              onPressed: _showTabs,
              icon: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                decoration: BoxDecoration(border: Border.all(width: 1.6), borderRadius: BorderRadius.circular(6)),
                child: Text('${_tabs.length}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ),
            IconButton(onPressed: _menu, icon: const Icon(Icons.more_vert_rounded)),
          ],
          bottom: _t.progress < 100 && _t.url.isNotEmpty
              ? PreferredSize(preferredSize: const Size.fromHeight(3), child: LinearProgressIndicator(value: _t.progress / 100, minHeight: 3))
              : null,
        ),
        body: Column(children: [
          if (_finding) _findBar(),
          Expanded(
            child: IndexedStack(
              index: _cur,
              children: [for (var i = 0; i < _tabs.length; i++) _tabView(_tabs[i], i)],
            ),
          ),
          _bottomBar(),
        ]),
        floatingActionButton: _t.url.isEmpty
            ? null
            : FloatingActionButton.extended(
                backgroundColor: kCyan,
                foregroundColor: Colors.black87,
                onPressed: _download,
                icon: const Icon(Icons.download_rounded),
                label: Text(_t.media.isEmpty ? 'تحميل بسند' : 'تحميل بسند (${_t.media.length})'),
              ),
        floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      ),
    );
  }

  Widget _tabView(_Tab t, int i) {
    if (t.url.isEmpty) return _startPage();
    t.find ??= FindInteractionController();
    return InAppWebView(
      key: ValueKey(t.key),
      initialUrlRequest: URLRequest(url: WebUri(t.url)),
      initialSettings: _settings(t),
      findInteractionController: t.find,
      onWebViewCreated: (c) {
        t.c = c;
        c.addJavaScriptHandler(
            handlerName: 'media',
            callback: (args) {
              final list = args.isNotEmpty && args[0] is List ? List<String>.from((args[0] as List).map((e) => '$e')) : <String>[];
              var changed = false;
              for (final u in list) {
                if (!t.media.contains(u)) {
                  t.media.add(u);
                  changed = true;
                }
              }
              if (changed && mounted) setState(() {});
              return null;
            });
      },
      shouldOverrideUrlLoading: (c, a) => _override(a),
      onCreateWindow: (c, a) async {
        final u = a.request.url?.toString() ?? '';
        final st = ref.read(settingsProvider);
        if (st.popupBlock && a.hasGesture == false) {
          _toast('تم حظر نافذة منبثقة');
          return false;
        }
        if (u.isNotEmpty && u != 'about:blank') _newTab(url: u, incognito: t.incognito);
        return false;
      },
      onLoadStart: (c, u) {
        t.media.clear();
        if (u != null) {
          t.url = u.toString();
          if (identical(t, _t) && !_addrFocus.hasFocus) _addr.text = t.url;
        }
        if (mounted) setState(() {});
      },
      onProgressChanged: (c, p) {
        t.progress = p;
        if (identical(t, _t) && mounted) setState(() {});
      },
      onUpdateVisitedHistory: (c, u, _) {
        if (u != null) {
          t.url = u.toString();
          if (identical(t, _t) && !_addrFocus.hasFocus) _addr.text = t.url;
        }
      },
      onTitleChanged: (c, title) {
        t.title = title ?? '';
      },
      onLoadStop: (c, u) async {
        t.progress = 100;
        final url = u?.toString() ?? t.url;
        t.url = url;
        t.title = (await c.getTitle()) ?? t.title;
        if (!t.incognito) ref.read(historyProvider.notifier).add(t.title, url);
        await _injectPageTweaks(c, url);
        if (mounted) setState(() {});
      },
      onReceivedError: (c, r, e) {},
      onDownloadStartRequest: (c, r) {
        _toast('ملف مباشر: ${r.suggestedFilename ?? r.url}');
        _t.media.add(r.url.toString());
        setState(() {});
      },
      onPermissionRequest: (c, r) async => PermissionResponse(resources: r.resources, action: PermissionResponseAction.DENY),
      onLongPressHitTestResult: (c, h) async {
        final extra = h.extra;
        if (extra == null || extra.isEmpty) return;
        switch (h.type) {
          case InAppWebViewHitTestResultType.SRC_ANCHOR_TYPE:
          case InAppWebViewHitTestResultType.SRC_IMAGE_ANCHOR_TYPE:
          case InAppWebViewHitTestResultType.IMAGE_TYPE:
            _linkSheet(extra, image: h.type != InAppWebViewHitTestResultType.SRC_ANCHOR_TYPE);
          default:
        }
      },
    );
  }

  Widget _findBar() => Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
        child: Row(children: [
          Expanded(
            child: TextField(
              controller: _findCtl,
              autofocus: true,
              decoration: const InputDecoration(isDense: true, hintText: 'بحث في الصفحة', prefixIcon: Icon(Icons.search_rounded)),
              onChanged: (v) => v.isEmpty ? _t.find?.clearMatches() : _t.find?.findAll(find: v),
            ),
          ),
          IconButton(icon: const Icon(Icons.keyboard_arrow_up_rounded), onPressed: () => _t.find?.findNext(forward: false)),
          IconButton(icon: const Icon(Icons.keyboard_arrow_down_rounded), onPressed: () => _t.find?.findNext(forward: true)),
          IconButton(
              icon: const Icon(Icons.close_rounded),
              onPressed: () {
                setState(() => _finding = false);
                _t.find?.clearMatches();
              }),
        ]),
      );

  Widget _bottomBar() => SafeArea(
        top: false,
        child: SizedBox(
          height: 44,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18), onPressed: () => _t.c?.goBack()),
            IconButton(icon: const Icon(Icons.arrow_forward_ios_rounded, size: 18), onPressed: () => _t.c?.goForward()),
            IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => _t.c?.reload()),
            IconButton(icon: const Icon(Icons.home_rounded), onPressed: () => setState(() {
                  _t.url = '';
                  _addr.text = '';
                })),
            IconButton(icon: const Icon(Icons.add_circle_outline_rounded), onPressed: () => _newTab()),
          ]),
        ),
      );

  // ───── صفحة البداية ─────
  static const _quick = <(String, String, IconData)>[
    ('YouTube', 'https://m.youtube.com', Icons.smart_display_rounded),
    ('TikTok', 'https://www.tiktok.com', Icons.music_note_rounded),
    ('Instagram', 'https://www.instagram.com', Icons.camera_alt_rounded),
    ('Facebook', 'https://m.facebook.com', Icons.facebook_rounded),
    ('Snapchat', 'https://www.snapchat.com', Icons.chat_bubble_rounded),
    ('Pinterest', 'https://www.pinterest.com', Icons.push_pin_rounded),
    ('X', 'https://x.com', Icons.alternate_email_rounded),
    ('Google', 'https://www.google.com', Icons.search_rounded),
  ];

  Widget _startPage() {
    final bms = ref.watch(bookmarksProvider);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Center(
        child: ShaderMask(
          shaderCallback: (r) => const LinearGradient(colors: [kCyan, kPurple]).createShader(r),
          child: const Text('سند', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: Colors.white)),
        ),
      ),
      Center(child: Text(_t.incognito ? 'تصفّح خفي — لا سجل ولا كوكيز' : 'متصفح سند', style: const TextStyle(fontSize: 12))),
      const SizedBox(height: 20),
      Wrap(spacing: 14, runSpacing: 14, alignment: WrapAlignment.center, children: [
        for (final q in _quick) _tile(q.$1, q.$3, () => _go(q.$2)),
        for (final b in bms.take(8)) _tile(b.title, Icons.star_rounded, () => _go(b.url), color: Colors.amber),
      ]),
    ]);
  }

  Widget _tile(String name, IconData icon, VoidCallback onTap, {Color color = kCyan}) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: SizedBox(
          width: 76,
          child: Column(children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(18), border: Border.all(color: color.withOpacity(0.6))),
              child: Icon(icon, color: color),
            ),
            const SizedBox(height: 6),
            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
          ]),
        ),
      );

  // ───── قوائم ─────
  void _showTabs() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(builder: (ctx, set) {
        return SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              title: Text('التبويبات (${_tabs.length})', style: const TextStyle(fontWeight: FontWeight.bold)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                TextButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _newTab(incognito: true);
                    },
                    icon: const Icon(Icons.theater_comedy_rounded, size: 18),
                    label: const Text('خفي')),
                TextButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _newTab(incognito: false);
                    },
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('جديد')),
              ]),
            ),
            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: _tabs.length,
                itemBuilder: (_, i) {
                  final t = _tabs[i];
                  return ListTile(
                    selected: i == _cur,
                    leading: Icon(t.incognito ? Icons.theater_comedy_rounded : Icons.tab_rounded, color: t.incognito ? kPurple : kCyan),
                    title: Text(t.title.isEmpty ? (t.url.isEmpty ? 'صفحة جديدة' : t.url) : t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(t.url, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr),
                    trailing: IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () {
                          Navigator.pop(ctx);
                          _closeTab(i);
                        }),
                    onTap: () {
                      Navigator.pop(ctx);
                      setState(() {
                        _cur = i;
                        _addr.text = t.url;
                      });
                    },
                  );
                },
              ),
            ),
          ]),
        );
      }),
    );
  }

  void _linkSheet(String url, {bool image = false}) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.all(12), child: Text(url, maxLines: 2, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12))),
          ListTile(leading: const Icon(Icons.open_in_new_rounded), title: const Text('فتح في تبويب جديد'), onTap: () { Navigator.pop(ctx); _newTab(url: url, incognito: _t.incognito); }),
          ListTile(leading: const Icon(Icons.theater_comedy_rounded), title: const Text('فتح في تبويب خفي'), onTap: () { Navigator.pop(ctx); _newTab(url: url, incognito: true); }),
          ListTile(leading: const Icon(Icons.download_rounded), title: const Text('تحميل بسند'), onTap: () {
            Navigator.pop(ctx);
            if (widget.onDownload != null) { widget.onDownload!(url); Navigator.pop(context); } else { Navigator.pop(context, url); }
          }),
          ListTile(leading: const Icon(Icons.copy_rounded), title: const Text('نسخ الرابط'), onTap: () { Clipboard.setData(ClipboardData(text: url)); Navigator.pop(ctx); _toast('تم النسخ'); }),
          ListTile(leading: const Icon(Icons.share_rounded), title: const Text('مشاركة'), onTap: () { Navigator.pop(ctx); Share.share(url); }),
        ]),
      ),
    );
  }

  void _menu() {
    final st = ref.read(settingsProvider);
    final ctl = ref.read(settingsProvider.notifier);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Consumer(builder: (ctx, ref, _) {
        final s = ref.watch(settingsProvider);
        Widget sw(String t, IconData i, bool v, void Function(bool) f) => SwitchListTile(
            dense: true, secondary: Icon(i), title: Text(t), value: v, onChanged: (x) { f(x); _t.c?.reload(); });
        return SafeArea(
          child: ListView(shrinkWrap: true, children: [
            ListTile(leading: const Icon(Icons.share_rounded), title: const Text('مشاركة الصفحة'), onTap: () { Navigator.pop(ctx); if (_t.url.isNotEmpty) Share.share(_t.url); }),
            ListTile(leading: const Icon(Icons.copy_rounded), title: const Text('نسخ الرابط'), onTap: () { Navigator.pop(ctx); Clipboard.setData(ClipboardData(text: _t.url)); _toast('تم النسخ'); }),
            ListTile(leading: const Icon(Icons.search_rounded), title: const Text('بحث في الصفحة'), onTap: () { Navigator.pop(ctx); setState(() => _finding = true); }),
            ListTile(leading: const Icon(Icons.smart_display_rounded), title: Text('وسائط مكتشفة (${_t.media.length})'), onTap: () { Navigator.pop(ctx); _mediaSheet(); }),
            ListTile(leading: const Icon(Icons.bookmarks_rounded), title: const Text('العلامات'), onTap: () { Navigator.pop(ctx); _listSheet(true); }),
            ListTile(leading: const Icon(Icons.history_rounded), title: const Text('السجل'), onTap: () { Navigator.pop(ctx); _listSheet(false); }),
            ListTile(leading: const Icon(Icons.extension_rounded), title: const Text('الإضافات (سكربتات)'), onTap: () { Navigator.pop(ctx); _scriptsSheet(); }),
            ListTile(leading: const Icon(Icons.account_circle_rounded), title: const Text('تسجيل الدخول للمنصات (لتحميل Instagram…)'), onTap: () { Navigator.pop(ctx); _loginSheet(); }),
            const Divider(),
            sw('حظر الإعلانات والمتتبعات', Icons.shield_rounded, s.adBlock, (v) => ctl.change(adBlock: v)),
            sw('حظر النوافذ المنبثقة', Icons.web_asset_off_rounded, s.popupBlock, (v) => ctl.change(popupBlock: v)),
            sw('إخفاء لافتات الكوكيز', Icons.cookie_rounded, s.hideCookieBanners, (v) => ctl.change(hideCookieBanners: v)),
            sw('وضع سطح المكتب', Icons.desktop_windows_rounded, s.desktopMode, (v) => ctl.change(desktopMode: v)),
            sw('الوضع الداكن للمواقع', Icons.dark_mode_rounded, s.forceDarkWeb, (v) => ctl.change(forceDarkWeb: v)),
            sw('HTTPS فقط', Icons.https_rounded, s.httpsOnly, (v) => ctl.change(httpsOnly: v)),
            ListTile(
              leading: const Icon(Icons.format_size_rounded),
              title: Text('حجم النص ${s.browserTextZoom}%'),
              subtitle: Slider(
                min: 60, max: 200, divisions: 14, value: s.browserTextZoom.toDouble().clamp(60, 200),
                onChanged: (v) => ctl.change(browserTextZoom: v.round()),
                onChangeEnd: (v) => _t.c?.setSettings(settings: InAppWebViewSettings(textZoom: v.round())),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.travel_explore_rounded),
              title: const Text('محرك البحث'),
              trailing: DropdownButton<int>(
                value: s.searchEngine.clamp(0, searchEngines.length - 1),
                items: [for (var i = 0; i < searchEngines.length; i++) DropdownMenuItem(value: i, child: Text(searchEngines[i].$1))],
                onChanged: (v) => ctl.change(searchEngine: v),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.cleaning_services_rounded),
              title: const Text('مسح بيانات التصفح'),
              onTap: () async {
                Navigator.pop(ctx);
                await CookieManager.instance().deleteAllCookies();
                await InAppWebViewController.clearAllCache();
                ref.read(historyProvider.notifier).clear();
                _toast('تم مسح الكوكيز والذاكرة المؤقتة والسجل');
              },
            ),
          ]),
        );
      }),
    ).then((_) => setState(() {}));
    // st مستخدم لإبقاء المرجع حيًّا فقط
    st.hashCode;
  }

  void _mediaSheet() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: _t.media.isEmpty
            ? const Padding(padding: EdgeInsets.all(24), child: Text('لم تُكتشف وسائط بعد. شغّل الفيديو ثم أعد المحاولة.'))
            : ListView(shrinkWrap: true, children: [
                for (final u in _t.media)
                  ListTile(
                    dense: true,
                    title: Text(u, maxLines: 2, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12)),
                    trailing: IconButton(icon: const Icon(Icons.copy_rounded), onPressed: () { Clipboard.setData(ClipboardData(text: u)); _toast('تم النسخ'); }),
                    onTap: () { Navigator.pop(ctx); _linkSheet(u); },
                  ),
              ]),
      ),
    );
  }

  void _listSheet(bool bookmarks) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Consumer(builder: (ctx, ref, _) {
        final bms = ref.watch(bookmarksProvider);
        final hist = ref.watch(historyProvider);
        final rows = bookmarks ? [for (final b in bms) (b.title, b.url)] : [for (final h in hist) (h.title, h.url)];
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.7,
            child: Column(children: [
              ListTile(
                title: Text(bookmarks ? 'العلامات' : 'السجل', style: const TextStyle(fontWeight: FontWeight.bold)),
                trailing: bookmarks ? null : TextButton(onPressed: () => ref.read(historyProvider.notifier).clear(), child: const Text('مسح')),
              ),
              Expanded(
                child: rows.isEmpty
                    ? const Center(child: Text('لا شيء هنا بعد'))
                    : ListView.builder(
                        itemCount: rows.length,
                        itemBuilder: (_, i) => ListTile(
                          dense: true,
                          title: Text(rows[i].$1, maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(rows[i].$2, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr),
                          trailing: bookmarks ? IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: () => ref.read(bookmarksProvider.notifier).remove(rows[i].$2)) : null,
                          onTap: () { Navigator.pop(ctx); _go(rows[i].$2); },
                        ),
                      ),
              ),
            ]),
          ),
        );
      }),
    );
  }

  void _scriptsSheet() {
    final urlCtl = TextEditingController();
    final codeCtl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Consumer(builder: (ctx, ref, _) {
        final list = ref.watch(userScriptsProvider);
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SafeArea(
            child: SizedBox(
              height: MediaQuery.of(ctx).size.height * 0.8,
              child: ListView(padding: const EdgeInsets.all(12), children: [
                const Text('الإضافات (سكربتات المستخدم)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 6),
                const Text(
                  'ملاحظة: إضافات Chrome (‎.crx) لا تعمل داخل WebView في أندرويد، لأن المتصفحات المبنية عليه لا تدعم واجهة الإضافات. '
                  'البديل: سكربتات المستخدم (Tampermonkey) — ثبّتها من رابط مثل Greasy Fork (‎.user.js) أو الصق الشيفرة. كثير من إضافات Chrome لها سكربت مكافئ.',
                  style: TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 10),
                TextField(controller: urlCtl, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'رابط سكربت ‎.user.js', prefixIcon: Icon(Icons.link_rounded))),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton.icon(
                    icon: const Icon(Icons.download_rounded),
                    label: const Text('تثبيت من الرابط'),
                    onPressed: () async {
                      try {
                        final s = await ref.read(userScriptsProvider.notifier).install(urlCtl.text.trim());
                        urlCtl.clear();
                        _toast('تم تثبيت: ${s.name}');
                      } catch (e) {
                        _toast('تعذّر التثبيت: $e');
                      }
                    },
                  ),
                ),
                TextField(controller: codeCtl, maxLines: 4, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'أو الصق شيفرة السكربت هنا')),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton.icon(
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('إضافة'),
                    onPressed: () {
                      if (codeCtl.text.trim().isEmpty) return;
                      ref.read(userScriptsProvider.notifier).add(UserScriptItem.parse(codeCtl.text));
                      codeCtl.clear();
                    },
                  ),
                ),
                const Divider(),
                if (list.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('لا توجد سكربتات مثبتة')),
                for (final s in list)
                  SwitchListTile(
                    dense: true,
                    title: Text(s.name),
                    subtitle: Text(s.matches.join('  '), maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr),
                    value: s.enabled,
                    onChanged: (_) => ref.read(userScriptsProvider.notifier).toggle(s.id),
                    secondary: IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: () => ref.read(userScriptsProvider.notifier).remove(s.id)),
                  ),
              ]),
            ),
          ),
        );
      }),
    );
  }

  void _loginSheet() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(
            title: Text('حسابات المنصات', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('سجّل دخولك في المتصفح ثم اضغط «تحديث الكوكيز» ليستخدمها محرك التحميل (يحل خطأ «يتطلب تسجيل الدخول» في Instagram وغيره). تبقى على جهازك فقط.'),
          ),
          for (final s in loginSites)
            ListTile(
              dense: true,
              leading: const Icon(Icons.login_rounded),
              title: Text(s.$1),
              onTap: () {
                Navigator.pop(ctx);
                _newTab(url: s.$2, incognito: false);
              },
            ),
          ListTile(
            leading: const Icon(Icons.sync_rounded, color: kCyan),
            title: const Text('تحديث الكوكيز لمحرك التحميل'),
            onTap: () async {
              Navigator.pop(ctx);
              final n = await exportCookiesToEngine();
              _toast(n == 0 ? 'لا توجد جلسات مسجّلة بعد' : 'تم تمرير $n كوكي إلى محرك التحميل');
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout_rounded),
            title: const Text('إلغاء ربط الحسابات'),
            onTap: () async {
              Navigator.pop(ctx);
              await clearEngineCookies();
              _toast('تم حذف كوكيز المحرك');
            },
          ),
        ]),
      ),
    );
  }
}
