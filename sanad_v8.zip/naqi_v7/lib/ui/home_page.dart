import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart' as yt;
import '../core/auto_download.dart';
import '../core/models.dart';
import '../core/vault.dart';
import '../engine/sys_native.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../engine/extractor_base.dart';
import 'browser_page.dart';
import 'design.dart';
import 'glass.dart';
import 'status_saver_page.dart';

/// وضع MP3: التحليل التالي ينزّل الصوت مباشرة.
final audioModeProvider = StateProvider<bool>((_) => false);

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> with WidgetsBindingObserver {
  final _ctrl = TextEditingController();
  final _bctrl = TextEditingController();
  String? _clipUrl;
  String? _lastHandled;
  bool _batchMode = false;
  final ValueNotifier<bool> _toVault = ValueNotifier(false);
  bool _batchRunning = false;
  final Map<String, String> _batchStatus = {};
  final _yte = yt.YoutubeExplode();
  List<yt.Video>? _results;
  bool _searching = false;
  String? _searchErr;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkClipboard();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ctrl.dispose();
    _bctrl.dispose();
    _toVault.dispose();
    _yte.close();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _checkClipboard();
  }

  Future<void> _checkClipboard() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim();
    if (t == null || !t.startsWith('http') || detectSite(t) == Site.unknown) return;
    if (t == _lastHandled || t == _ctrl.text) return;
    _lastHandled = t;
    if (!mounted || _batchMode) return;
    if (ref.read(settingsProvider).autoAnalyze) {
      _usePasted(t);
    } else {
      setState(() => _clipUrl = t);
    }
  }

  void _usePasted(String url) {
    haptic(ref);
    _ctrl.text = url;
    setState(() {
      _clipUrl = null;
      _results = null;
      _searchErr = null;
    });
    ref.read(analysisProvider.notifier).analyze(url);
  }

  /// رابط → تحليل مباشر، أي نص آخر → بحث في يوتيوب.
  void _submit(String raw) {
    final v = raw.trim();
    if (v.isEmpty) return;
    FocusScope.of(context).unfocus();
    if (v.startsWith('http')) {
      _usePasted(v);
    } else {
      _search(v);
    }
  }

  Future<void> _search(String q) async {
    haptic(ref);
    setState(() {
      _searching = true;
      _results = null;
      _searchErr = null;
    });
    ref.read(analysisProvider.notifier).clear();
    try {
      final r = await _yte.search.search(q);
      if (!mounted) return;
      setState(() => _results = r.take(20).toList());
    } catch (_) {
      if (mounted) setState(() => _searchErr = 'تعذّر البحث. تحقق من الإنترنت.');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim();
    if (t == null || t.isEmpty) return;
    if (_batchMode) {
      _bctrl.text = _bctrl.text.isEmpty ? t : '${_bctrl.text}\n$t';
    } else {
      _usePasted(t);
    }
  }

  Future<void> _enqueue(MediaInfo info, MediaOption opt) async {
    if (ref.read(settingsProvider).wifiOnly && !await Sys.isWifi()) {
      if (mounted) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('«واي فاي فقط» مفعّل — اتصل بالواي فاي أو عطّل الخيار من الإعدادات.')));
      }
      return;
    }
    haptic(ref, strong: true);
    ref.read(downloadManagerProvider.notifier).enqueue(info, opt, toVault: _toVault.value);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: const Text('أُضيف إلى قائمة التنزيل'),
        action: SnackBarAction(label: 'عرض', onPressed: () => ref.read(tabProvider.notifier).state = 1),
      ));
  }

  Future<void> _runBatch() async {
    final urls = _bctrl.text.split(RegExp(r'\s+')).where((u) => u.startsWith('http')).toSet().toList();
    if (urls.isEmpty) return;
    setState(() {
      _batchRunning = true;
      _batchStatus
        ..clear()
        ..addEntries(urls.map((u) => MapEntry(u, 'بالانتظار')));
    });
    final audio = ref.read(audioModeProvider);
    for (final u in urls) {
      if (!mounted) return;
      setState(() => _batchStatus[u] = 'جارٍ التحليل…');
      try {
        final info = await ref.read(extractorProvider).analyze(u);
        final mp3 = info.options.where((o) => o.audioOnly).toList();
        final st = ref.read(settingsProvider);
        ref.read(downloadManagerProvider.notifier).enqueue(
            info, (audio && mp3.isNotEmpty) ? mp3.first : pickOption(info, maxHeight: st.maxQuality),
            toVault: _toVault.value);
        if (mounted) setState(() => _batchStatus[u] = '✓ أُضيف: ${info.title}');
      } catch (e) {
        if (mounted) setState(() => _batchStatus[u] = '✗ ${e is ExtractorException ? e.message : 'تعذّر التحليل'}');
      }
    }
    if (mounted) {
      setState(() => _batchRunning = false);
      haptic(ref, strong: true);
    }
  }

  Future<void> _openBrowser(String url) async {
    final picked = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => BrowserPage(initialUrl: url)));
    if (picked != null && mounted) _usePasted(picked);
  }

  void _platformTap(String name) {
    switch (name) {
      case 'WhatsApp':
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StatusSaverPage()));
      case 'YouTube':
        _openBrowser('https://m.youtube.com');
      case 'TikTok':
        _openBrowser('https://www.tiktok.com');
      case 'Instagram':
        _openBrowser('https://www.instagram.com');
      case 'Snapchat':
        _openBrowser('https://www.snapchat.com');
      case 'Facebook':
        _openBrowser('https://m.facebook.com');
      case 'Pinterest':
        _openBrowser('https://www.pinterest.com');
      case 'X':
        _openBrowser('https://x.com');
    }
  }

  void _vaultDenied() {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: const Text('أنشئ رمز الخزنة أولًا من تبويب الخزنة'),
        action: SnackBarAction(label: 'فتح', onPressed: () => ref.read(tabProvider.notifier).state = 3),
      ));
  }

  void _watermarkInfo() {
    showGlassSheet<void>(
      context,
      (ctx) => ListView(shrinkWrap: true, padding: const EdgeInsets.all(20), children: [
        Row(children: [
          const Icon(Icons.auto_fix_high_rounded, color: kCyan),
          const SizedBox(width: 10),
          Text('نسخة أصلية بلا علامة مائية', style: Theme.of(ctx).textTheme.titleMedium),
        ]),
        const SizedBox(height: 12),
        const Text(
          'يطلب التطبيق من المنصة النسخة الأصلية النظيفة التي تنشرها للعامة (مثل ملف تيك توك الأصلي)، '
          'ويستبعد تلقائيًا أي صيغة معلَّمة بعلامة مائية.\n\n'
          'التطبيق لا يعدّل الفيديوهات ولا يمحو العلامات من ملفات أخرى، ولا يتجاوز الحماية أو المحتوى الخاص.',
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<String?>(incomingLinkProvider, (prev, next) {
      if (next != null) {
        _usePasted(next);
        ref.read(incomingLinkProvider.notifier).state = null;
      }
    });
    ref.listen<AsyncValue<MediaInfo?>>(analysisProvider, (prev, next) {
      final info = next.valueOrNull;
      if (info == null || prev?.valueOrNull == info) return;
      final audio = info.options.where((o) => o.audioOnly).toList();
      if (ref.read(audioModeProvider) && audio.isNotEmpty) {
        _enqueue(info, audio.first);
      } else if (ref.read(settingsProvider).bestQuality) {
        _enqueue(info, pickOption(info, maxHeight: ref.read(settingsProvider).maxQuality, preferAudio: ref.read(settingsProvider).preferAudio));
      }
    });

    final analysis = ref.watch(analysisProvider);
    final audioMode = ref.watch(audioModeProvider);
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    final list = ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      children: [
        const SizedBox(height: 8),
        Row(children: [
          ShaderMask(
            shaderCallback: (r) => LinearGradient(colors: [cs.primary, kPurple]).createShader(r),
            child: Text('سند', style: tt.displaySmall?.copyWith(fontWeight: FontWeight.w900, color: Colors.white, height: 1.1)),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: cs.primary.withOpacity(0.7)),
              color: cs.primary.withOpacity(0.12),
            ),
            child: Text('PRO PLUS', style: tt.labelSmall?.copyWith(color: cs.primary, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
          ),
        ]),
        Text('سندك لتحميل كل ما تحب… بنقاء وجودة احترافية', style: tt.bodyMedium),
        const SizedBox(height: 16),
        SizedBox(
          height: 112,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (final n in platformStyles.keys)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 14),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => _platformTap(n),
                    child: SizedBox(
                      width: 72,
                      child: Column(children: [
                        PlatformBadge(n, size: 60),
                        const SizedBox(height: 6),
                        Text(n, style: tt.labelMedium?.copyWith(fontWeight: FontWeight.w700), maxLines: 1),
                        Text(platformStyles[n]!.sub, style: tt.labelSmall?.copyWith(color: cs.onSurface.withOpacity(0.55)), maxLines: 1, overflow: TextOverflow.ellipsis),
                      ]),
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<bool>(
            showSelectedIcon: true,
            segments: const [
              ButtonSegment(value: false, label: Text('رابط واحد')),
              ButtonSegment(value: true, label: Text('تحميل دفعة روابط (متعدد)')),
            ],
            selected: {_batchMode},
            onSelectionChanged: (s) => setState(() => _batchMode = s.first),
          ),
        ),
        const SizedBox(height: 14),
        if (!_batchMode) ...[
          Glass(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
            child: Column(children: [
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    keyboardType: TextInputType.url,
                    textInputAction: TextInputAction.go,
                    onSubmitted: _submit,
                    decoration: const InputDecoration(
                      hintText: 'الصق رابط الفيديو، الريلز، القصة… أو ابحث في يوتيوب',
                      border: InputBorder.none,
                      prefixIcon: Icon(Icons.link_rounded),
                    ),
                  ),
                ),
                InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: _paste,
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.content_paste_rounded, color: kMint, size: 30),
                      Text('لصق تلقائي', style: tt.labelSmall?.copyWith(color: kMint)),
                    ]),
                  ),
                ),
              ]),
              const SizedBox(height: 10),
              GradientButton(
                label: audioMode ? 'تحليل وتحميل MP3' : 'تحليل وتحميل',
                icon: Icons.search_rounded,
                busy: analysis.isLoading,
                onPressed: () => _submit(_ctrl.text),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          if (_searching) const _Skeleton(),
          if (_searchErr != null) Glass(child: Text(_searchErr!)),
          if (_results != null) ..._resultTiles(),
          analysis.when(
            loading: () => const _Skeleton(),
            error: (e, _) => Glass(
              child: Row(children: [
                Icon(Icons.info_outline, color: cs.error),
                const SizedBox(width: 12),
                Expanded(child: Text('$e')),
              ]),
            ),
            data: (info) => info == null ? const SizedBox.shrink() : _InfoCard(info: info, onPick: _enqueue, toVault: _toVault, onVaultDenied: _vaultDenied),
          ),
        ] else ...[
          Glass(
            child: Column(children: [
              TextField(
                controller: _bctrl,
                minLines: 4,
                maxLines: 8,
                keyboardType: TextInputType.multiline,
                decoration: const InputDecoration(hintText: 'ألصق كل رابط في سطر مستقل', border: InputBorder.none),
              ),
              Row(children: [
                IconButton(tooltip: 'لصق من الحافظة', icon: const Icon(Icons.content_paste_rounded), onPressed: _paste),
                const Spacer(),
                FilledButton.icon(
                  onPressed: _batchRunning ? null : _runBatch,
                  icon: _batchRunning
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download_rounded),
                  label: Text(audioMode ? 'تحميل الكل MP3' : 'تحميل الكل بأعلى جودة'),
                ),
              ]),
            ]),
          ),
          if (_batchStatus.isNotEmpty) ...[
            const SizedBox(height: 12),
            Glass(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                for (final e in _batchStatus.entries)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(e.key, maxLines: 1, overflow: TextOverflow.ellipsis, style: tt.bodySmall),
                      Text(e.value, maxLines: 2, overflow: TextOverflow.ellipsis),
                    ]),
                  ),
              ]),
            ),
          ],
        ],
        const SectionTitle('ميزات ذكية فائقة'),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _Feature(
              icon: Icons.chat_rounded,
              color: const Color(0xFF25D366),
              title: 'سحب حالات واتساب',
              sub: 'حفظ الحالات النشطة مباشرة دون روابط.',
              onTap: () => _platformTap('WhatsApp')),
          const SizedBox(width: 12),
          _Feature(
              icon: Icons.theater_comedy_rounded,
              color: kCyan,
              title: 'المتصفح الخفي',
              sub: 'تصفح المنصات والتحميل بنقرة واحدة من داخل التطبيق.',
              onTap: () => _openBrowser('https://www.google.com')),
        ]),
        const SizedBox(height: 12),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _Feature(
              icon: Icons.music_note_rounded,
              color: kMint,
              title: 'تحويل إلى MP3',
              sub: audioMode ? 'مفعّل: التنزيل التالي صوت فقط' : 'لاستخراج الصوت بجودة عالية فورًا.',
              active: audioMode,
              onTap: () => ref.read(audioModeProvider.notifier).state = !audioMode),
          const SizedBox(width: 12),
          _Feature(
              icon: Icons.auto_fix_high_rounded,
              color: kPurple,
              title: 'نسخة أصلية بلا علامة',
              sub: 'نجلب الملف الأصلي النظيف عند توفره.',
              onTap: _watermarkInfo),
        ]),
        const SizedBox(height: 20),
        Text(
          'يحمّل التطبيق الملفات المتاحة للعامة والمسموح بها فقط، ولا يتجاوز الحماية أو المحتوى الخاص. '
          'أنت المسؤول عن احترام حقوق النشر وشروط المنصات.',
          style: tt.bodySmall,
        ),
      ],
    );

    return Stack(children: [
      list,
      // نافذة اكتشاف رابط في الحافظة
      Positioned(
        left: 24,
        right: 24,
        bottom: 96,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: _clipUrl == null
              ? const SizedBox.shrink()
              : Glass(
                  key: ValueKey(_clipUrl),
                  accent: kMint,
                  padding: const EdgeInsets.fromLTRB(16, 12, 8, 14),
                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(
                        child: Text('تم اكتشاف رابط ${siteName(detectSite(_clipUrl!))}!\nهل تريد تحليله؟',
                            style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                      ),
                      IconButton(onPressed: () => setState(() => _clipUrl = null), icon: const Icon(Icons.close_rounded)),
                    ]),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      height: 46,
                      child: FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: kMint, foregroundColor: Colors.black87),
                        onPressed: () => _usePasted(_clipUrl!),
                        child: const Text('نعم', style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ),
                  ]),
                ),
        ),
      ),
    ]);
  }

  List<Widget> _resultTiles() {
    if (_results!.isEmpty) return [const Glass(child: Text('لا توجد نتائج'))];
    return [
      for (final v in _results!)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Glass(
            padding: const EdgeInsets.all(8),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => _usePasted(v.url),
              child: Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(v.thumbnails.mediumResUrl,
                      width: 112, height: 64, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox(width: 112, height: 64)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleSmall),
                    Text([v.author, fmtDuration(v.duration)].where((e) => e.isNotEmpty).join(' • '),
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                  ]),
                ),
              ]),
            ),
          ),
        ),
    ];
  }
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String sub;
  final VoidCallback onTap;
  final bool active;
  const _Feature({required this.icon, required this.color, required this.title, required this.sub, required this.onTap, this.active = false});

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Glass(
          accent: active ? color : null,
          radius: 22,
          padding: const EdgeInsets.all(14),
          child: SizedBox(
            height: 92,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(title, style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis)),
                Icon(icon, color: color),
              ]),
              const SizedBox(height: 6),
              Text(sub, style: tt.bodySmall, maxLines: 3, overflow: TextOverflow.ellipsis),
            ]),
          ),
        ),
      ),
    );
  }
}

class _Skeleton extends StatefulWidget {
  const _Skeleton();
  @override
  State<_Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<_Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context).colorScheme.onSurface;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        Widget bar(double w, double h) => Container(
            width: w, height: h, decoration: BoxDecoration(color: base.withOpacity(0.06 + 0.08 * _c.value), borderRadius: BorderRadius.circular(8)));
        return Glass(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            bar(double.infinity, 160),
            const SizedBox(height: 12),
            bar(240, 16),
            const SizedBox(height: 8),
            bar(140, 12),
          ]),
        );
      },
    );
  }
}

class _VaultSwitch extends ConsumerWidget {
  final ValueNotifier<bool> toVault;
  final VoidCallback onDenied;
  const _VaultSwitch({required this.toVault, required this.onDenied});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final has = PinStore.has(ref.watch(prefsProvider), vault: true);
    return ValueListenableBuilder<bool>(
      valueListenable: toVault,
      builder: (_, v, __) => SwitchListTile(
        dense: true,
        contentPadding: EdgeInsets.zero,
        secondary: const Icon(Icons.lock_rounded, color: kMint),
        title: const Text('إضافة إلى الخزنة بعد التنزيل'),
        subtitle: const Text('يُشفَّر الملف ولا يظهر في المكتبة أو الاستوديو'),
        value: v && has,
        onChanged: (n) {
          if (n && !has) {
            onDenied();
            return;
          }
          toVault.value = n;
        },
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final MediaInfo info;
  final void Function(MediaInfo, MediaOption) onPick;
  final ValueNotifier<bool> toVault;
  final VoidCallback onVaultDenied;
  const _InfoCard({required this.info, required this.onPick, required this.toVault, required this.onVaultDenied});

  @override
  Widget build(BuildContext context) {
    return Glass(
      accent: kCyan,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (info.thumbnail != null && info.thumbnail!.isNotEmpty)
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.network(info.thumbnail!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Colors.black12)),
            ),
          ),
        const SizedBox(height: 12),
        Text(info.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 4),
        Text([siteName(info.site), if (info.author != null && info.author!.isNotEmpty) info.author!, fmtDuration(info.duration)]
            .where((s) => s.isNotEmpty)
            .join(' • ')),
        const SizedBox(height: 4),
        _VaultSwitch(toVault: toVault, onDenied: onVaultDenied),
        const SizedBox(height: 8),
        GradientButton(
          label: 'تنزيل بأعلى جودة (${info.best.label})',
          icon: Icons.bolt_rounded,
          onPressed: () => onPick(info, info.best),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          height: 48,
          child: OutlinedButton.icon(
            onPressed: () => showGlassSheet(
                context,
                (ctx) => _OptionsSheet(
                    info: info,
                    onPick: (o) {
                      Navigator.pop(ctx);
                      onPick(info, o);
                    })),
            icon: const Icon(Icons.tune_rounded),
            label: const Text('كل الجودات والصوت'),
          ),
        ),
      ]),
    );
  }
}

class _OptionsSheet extends StatelessWidget {
  final MediaInfo info;
  final void Function(MediaOption) onPick;
  const _OptionsSheet({required this.info, required this.onPick});

  @override
  Widget build(BuildContext context) {
    final videos = info.options.where((o) => !o.audioOnly).toList();
    final audios = info.options.where((o) => o.audioOnly).toList();
    Widget tile(MediaOption o) => ListTile(
          minVerticalPadding: 12,
          leading: Icon(o.audioOnly ? Icons.music_note_rounded : Icons.videocam_rounded),
          title: Text(o.label),
          subtitle: Text('${o.container.toUpperCase()} • ${fmtBytes(o.sizeBytes)}'),
          trailing: const Icon(Icons.download_rounded),
          onTap: () => onPick(o),
        );
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      children: [
        Text(info.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleSmall),
        const Divider(height: 24),
        if (videos.isNotEmpty) Text('فيديو', style: Theme.of(context).textTheme.labelLarge),
        for (final o in videos) tile(o),
        if (audios.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('صوت فقط', style: Theme.of(context).textTheme.labelLarge),
          for (final o in audios) tile(o),
        ],
      ],
    );
  }
}
