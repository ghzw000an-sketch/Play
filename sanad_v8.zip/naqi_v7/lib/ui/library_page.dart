import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import '../core/library.dart' show LibFolder, folderColors;
import '../core/models.dart';
import '../core/providers.dart';
import '../engine/gallery.dart';
import '../engine/native_engine.dart';
import 'design.dart';
import 'glass.dart';
import 'player_page.dart';

enum _Sort { newest, oldest, largest, name }

class LibraryPage extends ConsumerStatefulWidget {
  const LibraryPage({super.key});
  @override
  ConsumerState<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends ConsumerState<LibraryPage> {
  String _q = '';
  int _filter = 0; // 0 الكل، 1 فيديو، 2 صوت، 3 مفضلة
  String? _folder; // اسم منصة، أو 'trash'، أو null = الرئيسية
  _Sort _sort = _Sort.newest;
  final Set<String> _sel = {};

  bool get _selecting => _sel.isNotEmpty;

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  Future<bool> _exists(LibraryItem i) async {
    if (await File(i.filePath).exists()) return true;
    _snack('الملف غير موجود (ربما حُذف من الجهاز)');
    return false;
  }

  Future<void> _play(LibraryItem i) async {
    if (!await _exists(i) || !mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerPage(item: i)));
  }

  Future<void> _share(List<LibraryItem> l) async {
    final ok = <XFile>[];
    for (final i in l) {
      if (await File(i.filePath).exists()) ok.add(XFile(i.filePath));
    }
    if (ok.isEmpty) {
      _snack('لا توجد ملفات صالحة للمشاركة');
      return;
    }
    await Share.shareXFiles(ok, text: l.length == 1 ? l.first.title : null);
  }

  Future<void> _gallery(LibraryItem i) async {
    if (!await _exists(i)) return;
    final uri = await saveToGallery(i.filePath, image: i.isImage);
    if (uri != null && uri != 'gal:') ref.read(libraryProvider.notifier).setGalleryUri(i.id, uri);
    final ok = uri != null;
    _snack(ok ? 'تم الحفظ في الاستوديو (مجلد سند)' : 'تعذّر الحفظ في الاستوديو (تحقق من الصلاحيات أو الصيغة)');
  }

  Future<void> _delete(List<LibraryItem> l) async {
    if (_folder == 'trash') {
      final yes = await confirmSheet(context,
          title: 'حذف نهائي',
          message: l.length == 1 ? 'سيُحذف الملف نهائيًا من الجهاز.' : 'سيتم حذف ${l.length} ملفات نهائيًا من الجهاز.',
          action: 'حذف نهائي');
      if (!yes) return;
      await ref.read(libraryProvider.notifier).removeMany(l.map((e) => e.id));
      _snack('تم الحذف نهائيًا');
    } else {
      ref.read(libraryProvider.notifier).trashMany(l.map((e) => e.id));
      _snack('نُقل إلى سلة المهملات');
    }
    if (mounted) setState(() => _sel.removeAll(l.map((e) => e.id)));
  }

  Future<void> _rename(LibraryItem i) async {
    final name = await inputSheet(context, title: 'إعادة تسمية', initial: i.title);
    if (name == null) return;
    final clean = name.replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), ' ').trim();
    if (clean.isEmpty) return;
    var newPath = i.filePath;
    try {
      final f = File(i.filePath);
      if (await f.exists()) {
        final dot = i.filePath.lastIndexOf('.');
        final slash = i.filePath.lastIndexOf('/');
        final ext = dot > slash ? i.filePath.substring(dot) : '';
        final target = '${i.filePath.substring(0, slash + 1)}$clean$ext';
        if (target != i.filePath && !await File(target).exists()) {
          await f.rename(target);
          newPath = target;
        }
      }
    } catch (_) {}
    ref.read(libraryProvider.notifier).update(i.copyWith(title: clean, filePath: newPath));
  }

  void _details(LibraryItem i) {
    showGlassSheet<void>(
      context,
      (ctx) => ListView(shrinkWrap: true, padding: const EdgeInsets.all(20), children: [
        Text('التفاصيل', style: Theme.of(ctx).textTheme.titleMedium),
        const SizedBox(height: 12),
        SelectableText([
          'العنوان: ${i.title}',
          'المنصة: ${i.site}',
          if (i.author != null && i.author!.isNotEmpty) 'الناشر: ${i.author}',
          'الجودة: ${i.label}',
          'الحجم: ${fmtBytes(i.sizeBytes)}',
          if (i.durationSec != null) 'المدة: ${fmtDuration(Duration(seconds: i.durationSec!))}',
          'التاريخ: ${fmtDate(i.createdAt)}',
          'المسار: ${i.filePath}',
          if (i.sourceUrl != null) 'الرابط: ${i.sourceUrl}',
        ].join('\n\n')),
      ]),
    );
  }

  /// يستخرج مسار الصوت من الفيديو إلى M4A (بدون إعادة ترميز) ويضيفه للمكتبة.
  Future<void> _toAudio(LibraryItem i) async {
    if (!await _exists(i)) return;
    _snack('جارٍ استخراج الصوت…');
    try {
      final dot = i.filePath.lastIndexOf('.');
      final slash = i.filePath.lastIndexOf('/');
      final stem = dot > slash ? i.filePath.substring(0, dot) : i.filePath;
      var out = '$stem.m4a';
      var n = 2;
      while (await File(out).exists()) {
        out = '$stem ($n).m4a';
        n++;
      }
      await MediaTools.extractAudio(i.filePath, out);
      final size = await File(out).length();
      ref.read(libraryProvider.notifier).add(LibraryItem(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            title: i.title,
            site: i.site,
            filePath: out,
            audioOnly: true,
            sizeBytes: size,
            label: 'M4A • من الفيديو',
            thumbPath: i.thumbPath,
            sourceUrl: i.sourceUrl,
            author: i.author,
            createdAt: DateTime.now(),
            durationSec: i.durationSec,
          ));
      _snack('تم إنشاء ملف صوتي (M4A) في المكتبة');
    } catch (_) {
      _snack('تعذّر استخراج الصوت (ربما الفيديو بلا مسار صوت أو بصيغة غير مدعومة)');
    }
  }

  // ───────── المجلدات المخصصة ─────────
  Future<void> _folderEditor({LibFolder? f}) async {
    final ctrl = TextEditingController(text: f?.name ?? '');
    var color = f?.color ?? folderColors.first;
    final r = await showGlassSheet<(String, int)>(
      context,
      (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(f == null ? 'مجلد جديد' : 'تعديل المجلد', style: Theme.of(ctx).textTheme.titleMedium),
            const SizedBox(height: 12),
            TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(hintText: 'اسم المجلد')),
            const SizedBox(height: 14),
            Wrap(spacing: 12, runSpacing: 12, children: [
              for (final c in folderColors)
                GestureDetector(
                  onTap: () => setS(() => color = c),
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle, border: Border.all(color: color == c ? Colors.white : Colors.transparent, width: 3)),
                    child: color == c ? const Icon(Icons.check, color: Colors.black87) : null,
                  ),
                ),
            ]),
            const SizedBox(height: 18),
            SizedBox(
              height: 48,
              child: FilledButton(
                onPressed: () {
                  final t = ctrl.text.trim();
                  if (t.isEmpty) return;
                  Navigator.pop(ctx, (t, color));
                },
                child: Text(f == null ? 'إنشاء' : 'حفظ'),
              ),
            ),
          ]),
        ),
      ),
    );
    if (r == null) return;
    final fn = ref.read(foldersProvider.notifier);
    if (f == null) {
      fn.create(r.$1, r.$2);
    } else {
      fn.update(f.id, name: r.$1, color: r.$2);
    }
  }

  void _folderMenu(LibFolder f) {
    showGlassSheet<void>(context, (ctx) {
      return ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 8), child: Text(f.name, style: Theme.of(ctx).textTheme.titleMedium)),
        ListTile(
            leading: const Icon(Icons.edit_outlined),
            title: const Text('إعادة تسمية / تغيير اللون'),
            onTap: () {
              Navigator.pop(ctx);
              _folderEditor(f: f);
            }),
        ListTile(
            leading: const Icon(Icons.delete_outline),
            title: const Text('حذف المجلد'),
            onTap: () {
              Navigator.pop(ctx);
              _deleteFolder(f);
            }),
      ]);
    });
  }

  Future<void> _deleteFolder(LibFolder f) async {
    final ids = ref.read(libraryProvider).where((i) => i.folder == f.id).map((i) => i.id).toList();
    final choice = await showGlassSheet<int>(
      context,
      (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('حذف «${f.name}»', style: Theme.of(ctx).textTheme.titleMedium, textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text('يحتوي ${ids.length} ملفًا.', textAlign: TextAlign.center),
          const SizedBox(height: 16),
          SizedBox(height: 48, child: OutlinedButton(onPressed: () => Navigator.pop(ctx, 1), child: const Text('حذف المجلد فقط (تبقى الملفات)'))),
          const SizedBox(height: 8),
          SizedBox(
            height: 48,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
              onPressed: () => Navigator.pop(ctx, 2),
              child: const Text('حذف المجلد وملفاته (إلى السلة)'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(height: 48, child: TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء'))),
        ]),
      ),
    );
    if (choice == null) return;
    final lib = ref.read(libraryProvider.notifier);
    lib.setFolder(ids, null);
    if (choice == 2) lib.trashMany(ids);
    ref.read(foldersProvider.notifier).remove(f.id);
    if (mounted && _folder == 'f:${f.id}') setState(() => _folder = null);
    _snack(choice == 2 ? 'حُذف المجلد ونُقلت ملفاته إلى السلة' : 'حُذف المجلد وبقيت ملفاته');
  }

  Future<void> _moveTo(List<LibraryItem> l) async {
    final folders = ref.read(foldersProvider);
    final pick = await showGlassSheet<String>(
      context,
      (ctx) => ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 8), child: Text('نقل ${l.length} إلى…', style: Theme.of(ctx).textTheme.titleMedium)),
        ListTile(leading: const Icon(Icons.create_new_folder_outlined), title: const Text('مجلد جديد…'), onTap: () => Navigator.pop(ctx, '__new')),
        ListTile(leading: const Icon(Icons.folder_off_outlined), title: const Text('بدون مجلد'), onTap: () => Navigator.pop(ctx, '__none')),
        for (final f in folders)
          ListTile(leading: Icon(Icons.folder_rounded, color: Color(f.color)), title: Text(f.name), onTap: () => Navigator.pop(ctx, f.id)),
      ]),
    );
    if (pick == null) return;
    String? target;
    if (pick == '__new') {
      final before = ref.read(foldersProvider).length;
      await _folderEditor();
      final now = ref.read(foldersProvider);
      if (now.length <= before) return;
      target = now.last.id;
    } else if (pick != '__none') {
      target = pick;
    }
    ref.read(libraryProvider.notifier).setFolder(l.map((e) => e.id), target);
    if (mounted) setState(_sel.clear);
    _snack(target == null ? 'أُخرجت من المجلد' : 'تم النقل');
  }

  void _more(LibraryItem i) {
    showGlassSheet<void>(context, (ctx) {
      Widget tile(IconData ic, String t, VoidCallback f) => ListTile(
            leading: Icon(ic),
            title: Text(t),
            onTap: () {
              Navigator.pop(ctx);
              f();
            },
          );
      return ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
        tile(Icons.play_circle_outline, 'تشغيل', () => _play(i)),
        tile(Icons.share_outlined, 'مشاركة', () => _share([i])),
        if (!i.audioOnly && !i.isImage) tile(Icons.music_note_rounded, 'تحويل إلى صوت (M4A)', () => _toAudio(i)),
        if (!i.audioOnly) tile(Icons.photo_library_outlined, 'حفظ في الاستوديو', () => _gallery(i)),
        tile(i.favorite ? Icons.star : Icons.star_border, i.favorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة',
            () => ref.read(libraryProvider.notifier).update(i.copyWith(favorite: !i.favorite))),
        tile(Icons.drive_file_move_outlined, 'نقل إلى مجلد', () => _moveTo([i])),
        tile(Icons.drive_file_rename_outline, 'إعادة تسمية', () => _rename(i)),
        if (i.sourceUrl != null)
          tile(Icons.link, 'نسخ الرابط الأصلي', () {
            Clipboard.setData(ClipboardData(text: i.sourceUrl!));
            _snack('تم نسخ الرابط');
          }),
        tile(Icons.info_outline, 'التفاصيل', () => _details(i)),
        tile(Icons.delete_outline, 'حذف', () => _delete([i])),
      ]);
    });
  }

  @override
  Widget build(BuildContext context) {
    final every = ref.watch(libraryProvider);
    final all = every.where((i) => !i.trashed).toList();
    final trash = every.where((i) => i.trashed).toList();
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final inTrash = _folder == 'trash';
    final customs = ref.watch(foldersProvider);
    LibFolder? curFolder;
    if (_folder != null && _folder!.startsWith('f:')) {
      final id = _folder!.substring(2);
      for (final f in customs) {
        if (f.id == id) curFolder = f;
      }
    }
    final home = _folder == null && _q.isEmpty && _filter == 0;

    final base = inTrash ? trash : all;
    final items = base.where((i) {
      if (_q.isNotEmpty && !i.title.toLowerCase().contains(_q.toLowerCase())) return false;
      if (curFolder != null) {
        if (i.folder != curFolder.id) return false;
      } else if (_folder != null && !inTrash && i.site != _folder) {
        return false;
      }
      return switch (_filter) {
        1 => !i.audioOnly && !i.isImage,
        2 => i.audioOnly,
        3 => i.favorite,
        _ => true,
      };
    }).toList();
    items.sort((a, b) => switch (_sort) {
          _Sort.newest => b.createdAt.compareTo(a.createdAt),
          _Sort.oldest => a.createdAt.compareTo(b.createdAt),
          _Sort.largest => b.sizeBytes.compareTo(a.sizeBytes),
          _Sort.name => a.title.toLowerCase().compareTo(b.title.toLowerCase()),
        });
    final total = all.fold<int>(0, (s, i) => s + i.sizeBytes);
    final selected = every.where((i) => _sel.contains(i.id)).toList();

    // مجلدات ذكية: لكل منصة فيها ملفات
    final sites = <String, List<LibraryItem>>{};
    for (final i in all) {
      sites.putIfAbsent(i.site, () => []).add(i);
    }

    Widget header;
    if (_selecting) {
      header = Row(children: [
        IconButton(onPressed: () => setState(_sel.clear), icon: const Icon(Icons.close)),
        Expanded(child: Text('${_sel.length} محدد', style: tt.titleMedium)),
        IconButton(tooltip: 'تحديد الكل', onPressed: () => setState(() => _sel.addAll(items.map((e) => e.id))), icon: const Icon(Icons.select_all)),
        if (inTrash)
          IconButton(
              tooltip: 'استعادة',
              onPressed: () {
                ref.read(libraryProvider.notifier).restoreMany(_sel.toList());
                setState(_sel.clear);
              },
              icon: const Icon(Icons.restore_from_trash_rounded))
        else ...[
          IconButton(tooltip: 'نقل إلى مجلد', onPressed: () => _moveTo(selected), icon: const Icon(Icons.drive_file_move_outlined)),
          IconButton(tooltip: 'مشاركة', onPressed: () => _share(selected), icon: const Icon(Icons.share_outlined)),
        ],
        IconButton(tooltip: inTrash ? 'حذف نهائي' : 'حذف', onPressed: () => _delete(selected), icon: const Icon(Icons.delete_outline)),
      ]);
    } else {
      header = Row(children: [
        if (_folder != null)
          IconButton(onPressed: () => setState(() => _folder = null), icon: const Icon(Icons.arrow_forward_rounded)),
        Expanded(
          child: TextField(
            onChanged: (v) => setState(() => _q = v),
            decoration: InputDecoration(
              hintText: 'ابحث في المكتبة',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white.withOpacity(0.08),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
              isDense: true,
            ),
          ),
        ),
        PopupMenuButton<_Sort>(
          tooltip: 'ترتيب',
          icon: const Icon(Icons.sort_rounded),
          initialValue: _sort,
          onSelected: (s) => setState(() => _sort = s),
          itemBuilder: (_) => const [
            PopupMenuItem(value: _Sort.newest, child: Text('الأحدث')),
            PopupMenuItem(value: _Sort.oldest, child: Text('الأقدم')),
            PopupMenuItem(value: _Sort.largest, child: Text('الأكبر حجمًا')),
            PopupMenuItem(value: _Sort.name, child: Text('الاسم')),
          ],
        ),
      ]);
    }

    Widget folderTile(String title, String sub, Widget badge, VoidCallback onTap) => InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Glass(
            radius: 22,
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              badge,
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                  Text(title, style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(sub, style: tt.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
                ]),
              ),
            ]),
          ),
        );

    final folders = <Widget>[
      for (final e in sites.entries)
        folderTile(platformFolderTitle(e.key), itemsLabel(e.value.length, e.value.fold<int>(0, (s, i) => s + i.sizeBytes)),
            PlatformBadge(e.key, size: 40), () => setState(() => _folder = e.key)),
      folderTile('المفضلة', '${all.where((i) => i.favorite).length} عنصرًا', const Icon(Icons.star_rounded, color: Colors.amber, size: 36),
          () => setState(() => _filter = 3)),
      folderTile('الصوتيات', '${all.where((i) => i.audioOnly).length} عنصرًا', const Icon(Icons.music_note_rounded, color: kMint, size: 36),
          () => setState(() => _filter = 2)),
    ];

    Widget body;
    if (home) {
      body = ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 120), children: [
        const SectionTitle('مجلدات ذكية'),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 2.3,
          children: folders,
        ),
        SectionTitle('مجلداتي',
            trailing: TextButton.icon(onPressed: () => _folderEditor(), icon: const Icon(Icons.create_new_folder_outlined), label: const Text('مجلد جديد'))),
        if (customs.isEmpty)
          Text('أنشئ مجلدات بأسمائك ثم انقل إليها ملفاتك من قائمة ⋯ أو بالتحديد المتعدد.', style: tt.bodySmall)
        else
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 2.3,
            children: [
              for (final f in customs)
                GestureDetector(
                  onLongPress: () => _folderMenu(f),
                  child: folderTile(f.name, itemsLabel(all.where((i) => i.folder == f.id).length, all.where((i) => i.folder == f.id).fold<int>(0, (s, i) => s + i.sizeBytes)),
                      Icon(Icons.folder_rounded, color: Color(f.color), size: 40), () => setState(() => _folder = 'f:${f.id}')),
                ),
            ],
          ),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => setState(() => _folder = 'trash'),
          child: Glass(
            radius: 22,
            child: Row(children: [
              const Icon(Icons.delete_outline_rounded, size: 30),
              const SizedBox(width: 12),
              Expanded(child: Text('سلة المهملات', style: tt.titleSmall)),
              Text('${trash.length}', style: tt.titleMedium),
              const Icon(Icons.chevron_left_rounded),
            ]),
          ),
        ),
        SectionTitle('كل الملفات (${all.length} • ${fmtBytes(total)})'),
        if (all.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 40),
            child: Column(children: [
              Icon(Icons.video_library_outlined, size: 72, color: cs.outline),
              const SizedBox(height: 12),
              const Text('مكتبتك فارغة — ابدأ بتنزيل أول ملف'),
            ]),
          ),
        for (final i in (items.take(30))) _card(i),
      ]);
    } else {
      body = Column(children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            for (final e in const [(0, 'الكل'), (1, 'فيديو'), (2, 'صوت'), (3, '⭐ المفضلة')])
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 8),
                child: ChoiceChip(label: Text(e.$2), selected: _filter == e.$1, onSelected: (_) => setState(() => _filter = e.$1)),
              ),
          ]),
        ),
        if (curFolder != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Icon(Icons.folder_rounded, color: Color(curFolder.color)),
              const SizedBox(width: 8),
              Expanded(child: Text(curFolder.name, style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800))),
              IconButton(tooltip: 'تعديل', onPressed: () => _folderEditor(f: curFolder), icon: const Icon(Icons.edit_outlined)),
              IconButton(tooltip: 'حذف المجلد', onPressed: () => _deleteFolder(curFolder!), icon: const Icon(Icons.delete_outline)),
            ]),
          ),
        if (inTrash)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(child: Text('سلة المهملات • ${trash.length}', style: tt.titleSmall)),
              TextButton.icon(
                onPressed: trash.isEmpty
                    ? null
                    : () async {
                        final yes = await confirmSheet(context, title: 'تفريغ السلة', message: 'سيتم حذف كل ما في السلة نهائيًا.', action: 'تفريغ');
                        if (yes) await ref.read(libraryProvider.notifier).emptyTrash();
                      },
                icon: const Icon(Icons.delete_forever_outlined),
                label: const Text('تفريغ'),
              ),
            ]),
          ),
        Expanded(
          child: items.isEmpty
              ? Center(child: Text(inTrash ? 'السلة فارغة' : 'لا توجد نتائج'))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                  itemCount: items.length,
                  itemBuilder: (_, k) => _card(items[k]),
                ),
        ),
      ]);
    }

    return PopScope(
      canPop: home && !_selecting,
      onPopInvoked: (didPop) {
        if (didPop) return;
        setState(() {
          if (_selecting) {
            _sel.clear();
          } else {
            _folder = null;
            _filter = 0;
            _q = '';
          }
        });
      },
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (home && !_selecting) const PageTitle('المكتبة', icon: Icons.video_library_rounded),
            header,
          ]),
        ),
        Expanded(child: body),
      ]),
    );
  }

  Widget _card(LibraryItem i) {
    final isSel = _sel.contains(i.id);
    final cs = Theme.of(context).colorScheme;

    Widget thumb;
    if (i.thumbPath != null && File(i.thumbPath!).existsSync()) {
      thumb = Image.file(File(i.thumbPath!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.movie_rounded));
    } else {
      thumb = Icon(i.audioOnly ? Icons.music_note_rounded : Icons.movie_rounded, size: 32, color: cs.outline);
    }

    void toggle() => setState(() => isSel ? _sel.remove(i.id) : _sel.add(i.id));

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Glass(
        padding: const EdgeInsets.all(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: _selecting ? toggle : () => (i.trashed ? toggle() : _play(i)),
          onLongPress: toggle,
          child: Column(children: [
            Row(children: [
              Stack(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox(width: 84, height: 84, child: ColoredBox(color: cs.surfaceContainerHighest, child: Center(child: thumb))),
                ),
                if (isSel)
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(color: cs.primary.withOpacity(0.55), borderRadius: BorderRadius.circular(14)),
                      child: const Icon(Icons.check_circle, color: Colors.white),
                    ),
                  ),
              ]),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(i.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 4),
                  Text('${i.site} • ${i.label}', maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                  Text('${fmtBytes(i.sizeBytes)} • ${fmtDate(i.createdAt)}', style: Theme.of(context).textTheme.bodySmall),
                ]),
              ),
              if (i.favorite) const Icon(Icons.star, color: Colors.amber, size: 20),
            ]),
            if (!_selecting && !i.trashed)
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                IconButton(tooltip: 'تشغيل', onPressed: () => _play(i), icon: const Icon(Icons.play_arrow_rounded)),
                IconButton(tooltip: 'مشاركة', onPressed: () => _share([i]), icon: const Icon(Icons.share_outlined)),
                if (!i.audioOnly && !i.isImage)
                  IconButton(tooltip: 'تحويل إلى صوت', onPressed: () => _toAudio(i), icon: const Icon(Icons.music_note_rounded)),
                if (!i.audioOnly)
                  IconButton(tooltip: 'حفظ في الاستوديو', onPressed: () => _gallery(i), icon: const Icon(Icons.photo_library_outlined)),
                IconButton(tooltip: 'حذف', onPressed: () => _delete([i]), icon: const Icon(Icons.delete_outline)),
                IconButton(tooltip: 'المزيد', onPressed: () => _more(i), icon: const Icon(Icons.more_horiz)),
              ]),
          ]),
        ),
      ),
    );
  }
}
