import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import 'design.dart';
import 'glass.dart';

class StatusFile {
  final String uri;
  final String name;
  final bool video;
  final int size;
  StatusFile(this.uri, this.name, this.video, this.size);
}

class StatusNative {
  static const _c = MethodChannel('sanad/status');

  static Future<bool> hasFolder() async => (await _c.invokeMethod<bool>('hasFolder')) ?? false;

  /// يفتح منتقي مجلد النظام (SAF) لاختيار مجلد .Statuses.
  static Future<bool> pickFolder() async => (await _c.invokeMethod<bool>('pickFolder')) ?? false;

  static Future<List<StatusFile>> list() async {
    final r = await _c.invokeMethod<List<dynamic>>('list') ?? [];
    return [
      for (final e in r)
        StatusFile((e as Map)['uri'] as String, e['name'] as String, e['video'] as bool, (e['size'] as num).toInt())
    ];
  }

  static Future<Uint8List?> thumb(String uri) async => _c.invokeMethod<Uint8List>('thumb', {'uri': uri});
  static Future<void> copy(String uri, String dst) => _c.invokeMethod('copy', {'uri': uri, 'dst': dst});
}

class StatusSaverPage extends ConsumerStatefulWidget {
  const StatusSaverPage({super.key});
  @override
  ConsumerState<StatusSaverPage> createState() => _StatusSaverPageState();
}

class _StatusSaverPageState extends ConsumerState<StatusSaverPage> with WidgetsBindingObserver {
  bool? _has;
  List<StatusFile> _files = [];
  bool _loading = false;
  String? _err;
  final _saved = <String>{};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed && _has == true) _load();
  }

  Future<void> _init() async {
    try {
      final h = await StatusNative.hasFolder();
      setState(() => _has = h);
      if (h) _load();
    } catch (_) {
      setState(() {
        _has = false;
        _err = 'هذه الميزة تحتاج نسخة أندرويد الكاملة.';
      });
    }
  }

  Future<void> _pick() async {
    try {
      final ok = await StatusNative.pickFolder();
      if (ok) {
        setState(() => _has = true);
        _load();
      }
    } catch (_) {
      setState(() => _err = 'تعذّر فتح منتقي المجلدات.');
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _err = null;
    });
    try {
      final l = await StatusNative.list();
      if (mounted) setState(() => _files = l);
    } catch (_) {
      if (mounted) setState(() => _err = 'تعذّر قراءة المجلد. اختره من جديد.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save(StatusFile f) async {
    haptic(ref, strong: true);
    try {
      final base = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
      final dir = Directory('${base.path}/WhatsApp');
      await dir.create(recursive: true);
      final dst = '${dir.path}/${f.name}';
      await StatusNative.copy(f.uri, dst);
      final size = await File(dst).length();
      ref.read(libraryProvider.notifier).add(LibraryItem(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            title: 'حالة واتساب ${f.name}',
            site: 'WhatsApp',
            filePath: dst,
            audioOnly: false,
            sizeBytes: size,
            label: f.video ? 'فيديو' : 'صورة',
            createdAt: DateTime.now(),
          ));
      setState(() => _saved.add(f.uri));
      if (mounted) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('تم الحفظ في المكتبة')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('تعذّر الحفظ')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('حالات واتساب'), backgroundColor: Colors.transparent, actions: [
        if (_has == true) IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
      ]),
      extendBodyBehindAppBar: true,
      body: AppBackground(
        child: SafeArea(
          child: _has != true
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Glass(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.chat_rounded, size: 56, color: Color(0xFF25D366)),
                        const SizedBox(height: 12),
                        Text('اختر مجلد الحالات مرة واحدة', style: tt.titleMedium),
                        const SizedBox(height: 8),
                        const Text(
                          'شاهد الحالة في واتساب أولًا، ثم اضغط "اختيار المجلد" وانتقل إلى:\n'
                          'Android ▸ media ▸ com.whatsapp ▸ WhatsApp ▸ Media ▸ .Statuses\n'
                          '(واتساب بزنس: com.whatsapp.w4b). ثم اضغط "استخدام هذا المجلد".\n'
                          'التطبيق يقرأ هذا المجلد فقط بإذنك، ولا يصل لأي شيء آخر.',
                          textAlign: TextAlign.center,
                        ),
                        if (_err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_err!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
                        const SizedBox(height: 16),
                        GradientButton(label: 'اختيار المجلد', icon: Icons.folder_open_rounded, onPressed: _pick),
                      ]),
                    ),
                  ),
                )
              : _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _files.isEmpty
                      ? Center(
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Text(_err ?? 'لا توجد حالات نشطة. شاهد حالة ثم عُد.'),
                            TextButton(onPressed: _pick, child: const Text('تغيير المجلد')),
                          ]),
                        )
                      : GridView.builder(
                          padding: const EdgeInsets.fromLTRB(12, 56, 12, 24),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8),
                          itemCount: _files.length,
                          itemBuilder: (_, i) {
                            final f = _files[i];
                            return ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: Stack(fit: StackFit.expand, children: [
                                _Thumb(f.uri),
                                if (f.video) const Positioned(top: 6, left: 6, child: Icon(Icons.play_circle_fill_rounded, color: Colors.white)),
                                Positioned(
                                  bottom: 4,
                                  right: 4,
                                  child: IconButton.filled(
                                    onPressed: _saved.contains(f.uri) ? null : () => _save(f),
                                    icon: Icon(_saved.contains(f.uri) ? Icons.check_rounded : Icons.download_rounded),
                                  ),
                                ),
                              ]),
                            );
                          },
                        ),
        ),
      ),
    );
  }
}

class _Thumb extends StatefulWidget {
  final String uri;
  const _Thumb(this.uri);
  @override
  State<_Thumb> createState() => _ThumbState();
}

class _ThumbState extends State<_Thumb> {
  Uint8List? _b;
  @override
  void initState() {
    super.initState();
    StatusNative.thumb(widget.uri).then((v) {
      if (mounted) setState(() => _b = v);
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) =>
      _b == null ? const ColoredBox(color: Colors.black26, child: Icon(Icons.image_outlined)) : Image.memory(_b!, fit: BoxFit.cover);
}
