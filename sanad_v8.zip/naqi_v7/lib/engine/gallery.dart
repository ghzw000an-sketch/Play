import 'package:flutter/services.dart';
import 'package:gal/gal.dart';

const _c = MethodChannel('sanad/gallery');

/// يحفظ الملف في استوديو الهاتف (ألبوم Sanad) عبر MediaStore.
/// يرجع معرّف النسخة (uri) أو null عند الفشل. يدعم فيديو وصورة وصوت.
Future<String?> saveToGallery(String path, {bool image = false}) async {
  try {
    final r = await _c.invokeMethod<String>('save', {'path': path, 'album': 'Sanad'});
    if (r != null && r.isNotEmpty) return r;
  } catch (_) {}
  // احتياطي (مكتبة gal) للفيديو والصور فقط.
  try {
    final p = path.toLowerCase();
    final isImg = image || RegExp(r'\.(jpg|jpeg|png|webp|gif)$').hasMatch(p);
    final isVid = RegExp(r'\.(mp4|mkv|webm|mov|3gp)$').hasMatch(p);
    if (!isImg && !isVid) return null;
    if (!await Gal.hasAccess(toAlbum: true)) {
      if (!await Gal.requestAccess(toAlbum: true)) return null;
    }
    isImg ? await Gal.putImage(path, album: 'Sanad') : await Gal.putVideo(path, album: 'Sanad');
    return 'gal:'; // نجح الحفظ لكن بلا معرّف للحذف لاحقًا
  } catch (_) {
    return null;
  }
}

/// يحذف نسخة الاستوديو التي أنشأها التطبيق.
Future<bool> deleteFromGallery(String? uri) async {
  if (uri == null || uri.isEmpty || uri == 'gal:') return false;
  try {
    return (await _c.invokeMethod<bool>('delete', {'uri': uri})) ?? false;
  } catch (_) {
    return false;
  }
}

/// يعيد ملفًا إلى مجلده الأصلي في الاستوديو (relPath مثل DCIM/Camera).
Future<String?> restoreToGallery(String src, String name, {String? mime, String? relPath}) async {
  try {
    return await _c.invokeMethod<String>('restore', {'src': src, 'name': name, 'mime': mime, 'relPath': relPath});
  } catch (_) {
    return null;
  }
}

class SavedFile {
  final String uri;
  final String? path;
  SavedFile(this.uri, this.path);
}

/// ينقل/ينسخ الملف إلى مجلد عام في الذاكرة الداخلية (مثل Movies/Sanad) ليظهر في الاستوديو.
/// يرجع uri والمسار الفعلي للملف الجديد (إن أمكن معرفته).
Future<SavedFile?> saveToPublic(String path, String relDir) async {
  try {
    final r = await _c.invokeMethod<Map<dynamic, dynamic>>('saveTo', {'src': path, 'rel': relDir});
    if (r == null || r['uri'] == null) return null;
    return SavedFile(r['uri'] as String, r['path'] as String?);
  } catch (_) {
    return null;
  }
}

/// ينظّف مسارًا نسبيًا يكتبه المستخدم (بلا .. ولا / زائدة).
String cleanRelDir(String input) {
  final parts = input.replaceAll('\\', '/').split('/').map((e) => e.trim()).where((e) => e.isNotEmpty && e != '.' && e != '..').toList();
  return parts.isEmpty ? 'Movies/Sanad' : parts.join('/');
}
