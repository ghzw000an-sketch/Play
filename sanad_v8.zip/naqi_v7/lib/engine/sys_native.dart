import 'package:flutter/services.dart';

class PickedFile {
  final String uri;
  final String name;
  final int size;
  final String mime;
  final String? relPath;
  PickedFile(this.uri, this.name, this.size, this.mime, this.relPath);
}

/// اختيار ملفات من الاستوديو/الجهاز ثم حذف الأصل (بإذن النظام).
class Picker {
  static const _c = MethodChannel('sanad/picker');

  static Future<List<PickedFile>> pick() async {
    final r = await _c.invokeMethod<List<dynamic>>('pick') ?? [];
    return [
      for (final e in r)
        PickedFile(
          (e as Map)['uri'] as String,
          e['name'] as String,
          (e['size'] as num?)?.toInt() ?? 0,
          (e['mime'] ?? '') as String,
          e['relPath'] as String?,
        )
    ];
  }

  static Future<void> copy(String uri, String dst) => _c.invokeMethod('copy', {'uri': uri, 'dst': dst});

  /// يحاول حذف الأصول؛ يرجع عدد ما حُذف فعلًا.
  static Future<int> deleteOriginals(List<String> uris) async {
    if (uris.isEmpty) return 0;
    return (await _c.invokeMethod<int>('delete', {'uris': uris})) ?? 0;
  }
}

/// ميزات النظام: التحميل التلقائي من الحافظة وأذوناته.
class Sys {
  static const _c = MethodChannel('sanad/sys');

  static Future<bool> _b(String m) async {
    try {
      return (await _c.invokeMethod<bool>(m)) ?? false;
    } catch (_) {
      return false;
    }
  }

  static const _net = MethodChannel('sanad/net');

  /// هل الاتصال الحالي واي فاي/إيثرنت؟ (true عند تعذّر المعرفة حتى لا نمنع التنزيل خطأً)
  static Future<bool> isWifi() async {
    try {
      return (await _net.invokeMethod<bool>('isWifi')) ?? true;
    } catch (_) {
      return true;
    }
  }

  static Future<bool> canOverlay() => _b('canOverlay');
  static Future<void> requestOverlay() => _b('requestOverlay');
  static Future<void> startClip() => _b('startClip');
  static Future<void> stopClip() => _b('stopClip');
  static Future<bool> clipRunning() => _b('clipRunning');
  static Future<bool> ignoringBattery() => _b('ignoringBattery');
  static Future<void> requestIgnoreBattery() => _b('requestIgnoreBattery');
}
