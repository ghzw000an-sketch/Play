import '../core/models.dart';
import 'extractor_base.dart';
import 'native_engine.dart';

/// رسالة عربية مفهومة من خطأ yt-dlp.
String friendlyEngineError(String raw) {
  final m = raw.toLowerCase();
  if (m.contains('login') || m.contains('log in') || m.contains('sign in') || m.contains('cookies') || m.contains('rate-limit') || m.contains('rate limit')) {
    return 'المنصة تطلب تسجيل الدخول لهذا المحتوى أو حدّت الطلبات مؤقتًا. سجّل دخولك من الإعدادات ▸ حسابات المنصات، أو جرّب رابطًا عامًا آخر.';
  }
  if (m.contains('private') || m.contains('not available') || m.contains('unavailable') || m.contains('removed') || m.contains('deleted')) {
    return 'المحتوى خاص أو محذوف أو غير متاح في منطقتك.';
  }
  if (m.contains('next.js') || m.contains('unable to extract')) {
    return 'تغيّر تصميم المنصة ولم يعد المحرك يقرأه. حدّث المحرك من الإعدادات ▸ التنزيل ثم أعد المحاولة.';
  }
  if (m.contains('unsupported url')) return 'هذا الرابط غير مدعوم.';
  if (m.contains('requested format is not available') || m.contains('no video formats')) {
    return 'لا تتوفر نسخة مناسبة (أو لا توجد نسخة بدون علامة مائية) لهذا الرابط.';
  }
  if (m.contains('timed out') || m.contains('timeout') || m.contains('unable to download') || m.contains('network') || m.contains('connection')) {
    return 'تعذّر الاتصال بالمنصة. تحقق من الإنترنت وأعد المحاولة.';
  }
  if (m.contains('http error 403') || m.contains('http error 410')) return 'انتهت صلاحية الرابط، حلّله من جديد.';
  return 'تعذّر التنزيل: ${raw.length > 160 ? raw.substring(0, 160) : raw}';
}

/// صيغة معلَّمة بعلامة مائية (مثل "Download video, watermarked" في تيك توك).
bool _isWatermarked(Map<String, dynamic> f) {
  final n = ('${f['format_note'] ?? ''} ${f['format'] ?? ''}').toLowerCase();
  if (!n.contains('watermark')) return false;
  return !RegExp(r'without|no[ -]watermark|non[ -]watermark|unwatermarked').hasMatch(n);
}

int? _int(Object? v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}');

/// يحوّل JSON الخاص بـ yt-dlp إلى MediaInfo مع خيارات الجودة والصوت.
MediaInfo mediaInfoFromYtdlp(Map<String, dynamic> j, String url) {
  // نستبعد الصيغ ذات العلامة المائية نهائيًا، ونختار الباقي بمعرّفاتها الصريحة (دون الاعتماد على صياغة المحدِّدات).
  final formats = [
    for (final f in (j['formats'] as List? ?? const []))
      if (f is Map && !_isWatermarked(Map<String, dynamic>.from(f))) Map<String, dynamic>.from(f)
  ];
  bool isVideo(Map<String, dynamic> f) {
    final v = f['vcodec'];
    return v != null && v != 'none' && f['ext'] != 'mhtml';
  }

  bool isAudioOnly(Map<String, dynamic> f) {
    final v = f['vcodec'];
    final a = f['acodec'];
    return (v == null || v == 'none') && a != null && a != 'none';
  }

  int? sizeOf(Map<String, dynamic> f) => _int(f['filesize']) ?? _int(f['filesize_approx']);
  num tbrOf(Map<String, dynamic> f) => (f['tbr'] is num ? f['tbr'] as num : 0);

  final vids = formats.where(isVideo).toList();
  final auds = formats.where(isAudioOnly).toList()..sort((a, b) => tbrOf(b).compareTo(tbrOf(a)));
  final bestAudioSize = auds.isEmpty ? null : sizeOf(auds.first);
  final audId = auds.isEmpty ? null : auds.first['format_id']?.toString();

  /// محدِّد صريح: معرّف الفيديو (+ معرّف الصوت إذا كان الفيديو بلا صوت).
  String selFor(Map<String, dynamic> v) {
    final id = '${v['format_id']}';
    final hasAudio = v['acodec'] != null && v['acodec'] != 'none';
    return (hasAudio || audId == null) ? id : '$id+$audId';
  }

  Map<String, dynamic>? bestByTbr(List<Map<String, dynamic>> l) =>
      l.isEmpty ? null : (l.toList()..sort((a, b) => tbrOf(b).compareTo(tbrOf(a)))).first;

  final heights = <int>{
    for (final f in vids) if ((_int(f['height']) ?? 0) > 0) _int(f['height'])!
  }.toList()
    ..sort((a, b) => b.compareTo(a));

  final opts = <MediaOption>[];
  if (heights.isEmpty) {
    final top = bestByTbr(vids);
    if (top != null) {
      opts.add(MediaOption(
        id: 'nbest',
        label: 'أفضل جودة',
        audioOnly: false,
        container: 'mp4',
        url: url,
        sizeBytes: sizeOf(top),
        nativeSel: selFor(top),
      ));
    }
  } else {
    for (final h in heights) {
      final top = bestByTbr(vids.where((f) => _int(f['height']) == h).toList())!;
      var size = sizeOf(top);
      if (size != null && top['acodec'] == 'none' && bestAudioSize != null) size += bestAudioSize;
      opts.add(MediaOption(
        id: 'n$h',
        label: '${h}p',
        audioOnly: false,
        container: 'mp4',
        url: url,
        sizeBytes: size,
        nativeSel: selFor(top),
      ));
    }
  }

  // صوت فقط (يُحوَّل بـ FFmpeg المضمّن). إن لم توجد صيغة صوت منفصلة نستخرجه من أفضل صيغة بلا علامة مائية.
  final audSrc = audId ?? (bestByTbr(vids)?['format_id']?.toString());
  opts.add(MediaOption(
    id: 'amp3',
    label: 'MP3 • أفضل جودة',
    audioOnly: true,
    container: 'mp3',
    url: url,
    sizeBytes: bestAudioSize,
    nativeSel: audSrc ?? 'ba/b',
    audioFmt: 'mp3',
  ));
  opts.add(MediaOption(
    id: 'am4a',
    label: 'M4A • AAC',
    audioOnly: true,
    container: 'm4a',
    url: url,
    sizeBytes: bestAudioSize,
    nativeSel: audSrc ?? 'ba/b',
    audioFmt: 'm4a',
  ));

  final title = ('${j['title'] ?? j['fulltitle'] ?? ''}').trim();
  final dur = j['duration'];
  return MediaInfo(
    sourceUrl: url,
    site: detectSite(url),
    title: title.isEmpty ? 'sanad' : (title.length > 120 ? title.substring(0, 120) : title),
    author: (j['uploader'] ?? j['channel'] ?? j['creator'])?.toString(),
    thumbnail: j['thumbnail']?.toString(),
    duration: dur is num ? Duration(seconds: dur.round()) : null,
    options: opts,
  );
}

/// المستخرج الرئيسي: محرك yt-dlp (يدعم مئات المواقع، ويختار النسخة الأصلية بلا علامة مائية).
class NativeExtractor implements Extractor {
  @override
  bool supports(Site s) => true;

  @override
  Future<MediaInfo> analyze(String url) async {
    try {
      final j = await NativeEngine.analyze(url);
      return mediaInfoFromYtdlp(j, url);
    } on EngineException catch (e) {
      throw ExtractorException(friendlyEngineError(e.message));
    }
  }
}
