import 'package:dio/dio.dart';
import '../core/models.dart';
import 'extractor_base.dart';

// حلّ الروابط المختصرة وتنظيف الروابط + مستخرجات احتياطية لسناب شات وبنتريست.
// الصفحات العامة فقط، بدون تسجيل دخول وبدون تجاوز أي حماية.

const _mobileUa =
    'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';

final _dio = Dio(BaseOptions(
  connectTimeout: const Duration(seconds: 15),
  receiveTimeout: const Duration(seconds: 25),
  followRedirects: false,
  validateStatus: (s) => true,
));

const _shortHosts = {
  'pin.it', 'fb.watch', 'fb.me', 'on.fb.me', 'vm.tiktok.com', 'vt.tiktok.com', 't.snapchat.com',
  't.co', 'bit.ly', 'instagr.am', 'lnkd.in', 'goo.gl', 'tinyurl.com', 'is.gd', 'cutt.ly',
};

bool _needsResolve(Uri u) {
  final h = u.host.toLowerCase();
  if (_shortHosts.contains(h)) return true;
  final p = u.path;
  if ((h.endsWith('tiktok.com')) && p.startsWith('/t/')) return true;
  if ((h.endsWith('facebook.com') || h.endsWith('instagram.com')) && p.contains('/share/')) return true;
  if (h.endsWith('snapchat.com') && p.startsWith('/t/')) return true;
  return false;
}

/// يتبع إعادة التوجيه للروابط المختصرة (pin.it, fb.watch, vm.tiktok…) ثم ينظّف الرابط.
Future<String> resolveUrl(String raw) async {
  var url = raw.trim();
  var uri = Uri.tryParse(url);
  if (uri == null || uri.host.isEmpty) return url;
  for (var i = 0; i < 6 && _needsResolve(uri!); i++) {
    try {
      final r = await _dio.get<String>(uri.toString(),
          options: Options(responseType: ResponseType.plain, headers: {'User-Agent': _mobileUa, 'Accept-Language': 'en-US,en;q=0.9'}));
      final loc = r.headers.value('location');
      if (loc == null || loc.isEmpty) break;
      uri = uri.resolve(loc);
    } catch (_) {
      break;
    }
  }
  return normalizeUrl(uri!.toString());
}

/// يحذف معاملات التتبّع ويوحّد صيغ إنستغرام (reels → reel).
String normalizeUrl(String url) {
  final u = Uri.tryParse(url);
  if (u == null) return url;
  final h = u.host.toLowerCase();
  var path = u.path;
  var q = Map<String, String>.from(u.queryParameters)
    ..removeWhere((k, _) => k.startsWith('utm_') || const {'fbclid', 'igsh', 'igshid', 'img_index', 'ref', 'mibextid', 'share_id', 'sender_device', 'is_copy_url'}.contains(k));
  if (h.endsWith('instagram.com')) {
    path = path.replaceFirstMapped(RegExp(r'/reels/([A-Za-z0-9_-]+)'), (m) => '/reel/${m.group(1)}');
    q = {};
  }
  if (h.endsWith('tiktok.com') || h.endsWith('pinterest.com') || h.endsWith('snapchat.com')) q = {};
  return u.replace(path: path, queryParameters: q).toString().replaceAll(RegExp(r'\?$'), '');
}

// ───────────────────────── أدوات ─────────────────────────
Future<String> _page(String url, {String ua = _mobileUa}) async {
  var u = Uri.parse(url);
  for (var i = 0; i < 6; i++) {
    final r = await _dio.get<String>(u.toString(),
        options: Options(responseType: ResponseType.plain, headers: {'User-Agent': ua, 'Accept-Language': 'en-US,en;q=0.9', 'Accept': 'text/html,*/*'}));
    final loc = r.headers.value('location');
    if ((r.statusCode ?? 0) >= 300 && (r.statusCode ?? 0) < 400 && loc != null) {
      u = u.resolve(loc);
      continue;
    }
    return r.data ?? '';
  }
  return '';
}

String _unesc(String v) => v
    .replaceAll(RegExp(r'\\+u002F', caseSensitive: false), '/')
    .replaceAll(RegExp(r'\\+u0026', caseSensitive: false), '&')
    .replaceAll(r'\/', '/')
    .replaceAll('&amp;', '&')
    .replaceAll('\\', '');

String? _meta(String h, String prop) {
  final a = RegExp('''<meta[^>]+(?:property|name)=["']$prop["'][^>]*?content=["']([^"']*)["']''', caseSensitive: false);
  final b = RegExp('''<meta[^>]+content=["']([^"']*)["'][^>]*?(?:property|name)=["']$prop["']''', caseSensitive: false);
  final v = (a.firstMatch(h) ?? b.firstMatch(h))?.group(1);
  return (v == null || v.isEmpty) ? null : _unesc(v);
}

Future<int?> _size(String url) async {
  try {
    final r = await _dio.head(url, options: Options(headers: {'User-Agent': _mobileUa}, receiveTimeout: const Duration(seconds: 6)));
    final v = r.headers.value(Headers.contentLengthHeader);
    return v == null ? null : int.tryParse(v);
  } catch (_) {
    return null;
  }
}

String _line(String s) {
  final t = s.replaceAll(RegExp(r'\s+'), ' ').trim();
  return t.length > 100 ? '${t.substring(0, 100).trim()}…' : t;
}

// ───────────────────────── Pinterest ─────────────────────────
class PinterestExtractor extends Extractor {
  @override
  bool supports(Site s) => s == Site.pinterest;

  @override
  Future<MediaInfo> analyze(String url) async {
    final h = await _page(url);
    if (h.isEmpty) throw ExtractorException('تعذّر فتح صفحة بنتريست.');
    final title = _meta(h, 'og:title') ?? _meta(h, 'twitter:title') ?? 'Pinterest';
    final thumb = _meta(h, 'og:image') ?? _meta(h, 'twitter:image:src');

    // فيديوهات: روابط mp4 على v*.pinimg.com (نختار الأعلى دقة).
    final vids = <String>{};
    for (final m in RegExp(r'https?:(?:\\?/){2}v\d*\.pinimg\.com(?:\\?/)[^"\s\\]+?\.mp4').allMatches(h)) {
      vids.add(_unesc(m.group(0)!));
    }
    final ogv = _meta(h, 'og:video') ?? _meta(h, 'og:video:url');
    if (ogv != null && ogv.contains('.mp4')) vids.add(ogv);
    int rank(String u) {
      final m = RegExp(r'/(\d{3,4})p/').firstMatch(u);
      if (m != null) return int.parse(m.group(1)!);
      if (u.contains('720')) return 720;
      return 0;
    }

    final list = vids.toList()..sort((a, b) => rank(b).compareTo(rank(a)));
    final opts = <MediaOption>[];
    for (final v in list.take(3)) {
      final r = rank(v);
      opts.add(MediaOption(
        id: 'pin${opts.length}',
        label: r > 0 ? '${r}p' : 'أعلى جودة متاحة',
        audioOnly: false,
        container: 'mp4',
        url: v,
        sizeBytes: await _size(v),
      ));
    }
    if (opts.isEmpty && thumb != null) {
      // صورة: نطلب النسخة الأصلية بدل المصغّرة.
      final orig = thumb.replaceFirst(RegExp(r'/(?:\d+x\d*|\d+x)/'), '/originals/');
      final ext = orig.split('?').first.split('.').last.toLowerCase();
      opts.add(MediaOption(
        id: 'pin-img',
        label: 'الصورة الأصلية',
        audioOnly: false,
        container: ext.length <= 4 ? ext : 'jpg',
        url: orig,
        sizeBytes: await _size(orig),
      ));
    }
    if (opts.isEmpty) throw ExtractorException('لا توجد وسائط عامة في هذا الـ Pin.');
    return MediaInfo(sourceUrl: url, site: Site.pinterest, title: _line(title), thumbnail: thumb, options: opts);
  }
}

// ───────────────────────── Snapchat ─────────────────────────
class SnapchatExtractor extends Extractor {
  @override
  bool supports(Site s) => s == Site.snapchat;

  @override
  Future<MediaInfo> analyze(String url) async {
    final h = await _page(url);
    if (h.isEmpty) throw ExtractorException('تعذّر فتح صفحة سناب شات.');
    String? video = _meta(h, 'og:video') ?? _meta(h, 'og:video:secure_url') ?? _meta(h, 'twitter:player:stream');
    if (video == null) {
      for (final key in ['contentUrl', 'snapMediaUrl', 'mediaUrl', 'videoUrl']) {
        final m = RegExp('"$key"\\s*:\\s*"(https?:[^"]+)"').firstMatch(h);
        if (m != null) {
          video = _unesc(m.group(1)!);
          break;
        }
      }
    }
    final thumb = _meta(h, 'og:image') ?? _meta(h, 'twitter:image');
    final title = _meta(h, 'og:title') ?? _meta(h, 'og:description') ?? 'Snapchat';
    if (video == null || !video.startsWith('http')) {
      throw ExtractorException('تعذّر استخراج الفيديو من سناب شات. استخدم رابط Spotlight عامًا.');
    }
    return MediaInfo(
      sourceUrl: url,
      site: Site.snapchat,
      title: _line(title),
      thumbnail: thumb,
      options: [
        MediaOption(id: 'snap', label: 'أعلى جودة متاحة', audioOnly: false, container: 'mp4', url: video, sizeBytes: await _size(video)),
      ],
    );
  }
}
