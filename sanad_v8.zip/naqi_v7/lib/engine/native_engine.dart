import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';

class EngineException implements Exception {
  final String message;
  EngineException(this.message);
  @override
  String toString() => message;
}

/// جسر إلى محرك yt-dlp الأصلي (Kotlin / youtubedl-android).
/// عند عدم وجوده (مثلاً تشغيل الاختبارات) تعود available = false ويستمر التطبيق بالمستخرجات الاحتياطية.
class NativeEngine {
  static const _m = MethodChannel('sanad/engine');
  static const _e = EventChannel('sanad/engine/events');

  static Stream<Map<String, dynamic>>? _events;
  static Stream<Map<String, dynamic>> get events => _events ??= _e
      .receiveBroadcastStream()
      .where((e) => e is Map)
      .map((e) => Map<String, dynamic>.from(e as Map));

  static bool? _available;
  static Future<bool> get available async {
    if (_available == true) return true;
    try {
      await _m.invokeMethod('ping');
      _available = true;
    } catch (_) {
      _available = false;
    }
    return _available!;
  }

  /// يرجع (جاهز؟، رسالة خطأ التهيئة إن وجدت).
  static Future<(bool, String?)> status() async {
    try {
      final r = await _m.invokeMapMethod<String, dynamic>('status');
      return (r?['ready'] == true, r?['error'] as String?);
    } catch (_) {
      return (false, null);
    }
  }

  /// يحلّل الرابط بالمحرك ويرجع JSON الكامل الذي ينتجه yt-dlp.
  static Future<Map<String, dynamic>> analyze(String url) async {
    try {
      final s = await _m.invokeMethod<String>('analyze', {'url': url});
      if (s == null || s.isEmpty) throw EngineException('empty response');
      return Map<String, dynamic>.from(jsonDecode(s) as Map);
    } on PlatformException catch (e) {
      throw EngineException(e.message ?? 'engine error');
    } on FormatException {
      throw EngineException('invalid engine response');
    }
  }

  /// يحفظ كوكيز المستخدم (Netscape) ليستعملها yt-dlp مع الحسابات العامة التي تطلب تسجيل الدخول.
  static Future<void> setCookies(String text) async {
    try {
      await _m.invokeMethod('setCookies', {'text': text});
    } catch (_) {}
  }

  static Future<void> download({
    required String id,
    required String url,
    required String format,
    required String outDir,
    required String base,
    String? audioFmt,
    int connections = 8,
  }) async {
    try {
      await _m.invokeMethod('download', {
        'id': id,
        'url': url,
        'format': format,
        'outDir': outDir,
        'base': base,
        'audioFmt': audioFmt,
        'connections': connections,
      });
    } on PlatformException catch (e) {
      throw EngineException(e.message ?? 'engine error');
    }
  }

  static Future<void> stop(String id) async {
    try {
      await _m.invokeMethod('cancel', {'id': id});
    } catch (_) {}
  }

  static Future<String> update() async {
    try {
      return (await _m.invokeMethod<String>('update')) ?? 'ok';
    } on PlatformException catch (e) {
      throw EngineException(e.message ?? 'update failed');
    }
  }

  static Future<String?> version() async {
    try {
      return await _m.invokeMethod<String>('version');
    } catch (_) {
      return null;
    }
  }
}

/// أدوات وسائط أصلية: استخراج الصوت، وإشعار الخدمة الأمامية.
class MediaTools {
  static const _c = MethodChannel('sanad/media');

  /// ينسخ مسار الصوت من الفيديو إلى M4A بدون إعادة ترميز (فوري وبلا خسارة).
  static Future<void> extractAudio(String input, String output) async {
    try {
      await _c.invokeMethod('extractAudio', {'input': input, 'output': output});
    } on PlatformException catch (e) {
      throw EngineException(e.message ?? 'extract failed');
    }
  }

  static Future<void> serviceUpdate(int active, int percent, String text) async {
    try {
      await _c.invokeMethod('service', {'action': 'update', 'active': active, 'percent': percent, 'text': text});
    } catch (_) {}
  }

  static Future<void> serviceStop() async {
    try {
      await _c.invokeMethod('service', {'action': 'stop'});
    } catch (_) {}
  }
}

/// استقبال الروابط من قائمة المشاركة في أي تطبيق.
class ShareIn {
  static const _m = MethodChannel('sanad/share');
  static const _e = EventChannel('sanad/share/events');
  static StreamSubscription<dynamic>? _sub;

  static Future<void> start(void Function(String url) onLink) async {
    try {
      final first = await _m.invokeMethod<String>('initial');
      if (first != null && first.isNotEmpty) onLink(first);
    } catch (_) {}
    _sub ??= _e.receiveBroadcastStream().listen((e) {
      if (e is String && e.isNotEmpty) onLink(e);
    }, onError: (_) {});
  }
}
