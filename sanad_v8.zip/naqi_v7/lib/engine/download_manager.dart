import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../core/models.dart';
import 'native_engine.dart';
import 'native_extractor.dart' show friendlyEngineError;
import 'segmented_downloader.dart';

const _ua =
    'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';

typedef DoneCallback = Future<void> Function(DownloadTask task, String? thumbPath);

/// مدير التنزيل:
///  • مسار المحرك الأصلي (yt-dlp + FFmpeg) لـ TikTok / Instagram / Facebook وغيرها.
///  • مسار HTTP متعدد الاتصالات (قطع Range متوازية) للروابط المباشرة مثل يوتيوب.
///  • طابور + عدد متوازٍ + إيقاف/استئناف/إلغاء + سرعة و ETA + إشعار الخدمة الأمامية.
class DownloadManager extends StateNotifier<List<DownloadTask>> {
  DownloadManager({
    required this.maxParallel,
    required this.connections,
    required this.notify,
    required this.onDone,
  }) : super(const []) {
    _timer = Timer.periodic(const Duration(milliseconds: 300), (_) => _tick());
    _events = NativeEngine.events.listen(_onEngineEvent, onError: (_) {});
  }

  final int Function() maxParallel;
  final int Function() connections;
  final bool Function() notify;
  final DoneCallback onDone;

  late final Timer _timer;
  StreamSubscription<Map<String, dynamic>>? _events;
  final Dio _dio = _makeDio();

  final _jobs = <String, SegmentedDownload>{}; // مسار HTTP
  final _last = <String, int>{};
  final _speed = <String, double>{};

  // المسار الأصلي
  final _gen = <String, int>{};
  final _proc = <String, String>{}; // taskId -> processId الحالي
  final _natDone = <String, Completer<Map<String, dynamic>>>{};
  final _nat = <String, _NatProg>{};

  int _tickN = 0;
  bool _svcOn = false;

  static Dio _makeDio() {
    final d = Dio(BaseOptions(connectTimeout: const Duration(seconds: 20)));
    d.httpClientAdapter = IOHttpClientAdapter(
      createHttpClient: () => HttpClient()..maxConnectionsPerHost = 64,
    );
    return d;
  }

  @override
  void dispose() {
    _timer.cancel();
    _events?.cancel();
    for (final j in _jobs.values) {
      j.dispose();
    }
    super.dispose();
  }

  // ───────────────────────── الطابور ─────────────────────────
  Future<void> enqueue(MediaInfo info, MediaOption opt, {bool toVault = false}) async {
    final t = DownloadTask(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      info: info,
      option: opt,
      total: opt.sizeBytes,
      toVault: toVault,
    );
    state = [...state, t];
    _pump();
  }

  void _update(String id, DownloadTask Function(DownloadTask) f) {
    state = [for (final t in state) t.id == id ? f(t) : t];
  }

  DownloadTask? _find(String id) {
    for (final t in state) {
      if (t.id == id) return t;
    }
    return null;
  }

  void _pump() {
    var free = maxParallel() - state.where((t) => t.state == TaskState.running).length;
    for (final t in state.where((t) => t.state == TaskState.queued).toList()) {
      if (free-- <= 0) break;
      _run(t.id);
    }
  }

  Future<void> _run(String id) async {
    final t = _find(id);
    if (t == null) return;
    if (t.option.nativeSel != null) {
      await _runNative(t);
    } else {
      await _runHttp(t);
    }
  }

  // ───────────────────────── مسارات الملفات ─────────────────────────
  String _safeName(DownloadTask t) {
    var safe = t.info.title.replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t%]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (safe.isEmpty) safe = 'sanad';
    if (safe.length > 70) safe = safe.substring(0, 70).trim();
    return safe;
  }

  Future<Directory> _dirFor(DownloadTask t) async {
    final base = (await getExternalStorageDirectory()) ?? await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/Sanad/${siteName(t.info.site)}');
    await dir.create(recursive: true);
    return dir;
  }

  bool _nameTaken(Directory dir, String name, String? ext) {
    for (final t in state) {
      final tp = t.targetPath;
      if (tp != null && (tp == '${dir.path}/$name' || tp == '${dir.path}/$name.$ext')) return true;
    }
    if (ext != null && File('${dir.path}/$name.$ext').existsSync()) return true;
    if (ext == null) {
      try {
        return dir.listSync().any((e) => e.path.split('/').last.startsWith('$name.'));
      } catch (_) {}
    }
    return false;
  }

  /// مسار HTTP: يحجز ملفًا فارغًا بالاسم الكامل.
  Future<String> _uniquePath(DownloadTask t) async {
    final dir = await _dirFor(t);
    final safe = _safeName(t);
    final ext = t.option.container;
    var name = safe;
    var n = 2;
    while (_nameTaken(dir, name, ext)) {
      name = '$safe ($n)';
      n++;
    }
    final path = '${dir.path}/$name.$ext';
    await File(path).create();
    return path;
  }

  /// المسار الأصلي: يرجع الاسم الأساسي بلا امتداد (يحدده yt-dlp).
  Future<String> _nativeBase(DownloadTask t) async {
    final dir = await _dirFor(t);
    final safe = _safeName(t);
    var name = safe;
    var n = 2;
    while (_nameTaken(dir, name, null)) {
      name = '$safe ($n)';
      n++;
    }
    return '${dir.path}/$name';
  }

  // ───────────────────────── المسار الأصلي (yt-dlp) ─────────────────────────
  Future<void> _runNative(DownloadTask t) async {
    final id = t.id;
    _update(id, (e) => e.copyWith(state: TaskState.running, error: ''));
    final gen = (_gen[id] ?? 0) + 1;
    _gen[id] = gen;
    final proc = '${id}_$gen';
    _proc[id] = proc;
    final c = Completer<Map<String, dynamic>>();
    _natDone[proc] = c;
    _nat[proc] = _NatProg();
    try {
      final base = t.targetPath ?? await _nativeBase(t);
      if (t.targetPath == null) _update(id, (e) => e.copyWith(targetPath: base));
      final slash = base.lastIndexOf('/');
      await NativeEngine.download(
        id: proc,
        url: t.info.sourceUrl,
        format: t.option.nativeSel!,
        outDir: base.substring(0, slash),
        base: base.substring(slash + 1),
        audioFmt: t.option.audioFmt,
        connections: connections(),
      );
      final r = await c.future;
      final type = r['type'];
      if (type == 'stopped') return; // إيقاف مؤقت أو إلغاء: الحالة محدَّثة مسبقًا
      if (_find(id) == null) return;
      if (type == 'done') {
        final path = '${r['path']}';
        final size = await File(path).length();
        _update(id, (e) => e.copyWith(state: TaskState.done, filePath: path, received: size, total: size, speed: 0, clearEta: true));
        final thumb = await _fetchThumb(t, path);
        try {
          await onDone(_find(id)!, thumb);
        } catch (_) {}
      } else {
        _update(id, (e) => e.copyWith(state: TaskState.failed, error: friendlyEngineError('${r['message'] ?? ''}'), speed: 0));
      }
    } catch (e) {
      _update(id, (x) => x.copyWith(state: TaskState.failed, error: friendlyEngineError('$e'), speed: 0));
    } finally {
      _natDone.remove(proc);
      _nat.remove(proc);
      _pump();
    }
  }

  void _onEngineEvent(Map<String, dynamic> e) {
    final proc = '${e['id']}';
    switch (e['type']) {
      case 'progress':
        final p = _nat[proc];
        if (p == null) return;
        p.feed('${e['line'] ?? ''}', (e['percent'] as num?)?.toDouble(), (e['eta'] as num?)?.toInt());
      case 'done':
      case 'error':
      case 'stopped':
        _natDone[proc]?.complete(e);
    }
  }

  // ───────────────────────── مسار HTTP متعدد الاتصالات ─────────────────────────
  Future<void> _runHttp(DownloadTask t) async {
    final id = t.id;
    _update(id, (e) => e.copyWith(state: TaskState.running, error: ''));
    try {
      var job = _jobs[id];
      if (job == null) {
        final path = t.targetPath ?? await _uniquePath(t);
        if (t.targetPath == null) _update(id, (e) => e.copyWith(targetPath: path));
        job = SegmentedDownload(
          dio: _dio,
          url: t.option.url,
          file: File(path),
          headers: {'User-Agent': _ua, ...t.option.headers},
          fallbackTotal: t.option.sizeBytes,
          connections: connections(),
        );
        _jobs[id] = job;
        _last[id] = 0;
      }
      final ok = await job.run();
      if (!ok) return; // إيقاف مؤقت أو إلغاء
      if (_find(id) == null) return;
      final path = job.file.path;
      final size = await job.file.length();
      if (size == 0) throw Exception('الملف فارغ (قد يكون الرابط منتهي الصلاحية).');
      _jobs.remove(id);
      _last.remove(id);
      _speed.remove(id);
      _update(id, (e) => e.copyWith(state: TaskState.done, filePath: path, received: size, total: size, speed: 0, clearEta: true));
      final thumb = await _fetchThumb(t, path);
      try {
        await onDone(_find(id)!, thumb);
      } catch (_) {}
    } on DioException catch (e) {
      final c = e.response?.statusCode;
      _update(id, (x) => x.copyWith(
          state: TaskState.failed,
          error: (c == 403 || c == 410) ? 'انتهت صلاحية الرابط، حلّله من جديد.' : 'خطأ في الشبكة، حاول مجددًا.',
          speed: 0));
    } catch (e) {
      _update(id, (x) => x.copyWith(state: TaskState.failed, error: '$e', speed: 0));
    } finally {
      _pump();
    }
  }

  // ───────────────────────── التقدم + الخدمة الأمامية ─────────────────────────
  void _tick() {
    var changed = false;
    final next = <DownloadTask>[];
    for (final t in state) {
      if (t.state != TaskState.running) {
        next.add(t);
        continue;
      }
      final job = _jobs[t.id];
      if (job != null) {
        final prev = _last[t.id] ?? job.received;
        final inst = ((job.received - prev) / 0.3).clamp(0, double.infinity).toDouble();
        final sp = (_speed[t.id] ?? 0) * 0.6 + inst * 0.4;
        _speed[t.id] = sp;
        _last[t.id] = job.received;
        final total = job.total ?? t.total;
        final eta = (total != null && sp > 1) ? ((total - job.received) / sp).round() : null;
        next.add(t.copyWith(received: job.received, total: total, speed: sp, etaSec: eta));
        changed = true;
        continue;
      }
      final p = _nat[_proc[t.id]];
      if (p != null && p.hasData) {
        final total = p.totalBytes ?? t.total;
        final rec = (total != null && p.percent != null) ? (total * p.percent! / 100).round() : t.received;
        next.add(t.copyWith(received: rec, total: total, speed: p.speed, etaSec: p.eta));
        changed = true;
        continue;
      }
      next.add(t);
    }
    if (changed) state = next;

    if (++_tickN % 4 == 0) _syncService();
  }

  void _syncService() {
    final live = state.where((t) => t.state == TaskState.running || t.state == TaskState.queued).toList();
    if (live.isEmpty || !notify()) {
      if (_svcOn) {
        _svcOn = false;
        MediaTools.serviceStop();
      }
      return;
    }
    final running = live.where((t) => t.state == TaskState.running).toList();
    final ps = [for (final t in running) if (t.progress != null) t.progress!];
    final pct = ps.isEmpty ? -1 : ((ps.reduce((a, b) => a + b) / ps.length) * 100).round();
    final sp = running.fold<double>(0, (a, t) => a + t.speed);
    final title = live.length == 1 ? live.first.info.title : '${live.length} تنزيلات';
    _svcOn = true;
    MediaTools.serviceUpdate(live.length, pct, sp > 1 ? '$title • ${fmtSpeed(sp)}' : title);
  }

  Future<String?> _fetchThumb(DownloadTask t, String path) async {
    final u = t.info.thumbnail;
    if (u == null || u.isEmpty) return null;
    try {
      final p = '$path.jpg';
      await _dio.download(u, p,
          options: Options(headers: {'User-Agent': _ua}, receiveTimeout: const Duration(seconds: 15)));
      return p;
    } catch (_) {
      return null;
    }
  }

  // ───────────────────────── تحكم ─────────────────────────
  void pause(String id) {
    final t = _find(id);
    if (t == null) return;
    _update(id, (e) => e.copyWith(state: TaskState.paused, speed: 0, clearEta: true));
    if (t.option.nativeSel != null) {
      final p = _proc[id];
      if (p != null) NativeEngine.stop(p);
    } else {
      _jobs[id]?.stop();
    }
  }

  void resume(String id) {
    _update(id, (e) => e.copyWith(state: TaskState.queued, error: ''));
    _pump();
  }

  Future<void> cancel(String id) async {
    final t = _find(id);
    if (t == null) return;
    _update(id, (e) => e.copyWith(state: TaskState.cancelled, speed: 0, clearEta: true));
    if (t.option.nativeSel != null) {
      final p = _proc[id];
      if (p != null) NativeEngine.stop(p);
      final base = t.targetPath;
      if (base != null) {
        // ننتظر قليلًا حتى تتوقف العملية ثم نحذف الملفات الجزئية.
        Future.delayed(const Duration(seconds: 2), () {
          try {
            final slash = base.lastIndexOf('/');
            final dir = Directory(base.substring(0, slash));
            final prefix = '${base.substring(slash + 1)}.';
            for (final f in dir.listSync()) {
              if (f.path.split('/').last.startsWith(prefix)) f.deleteSync();
            }
          } catch (_) {}
        });
      }
    } else {
      _jobs.remove(id)?.dispose(deleteFile: true);
      _last.remove(id);
      _speed.remove(id);
    }
  }

  void remove(String id) {
    state = state.where((t) => t.id != id).toList();
  }

  void clearFinished() {
    state = state.where((t) => t.state != TaskState.done && t.state != TaskState.cancelled).toList();
  }
}

/// يحلّل أسطر تقدم yt-dlp:  [download]  45.2% of  10.00MiB at  1.20MiB/s ETA 00:05
class _NatProg {
  double? percent;
  int? totalBytes;
  double speed = 0;
  int? eta;
  bool hasData = false;

  static final _pct = RegExp(r'(\d+(?:\.\d+)?)%');
  static final _tot = RegExp(r'of\s+~?\s*(\d+(?:\.\d+)?)\s*([KMG]i?B)', caseSensitive: false);
  static final _spd = RegExp(r'at\s+(\d+(?:\.\d+)?)\s*([KMG]i?B)/s', caseSensitive: false);

  static double _mult(String u) {
    switch (u.toUpperCase()[0]) {
      case 'K':
        return 1024;
      case 'M':
        return 1024 * 1024;
      default:
        return 1024 * 1024 * 1024;
    }
  }

  void feed(String line, double? pct, int? etaSec) {
    hasData = true;
    final p = _pct.firstMatch(line);
    percent = p != null ? double.tryParse(p.group(1)!) : (pct != null && pct >= 0 ? pct : percent);
    final t = _tot.firstMatch(line);
    if (t != null) totalBytes = (double.parse(t.group(1)!) * _mult(t.group(2)!)).round();
    final s = _spd.firstMatch(line);
    if (s != null) speed = double.parse(s.group(1)!) * _mult(s.group(2)!);
    if (etaSec != null && etaSec >= 0) eta = etaSec;
  }
}

