/// حظر الإعلانات والمتتبّعات: قائمة نطاقات + أنماط مسارات + إخفاء عناصر (CSS).
/// تُطبَّق على الطلبات الفرعية داخل المتصفح (shouldInterceptRequest) وعلى التنقّل.
const adHosts = <String>{
  'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'google-analytics.com', 'googletagmanager.com',
  'googletagservices.com', 'adservice.google.com', 'pagead2.googlesyndication.com', 'adsystem.com', 'adnxs.com',
  'taboola.com', 'outbrain.com', 'popads.net', 'popcash.net', 'propellerads.com', 'exoclick.com', 'adsterra.com',
  'mgid.com', 'revcontent.com', 'zedo.com', 'yieldmo.com', 'criteo.com', 'criteo.net', 'rubiconproject.com',
  'pubmatic.com', 'openx.net', 'smartadserver.com', 'adform.net', 'advertising.com', 'adcolony.com', 'applovin.com',
  'unityads.unity3d.com', 'moatads.com', 'scorecardresearch.com', 'quantserve.com', 'amazon-adsystem.com',
  'facebook.net', 'connect.facebook.net', 'ads.twitter.com', 'analytics.twitter.com', 'ads-twitter.com',
  'ads.tiktok.com', 'analytics.tiktok.com', 'business-api.tiktok.com', 'log.byteoversea.com', 'mon.tiktokv.com',
  'ads.pinterest.com', 'ads.linkedin.com', 'adsafeprotected.com', 'serving-sys.com', 'bidswitch.net', 'casalemedia.com',
  'contextweb.com', 'sharethrough.com', 'teads.tv', 'triplelift.com', 'adition.com', 'adroll.com', 'bluekai.com',
  'demdex.net', 'everesttech.net', 'exelator.com', 'krxd.net', 'lijit.com', 'mathtag.com', 'media.net', 'nativeads.com',
  'onetag-sys.com', 'pingdom.net', 'adtng.com', 'trafficjunky.net', 'juicyads.com', 'clickadu.com', 'hilltopads.net',
  'richpush.co', 'push.house', 'pushwoosh.com', 'onesignal.com', 'realsrv.com', 'tsyndicate.com', 'a-ads.com',
  'ad-maven.com', 'admaven.com', 'adspyglass.com', 'ero-advertising.com', 'bongacams.com', 'juicyads.com',
  'cdn.mxpnl.com', 'mixpanel.com', 'hotjar.com', 'fullstory.com', 'segment.io', 'branch.io', 'appsflyer.com', 'adjust.com',
  'crashlytics.com', 'app-measurement.com', 'ib.adnxs.com', 'yandex.ru/ads', 'an.yandex.ru', 'mc.yandex.ru',
  'ads.yahoo.com', 'advertising.yahoo.com', 'gemini.yahoo.com', 'ad.doubleclick.net', 'tpc.googlesyndication.com',
  'adsrvr.org', 'agkn.com', 'rlcdn.com', 'tapad.com', 'turn.com', 'undertone.com', 'yieldlab.net', 'smaato.net',
  'inmobi.com', 'mopub.com', 'vungle.com', 'chartboost.com', 'ironsrc.com', 'startappservice.com', 'tapjoy.com',
  'flurry.com', 'optimizely.com', 'newrelic.com', 'bugsnag.com', 'sentry.io', 'popunder.net', 'adskeeper.com',
  'adskeeper.co.uk', 'jads.co', 'monetag.com', 'galaksion.com', 'evadav.com', 'dolohen.com', 'acint.net',
};

final _pathPatterns = RegExp(
  r'(/pagead/|/adserver/|/adframe|/ads/banner|/adsbygoogle|/ad\.js|/ads\.js|/popunder|/popads|/clickunder|/prebid|/gpt\.js|/doubleclick/)',
  caseSensitive: false,
);

bool isAdHost(String host) {
  var h = host.toLowerCase();
  while (true) {
    if (adHosts.contains(h)) return true;
    final i = h.indexOf('.');
    if (i < 0 || h.indexOf('.', i + 1) < 0) return false; // لا نفحص النطاق الأعلى وحده
    h = h.substring(i + 1);
  }
}

bool isAdUrl(Uri u) => isAdHost(u.host) || _pathPatterns.hasMatch(u.path);

/// امتدادات الوسائط التي نرصدها من الشبكة لزر "تحميل".
final mediaUrlPattern = RegExp(r'\.(mp4|m3u8|mpd|webm|mkv|mov|mp3|m4a|aac|ogg|flac|wav)(\?|$)', caseSensitive: false);

const cosmeticAdCss = '''
ins.adsbygoogle,.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[class*="ad-banner"],[class*="adbanner"],[class*="ad_banner"],
[class*="advert"],[id*="advert"],[class*="sponsored"],[aria-label="Advertisement"],[data-ad],[data-ad-slot],iframe[src*="doubleclick"],
iframe[src*="googlesyndication"],iframe[src*="adservice"],.ad-container,.ad-wrapper,.ad-slot,.adslot,#ad,#ads,.ads,.ad-box,
.taboola,[id^="taboola"],[id^="outbrain"],.outbrain,.OUTBRAIN,[class*="popup-ad"],[class*="interstitial"]{display:none!important;visibility:hidden!important;height:0!important;min-height:0!important}
''';

const cookieBannerCss = '''
#onetrust-banner-sdk,#onetrust-consent-sdk,.onetrust-pc-dark-filter,#CybotCookiebotDialog,#cookie-banner,.cookie-banner,
#cookieconsent,.cc-window,.cookie-consent,#cookie-consent,[id*="cookie-notice"],[class*="cookie-notice"],.cmp-container,
#qc-cmp2-container,.truste_overlay,.truste_box_overlay,#sp_message_container_,[id^="sp_message_container"]{display:none!important}
html,body{overflow:auto!important}
''';

/// يمنع window.open بلا لمسة من المستخدم (النوافذ المنبثقة الإعلانية).
const popupGuardJs = '''
(function(){
  if (window.__sanadPopup) return; window.__sanadPopup = 1;
  var o = window.open;
  window.open = function(){
    try { if (navigator.userActivation && !navigator.userActivation.isActive) return null; } catch(e){}
    return o.apply(window, arguments);
  };
})();
''';

/// يرصد عناصر الفيديو/الصوت في الصفحة ويرسلها إلى Dart.
const mediaSnifferJs = '''
(function(){
  if (window.__sanadSniff) return; window.__sanadSniff = 1;
  var seen = {};
  function scan(){
    var out = [];
    document.querySelectorAll('video,audio,source').forEach(function(e){
      var s = e.currentSrc || e.src;
      if (s && s.indexOf('http') === 0 && !seen[s]) { seen[s] = 1; out.push(s); }
    });
    if (out.length && window.flutter_inappwebview) window.flutter_inappwebview.callHandler('media', out);
  }
  setInterval(scan, 2500); scan();
})();
''';

String styleInjectJs(String css, String id) => '''
(function(){
  var s = document.getElementById('$id');
  if (!s) { s = document.createElement('style'); s.id = '$id'; (document.head || document.documentElement).appendChild(s); }
  s.textContent = ${_jsString(css)};
})();
''';

String _jsString(String s) => "'${s.replaceAll('\\', '\\\\').replaceAll("'", "\\'").replaceAll('\n', ' ')}'";

const darkWebCss = 'html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}img,video,picture,canvas,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}';

const searchEngines = <(String, String)>[
  ('Google', 'https://www.google.com/search?q='),
  ('DuckDuckGo', 'https://duckduckgo.com/?q='),
  ('Bing', 'https://www.bing.com/search?q='),
  ('Brave', 'https://search.brave.com/search?q='),
  ('Yandex', 'https://yandex.com/search/?text='),
];

const desktopUa =
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
