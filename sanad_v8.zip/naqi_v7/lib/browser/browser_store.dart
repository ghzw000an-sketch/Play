import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/settings.dart';
import '../engine/native_engine.dart';

// ───────────────────────── علامات وسجل ─────────────────────────
class Bookmark {
  final String title;
  final String url;
  const Bookmark(this.title, this.url);
  Map<String, dynamic> toJson() => {'t': title, 'u': url};
  factory Bookmark.fromJson(Map<String, dynamic> j) => Bookmark((j['t'] ?? '') as String, (j['u'] ?? '') as String);
}

class HistoryEntry {
  final String title;
  final String url;
  final int ts;
  const HistoryEntry(this.title, this.url, this.ts);
  Map<String, dynamic> toJson() => {'t': title, 'u': url, 'ts': ts};
  factory HistoryEntry.fromJson(Map<String, dynamic> j) =>
      HistoryEntry((j['t'] ?? '') as String, (j['u'] ?? '') as String, (j['ts'] as num?)?.toInt() ?? 0);
}

List<T> _loadList<T>(SharedPreferences p, String key, T Function(Map<String, dynamic>) f) {
  final raw = p.getString(key);
  if (raw == null) return [];
  try {
    return [for (final e in jsonDecode(raw) as List) f(Map<String, dynamic>.from(e as Map))];
  } catch (_) {
    return [];
  }
}

class BookmarksNotifier extends StateNotifier<List<Bookmark>> {
  BookmarksNotifier(this._p) : super(_loadList(_p, 'bm_v1', Bookmark.fromJson));
  final SharedPreferences _p;
  void _save() => _p.setString('bm_v1', jsonEncode([for (final b in state) b.toJson()]));
  bool has(String url) => state.any((b) => b.url == url);
  void toggle(String title, String url) {
    state = has(url) ? state.where((b) => b.url != url).toList() : [Bookmark(title.isEmpty ? url : title, url), ...state];
    _save();
  }

  void remove(String url) {
    state = state.where((b) => b.url != url).toList();
    _save();
  }
}

class HistoryNotifier extends StateNotifier<List<HistoryEntry>> {
  HistoryNotifier(this._p) : super(_loadList(_p, 'hist_v1', HistoryEntry.fromJson));
  final SharedPreferences _p;
  void _save() => _p.setString('hist_v1', jsonEncode([for (final h in state) h.toJson()]));
  void add(String title, String url) {
    if (url.isEmpty || url == 'about:blank') return;
    final rest = state.where((h) => h.url != url).take(299).toList();
    state = [HistoryEntry(title.isEmpty ? url : title, url, DateTime.now().millisecondsSinceEpoch), ...rest];
    _save();
  }

  void clear() {
    state = [];
    _save();
  }
}

final bookmarksProvider = StateNotifierProvider<BookmarksNotifier, List<Bookmark>>((ref) => BookmarksNotifier(ref.watch(prefsProvider)));
final historyProvider = StateNotifierProvider<HistoryNotifier, List<HistoryEntry>>((ref) => HistoryNotifier(ref.watch(prefsProvider)));

// ───────────────────────── إضافات (سكربتات المستخدم) ─────────────────────────
class UserScriptItem {
  final String id;
  final String name;
  final String code;
  final List<String> matches;
  final List<String> excludes;
  final bool enabled;
  final String? source; // رابط التثبيت
  const UserScriptItem({
    required this.id,
    required this.name,
    required this.code,
    this.matches = const ['*'],
    this.excludes = const [],
    this.enabled = true,
    this.source,
  });

  UserScriptItem copyWith({bool? enabled}) => UserScriptItem(
      id: id, name: name, code: code, matches: matches, excludes: excludes, enabled: enabled ?? this.enabled, source: source);

  Map<String, dynamic> toJson() =>
      {'id': id, 'n': name, 'c': code, 'm': matches, 'x': excludes, 'e': enabled, 's': source};
  factory UserScriptItem.fromJson(Map<String, dynamic> j) => UserScriptItem(
        id: j['id'] as String,
        name: (j['n'] ?? 'Script') as String,
        code: (j['c'] ?? '') as String,
        matches: [for (final e in (j['m'] as List? ?? ['*'])) '$e'],
        excludes: [for (final e in (j['x'] as List? ?? [])) '$e'],
        enabled: j['e'] != false,
        source: j['s'] as String?,
      );

  /// يحلّل ترويسة // ==UserScript== (@name/@match/@include/@exclude).
  static UserScriptItem parse(String code, {String? source}) {
    String name = 'سكربت بلا اسم';
    final matches = <String>[];
    final excludes = <String>[];
    final head = RegExp(r'//\s*==UserScript==([\s\S]*?)//\s*==/UserScript==').firstMatch(code)?.group(1) ?? '';
    for (final line in head.split('\n')) {
      final m = RegExp(r'//\s*@(\S+)\s+(.*)$').firstMatch(line.trim());
      if (m == null) continue;
      final k = m.group(1)!;
      final v = m.group(2)!.trim();
      if (k == 'name' && name == 'سكربت بلا اسم') name = v;
      if (k == 'match' || k == 'include') matches.add(v);
      if (k == 'exclude' || k == 'exclude-match') excludes.add(v);
    }
    return UserScriptItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      code: code,
      matches: matches.isEmpty ? const ['*'] : matches,
      excludes: excludes,
      source: source,
    );
  }

  static RegExp _glob(String g) {
    if (g == '*' || g == '<all_urls>') return RegExp('.*');
    if (g.startsWith('/') && g.endsWith('/') && g.length > 2) return RegExp(g.substring(1, g.length - 1));
    final esc = RegExp.escape(g).replaceAll(r'\*', '.*').replaceFirst(RegExp(r'^https\?:'), 'https?:');
    return RegExp('^${esc.replaceFirst(r'\*://', 'https?://').replaceFirst('.*://', 'https?://')}\$');
  }

  bool appliesTo(String url) {
    if (!enabled) return false;
    for (final x in excludes) {
      if (_glob(x).hasMatch(url)) return false;
    }
    return matches.any((m) => _glob(m).hasMatch(url));
  }

  /// يغلّف الشيفرة بدوال GM_* الأساسية.
  String wrapped() => '''
(function(){
  var unsafeWindow = window;
  function GM_addStyle(css){ var s=document.createElement('style'); s.textContent=css; (document.head||document.documentElement).appendChild(s); return s; }
  function GM_getValue(k,d){ try{ var v=localStorage.getItem('gm_$id'+k); return v===null?d:JSON.parse(v);}catch(e){return d;} }
  function GM_setValue(k,v){ try{ localStorage.setItem('gm_$id'+k, JSON.stringify(v)); }catch(e){} }
  function GM_log(){ console.log.apply(console, arguments); }
  function GM_openInTab(u){ window.open(u,'_blank'); }
  try {
$code
  } catch(e) { console.log('Sanad userscript error', e); }
})();
''';
}

class UserScriptsNotifier extends StateNotifier<List<UserScriptItem>> {
  UserScriptsNotifier(this._p) : super(_loadList(_p, 'us_v1', UserScriptItem.fromJson));
  final SharedPreferences _p;
  void _save() => _p.setString('us_v1', jsonEncode([for (final s in state) s.toJson()]));
  void add(UserScriptItem s) {
    state = [s, ...state];
    _save();
  }

  void toggle(String id) {
    state = [for (final s in state) s.id == id ? s.copyWith(enabled: !s.enabled) : s];
    _save();
  }

  void remove(String id) {
    state = state.where((s) => s.id != id).toList();
    _save();
  }

  /// يثبّت سكربتًا من رابط مباشر (مثل greasyfork .user.js).
  Future<UserScriptItem> install(String url) async {
    final r = await Dio().get<String>(url, options: Options(responseType: ResponseType.plain, receiveTimeout: const Duration(seconds: 20)));
    final code = r.data ?? '';
    if (!code.contains('==UserScript==')) throw Exception('الملف ليس سكربت مستخدم صالحًا');
    final s = UserScriptItem.parse(code, source: url);
    add(s);
    return s;
  }
}

final userScriptsProvider =
    StateNotifierProvider<UserScriptsNotifier, List<UserScriptItem>>((ref) => UserScriptsNotifier(ref.watch(prefsProvider)));

// ───────────────────────── كوكيز تسجيل الدخول لمحرك التنزيل ─────────────────────────
const loginSites = <(String name, String url, List<String> domains)>[
  ('Instagram', 'https://www.instagram.com/accounts/login/', ['instagram.com']),
  ('Facebook', 'https://m.facebook.com/login', ['facebook.com']),
  ('TikTok', 'https://www.tiktok.com/login', ['tiktok.com']),
  ('Snapchat', 'https://accounts.snapchat.com/', ['snapchat.com']),
  ('X (Twitter)', 'https://x.com/i/flow/login', ['x.com', 'twitter.com']),
  ('Pinterest', 'https://www.pinterest.com/login/', ['pinterest.com']),
];

/// يصدّر كوكيز المنصات المسجَّل دخولها (Netscape) ويسلّمها لمحرك yt-dlp.
/// الكوكيز تبقى على جهازك فقط ولا تُرسل لأي خادم غير المنصة نفسها.
Future<int> exportCookiesToEngine() async {
  final cm = CookieManager.instance();
  final buf = StringBuffer('# Netscape HTTP Cookie File\n');
  var n = 0;
  final exp = (DateTime.now().millisecondsSinceEpoch ~/ 1000) + 60 * 60 * 24 * 180;
  for (final s in loginSites) {
    for (final d in s.$3) {
      for (final host in ['https://www.$d', 'https://$d', 'https://m.$d']) {
        try {
          final cookies = await cm.getCookies(url: WebUri(host));
          for (final c in cookies) {
            final v = c.value?.toString() ?? '';
            if (v.isEmpty) continue;
            buf.writeln('.$d\tTRUE\t/\tTRUE\t$exp\t${c.name}\t$v');
            n++;
          }
        } catch (_) {}
      }
    }
  }
  await NativeEngine.setCookies(n == 0 ? '' : buf.toString());
  return n;
}

Future<void> clearEngineCookies() => NativeEngine.setCookies('');
