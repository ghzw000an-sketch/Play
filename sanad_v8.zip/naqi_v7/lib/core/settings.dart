import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

final prefsProvider = Provider<SharedPreferences>((ref) => throw UnimplementedError('prefs not loaded'));

const accentSeeds = <int>[0xFF22D3EE, 0xFF3B82F6, 0xFF6C4CF5, 0xFFB620E0, 0xFFE4572E, 0xFF2E9E5B, 0xFFD6336C, 0xFFFFB020];
const textColors = <int>[0xFFFFFFFF, 0xFFE0F2FE, 0xFFFDE68A, 0xFFBBF7D0, 0xFFFBCFE8, 0xFF111827];

class AppSettings {
  final ThemeMode themeMode;
  final bool hideCookieBanners;
  final bool forceDarkWeb;
  final int browserTextZoom;
  final bool desktopMode;
  final bool httpsOnly;
  final int searchEngine;
  final bool browserIncognito;
  final bool popupBlock;
  final bool adBlock;
  final int maxQuality;
  final bool wifiOnly;
  final bool siteFolders;
  final String saveDir;
  final int seed;
  final bool amoled;
  final int maxParallel;
  final bool autoGallery;
  final bool autoAnalyze;
  final bool haptics;
  final bool bestQuality;
  final int connections;
  final bool notify;
  final bool autoUpdateEngine;
  final bool preferAudio;
  final bool appLock;
  final bool biometric;
  final bool autoVault;
  final bool autoPlay;
  final bool vaultBiometric;
  final bool clipWatch;
  final double glassBlur;
  final double glassOpacity;
  final double radius;
  final double textScale;
  final int textColor;
  const AppSettings({
    this.themeMode = ThemeMode.dark,
    this.hideCookieBanners = true,
    this.forceDarkWeb = false,
    this.browserTextZoom = 100,
    this.desktopMode = false,
    this.httpsOnly = false,
    this.searchEngine = 0,
    this.browserIncognito = true,
    this.popupBlock = true,
    this.adBlock = true,
    this.maxQuality = 0,
    this.wifiOnly = false,
    this.siteFolders = false,
    this.saveDir = 'Movies/Sanad',
    this.seed = 0xFF22D3EE,
    this.amoled = false,
    this.maxParallel = 2,
    this.autoGallery = true,
    this.autoAnalyze = false,
    this.haptics = true,
    this.bestQuality = false,
    this.connections = 8,
    this.notify = true,
    this.autoUpdateEngine = true,
    this.preferAudio = false,
    this.appLock = false,
    this.biometric = false,
    this.autoVault = false,
    this.autoPlay = false,
    this.vaultBiometric = false,
    this.clipWatch = false,
    this.glassBlur = 16.0,
    this.glassOpacity = 0.10,
    this.radius = 24.0,
    this.textScale = 1.0,
    this.textColor = 0,
  });

  AppSettings copyWith({
    ThemeMode? themeMode,
    bool? hideCookieBanners,
    bool? forceDarkWeb,
    int? browserTextZoom,
    bool? desktopMode,
    bool? httpsOnly,
    int? searchEngine,
    bool? browserIncognito,
    bool? popupBlock,
    bool? adBlock,
    int? maxQuality,
    bool? wifiOnly,
    bool? siteFolders,
    String? saveDir,
    int? seed,
    bool? amoled,
    int? maxParallel,
    bool? autoGallery,
    bool? autoAnalyze,
    bool? haptics,
    bool? bestQuality,
    int? connections,
    bool? notify,
    bool? autoUpdateEngine,
    bool? preferAudio,
    bool? appLock,
    bool? biometric,
    bool? autoVault,
    bool? autoPlay,
    bool? vaultBiometric,
    bool? clipWatch,
    double? glassBlur,
    double? glassOpacity,
    double? radius,
    double? textScale,
    int? textColor,
  }) =>
      AppSettings(
        themeMode: themeMode ?? this.themeMode,
        hideCookieBanners: hideCookieBanners ?? this.hideCookieBanners,
        forceDarkWeb: forceDarkWeb ?? this.forceDarkWeb,
        browserTextZoom: browserTextZoom ?? this.browserTextZoom,
        desktopMode: desktopMode ?? this.desktopMode,
        httpsOnly: httpsOnly ?? this.httpsOnly,
        searchEngine: searchEngine ?? this.searchEngine,
        browserIncognito: browserIncognito ?? this.browserIncognito,
        popupBlock: popupBlock ?? this.popupBlock,
        adBlock: adBlock ?? this.adBlock,
        maxQuality: maxQuality ?? this.maxQuality,
        wifiOnly: wifiOnly ?? this.wifiOnly,
        siteFolders: siteFolders ?? this.siteFolders,
        saveDir: saveDir ?? this.saveDir,
        seed: seed ?? this.seed,
        amoled: amoled ?? this.amoled,
        maxParallel: maxParallel ?? this.maxParallel,
        autoGallery: autoGallery ?? this.autoGallery,
        autoAnalyze: autoAnalyze ?? this.autoAnalyze,
        haptics: haptics ?? this.haptics,
        bestQuality: bestQuality ?? this.bestQuality,
        connections: connections ?? this.connections,
        notify: notify ?? this.notify,
        autoUpdateEngine: autoUpdateEngine ?? this.autoUpdateEngine,
        preferAudio: preferAudio ?? this.preferAudio,
        appLock: appLock ?? this.appLock,
        biometric: biometric ?? this.biometric,
        autoVault: autoVault ?? this.autoVault,
        autoPlay: autoPlay ?? this.autoPlay,
        vaultBiometric: vaultBiometric ?? this.vaultBiometric,
        clipWatch: clipWatch ?? this.clipWatch,
        glassBlur: glassBlur ?? this.glassBlur,
        glassOpacity: glassOpacity ?? this.glassOpacity,
        radius: radius ?? this.radius,
        textScale: textScale ?? this.textScale,
        textColor: textColor ?? this.textColor,
      );
}

class SettingsNotifier extends StateNotifier<AppSettings> {
  SettingsNotifier(this._p) : super(_load(_p));
  final SharedPreferences _p;

  static const _d = AppSettings();

  static AppSettings _load(SharedPreferences p) => AppSettings(
        themeMode: ThemeMode.values[(p.getInt('themeMode') ?? ThemeMode.dark.index).clamp(0, 2)],
        hideCookieBanners: p.getBool('hideCookieBanners') ?? _d.hideCookieBanners,
        forceDarkWeb: p.getBool('forceDarkWeb') ?? _d.forceDarkWeb,
        browserTextZoom: p.getInt('browserTextZoom') ?? _d.browserTextZoom,
        desktopMode: p.getBool('desktopMode') ?? _d.desktopMode,
        httpsOnly: p.getBool('httpsOnly') ?? _d.httpsOnly,
        searchEngine: p.getInt('searchEngine') ?? _d.searchEngine,
        browserIncognito: p.getBool('browserIncognito') ?? _d.browserIncognito,
        popupBlock: p.getBool('popupBlock') ?? _d.popupBlock,
        adBlock: p.getBool('adBlock') ?? _d.adBlock,
        maxQuality: p.getInt('maxQuality') ?? _d.maxQuality,
        wifiOnly: p.getBool('wifiOnly') ?? _d.wifiOnly,
        siteFolders: p.getBool('siteFolders') ?? _d.siteFolders,
        saveDir: p.getString('saveDir') ?? _d.saveDir,
        seed: p.getInt('seed') ?? _d.seed,
        amoled: p.getBool('amoled') ?? _d.amoled,
        maxParallel: (p.getInt('maxParallel') ?? _d.maxParallel).clamp(1, 5),
        autoGallery: p.getBool('autoGallery') ?? _d.autoGallery,
        autoAnalyze: p.getBool('autoAnalyze') ?? _d.autoAnalyze,
        haptics: p.getBool('haptics') ?? _d.haptics,
        bestQuality: p.getBool('bestQuality') ?? _d.bestQuality,
        connections: p.getInt('connections') ?? _d.connections,
        notify: p.getBool('notify') ?? _d.notify,
        autoUpdateEngine: p.getBool('autoUpdateEngine') ?? _d.autoUpdateEngine,
        preferAudio: p.getBool('preferAudio') ?? _d.preferAudio,
        appLock: p.getBool('appLock') ?? _d.appLock,
        biometric: p.getBool('biometric') ?? _d.biometric,
        autoVault: p.getBool('autoVault') ?? _d.autoVault,
        autoPlay: p.getBool('autoPlay') ?? _d.autoPlay,
        vaultBiometric: p.getBool('vaultBiometric') ?? _d.vaultBiometric,
        clipWatch: p.getBool('clipWatch') ?? _d.clipWatch,
        glassBlur: (p.getDouble('glassBlur') ?? _d.glassBlur).clamp(0.0, 30.0),
        glassOpacity: (p.getDouble('glassOpacity') ?? _d.glassOpacity).clamp(0.02, 0.45),
        radius: (p.getDouble('radius') ?? _d.radius).clamp(6.0, 40.0),
        textScale: (p.getDouble('textScale') ?? _d.textScale).clamp(0.8, 1.5),
        textColor: p.getInt('textColor') ?? _d.textColor,
      );

  void change({
    ThemeMode? themeMode,
    bool? hideCookieBanners,
    bool? forceDarkWeb,
    int? browserTextZoom,
    bool? desktopMode,
    bool? httpsOnly,
    int? searchEngine,
    bool? browserIncognito,
    bool? popupBlock,
    bool? adBlock,
    int? maxQuality,
    bool? wifiOnly,
    bool? siteFolders,
    String? saveDir,
    int? seed,
    bool? amoled,
    int? maxParallel,
    bool? autoGallery,
    bool? autoAnalyze,
    bool? haptics,
    bool? bestQuality,
    int? connections,
    bool? notify,
    bool? autoUpdateEngine,
    bool? preferAudio,
    bool? appLock,
    bool? biometric,
    bool? autoVault,
    bool? autoPlay,
    bool? vaultBiometric,
    bool? clipWatch,
    double? glassBlur,
    double? glassOpacity,
    double? radius,
    double? textScale,
    int? textColor,
  }) {
    state = state.copyWith(
      themeMode: themeMode,
      hideCookieBanners: hideCookieBanners,
      forceDarkWeb: forceDarkWeb,
      browserTextZoom: browserTextZoom,
      desktopMode: desktopMode,
      httpsOnly: httpsOnly,
      searchEngine: searchEngine,
      browserIncognito: browserIncognito,
      popupBlock: popupBlock,
      adBlock: adBlock,
      maxQuality: maxQuality,
      wifiOnly: wifiOnly,
      siteFolders: siteFolders,
      saveDir: saveDir,
      seed: seed,
      amoled: amoled,
      maxParallel: maxParallel,
      autoGallery: autoGallery,
      autoAnalyze: autoAnalyze,
      haptics: haptics,
      bestQuality: bestQuality,
      connections: connections,
      notify: notify,
      autoUpdateEngine: autoUpdateEngine,
      preferAudio: preferAudio,
      appLock: appLock,
      biometric: biometric,
      autoVault: autoVault,
      autoPlay: autoPlay,
      vaultBiometric: vaultBiometric,
      clipWatch: clipWatch,
      glassBlur: glassBlur,
      glassOpacity: glassOpacity,
      radius: radius,
      textScale: textScale,
      textColor: textColor,
    );
    _p.setInt('themeMode', state.themeMode.index);
    _p.setBool('hideCookieBanners', state.hideCookieBanners);
    _p.setBool('forceDarkWeb', state.forceDarkWeb);
    _p.setInt('browserTextZoom', state.browserTextZoom);
    _p.setBool('desktopMode', state.desktopMode);
    _p.setBool('httpsOnly', state.httpsOnly);
    _p.setInt('searchEngine', state.searchEngine);
    _p.setBool('browserIncognito', state.browserIncognito);
    _p.setBool('popupBlock', state.popupBlock);
    _p.setBool('adBlock', state.adBlock);
    _p.setInt('maxQuality', state.maxQuality);
    _p.setBool('wifiOnly', state.wifiOnly);
    _p.setBool('siteFolders', state.siteFolders);
    _p.setString('saveDir', state.saveDir);
    _p.setInt('seed', state.seed);
    _p.setBool('amoled', state.amoled);
    _p.setInt('maxParallel', state.maxParallel);
    _p.setBool('autoGallery', state.autoGallery);
    _p.setBool('autoAnalyze', state.autoAnalyze);
    _p.setBool('haptics', state.haptics);
    _p.setBool('bestQuality', state.bestQuality);
    _p.setInt('connections', state.connections);
    _p.setBool('notify', state.notify);
    _p.setBool('autoUpdateEngine', state.autoUpdateEngine);
    _p.setBool('preferAudio', state.preferAudio);
    _p.setBool('appLock', state.appLock);
    _p.setBool('biometric', state.biometric);
    _p.setBool('autoVault', state.autoVault);
    _p.setBool('autoPlay', state.autoPlay);
    _p.setBool('vaultBiometric', state.vaultBiometric);
    _p.setBool('clipWatch', state.clipWatch);
    _p.setDouble('glassBlur', state.glassBlur);
    _p.setDouble('glassOpacity', state.glassOpacity);
    _p.setDouble('radius', state.radius);
    _p.setDouble('textScale', state.textScale);
    _p.setInt('textColor', state.textColor);
  }

  /// يعيد ضبط خيارات الشكل فقط إلى الافتراضي.
  void resetAppearance() => change(
        seed: _d.seed,
        amoled: _d.amoled,
        glassBlur: _d.glassBlur,
        glassOpacity: _d.glassOpacity,
        radius: _d.radius,
        textScale: _d.textScale,
        textColor: _d.textColor,
        themeMode: ThemeMode.dark,
      );
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, AppSettings>((ref) => SettingsNotifier(ref.watch(prefsProvider)));

void haptic(WidgetRef ref, {bool strong = false}) {
  if (!ref.read(settingsProvider).haptics) return;
  strong ? HapticFeedback.mediumImpact() : HapticFeedback.lightImpact();
}
