import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../engine/extractor_base.dart';
import 'models.dart';
import 'providers.dart';
import 'settings.dart';
import '../engine/sys_native.dart';

final _seen = <String, DateTime>{};

/// يحلّل الرابط ويبدأ تنزيله بأعلى جودة (أو MP3 حسب الإعداد). يرجع رسالة للمستخدم أو null.
Future<String?> autoDownloadLink(ProviderContainer c, String url) async {
  final now = DateTime.now();
  final last = _seen[url];
  if (last != null && now.difference(last).inSeconds < 30) return null;
  _seen[url] = now;
  if (detectSite(url) == Site.unknown) return null;
  try {
    final info = await c.read(extractorProvider).analyze(url);
    final st = c.read(settingsProvider);
    if (st.wifiOnly && !await Sys.isWifi()) return 'سند: «واي فاي فقط» مفعّل — اتصل بالواي فاي أو عطّل الخيار.';
    final opt = pickOption(info, maxHeight: st.maxQuality, preferAudio: st.preferAudio);
    c.read(downloadManagerProvider.notifier).enqueue(info, opt, toVault: false);
    return 'سند: بدأ تحميل «${info.title}»';
  } catch (e) {
    return e is ExtractorException ? 'سند: ${e.message}' : 'سند: تعذّر تحليل الرابط';
  }
}

/// أفضل خيار ضمن حدّ الجودة (0 = الأعلى). يفضّل الصوت إن طُلب.
MediaOption pickOption(MediaInfo info, {int maxHeight = 0, bool preferAudio = false}) {
  final audio = info.options.where((o) => o.audioOnly).toList();
  if (preferAudio && audio.isNotEmpty) return audio.first;
  if (maxHeight <= 0) return info.best;
  MediaOption? best;
  var bestH = -1;
  for (final o in info.options.where((o) => !o.audioOnly)) {
    final m = RegExp(r'(\d{3,4})p').firstMatch(o.label);
    if (m == null) continue;
    final h = int.parse(m.group(1)!);
    if (h <= maxHeight && h > bestH) {
      best = o;
      bestH = h;
    }
  }
  return best ?? info.best;
}
