import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:local_auth/local_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'settings.dart';

/// جسر التشفير الأصلي: AES-256-GCM بمفتاح داخل Android Keystore لا يغادر الجهاز.
class VaultNative {
  static const _c = MethodChannel('sanad/vault');

  static Future<void> encrypt(String src, String dst) => _c.invokeMethod('encrypt', {'src': src, 'dst': dst});
  static Future<void> decrypt(String src, String dst) => _c.invokeMethod('decrypt', {'src': src, 'dst': dst});

  /// يكتب أصفارًا فوق الملف ثم يحذفه (حذف آمن).
  static Future<void> wipe(String path) async {
    try {
      await _c.invokeMethod('wipe', {'path': path});
    } catch (_) {
      try {
        final f = File(path);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  static Future<String> hashPin(String pin, String salt) async =>
      (await _c.invokeMethod<String>('hashPin', {'pin': pin, 'salt': salt})) ?? '';
}

/// رمزان منفصلان: رمز قفل التطبيق (vault=false) ورمز الخزنة (vault=true).
class PinStore {
  static String _k(bool vault, String n) => vault ? 'v${n[0].toUpperCase()}${n.substring(1)}' : n;

  static bool has(SharedPreferences p, {bool vault = false}) => (p.getString(_k(vault, 'pinHash')) ?? '').isNotEmpty;

  static Future<void> set(SharedPreferences p, String pin, {bool vault = false}) async {
    final r = Random.secure();
    final salt = List.generate(16, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
    await p.setString(_k(vault, 'pinSalt'), salt);
    await p.setString(_k(vault, 'pinHash'), await VaultNative.hashPin(pin, salt));
  }

  static Future<bool> verify(SharedPreferences p, String pin, {bool vault = false}) async {
    final salt = p.getString(_k(vault, 'pinSalt')) ?? '';
    final hash = p.getString(_k(vault, 'pinHash')) ?? '';
    if (salt.isEmpty || hash.isEmpty) return false;
    return (await VaultNative.hashPin(pin, salt)) == hash;
  }
}

class Biometric {
  static final _a = LocalAuthentication();

  static Future<bool> available() async {
    try {
      return await _a.canCheckBiometrics || await _a.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  static Future<bool> authenticate(String reason) async {
    try {
      return await _a.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: false, stickyAuth: true),
      );
    } catch (_) {
      return false;
    }
  }
}

class VaultItem {
  final String id;
  final String title;
  final int kind; // 0 صورة، 1 فيديو، 2 أخرى
  final int size;
  final String encPath;
  final String ext;
  final int createdAt;
  final int originKind; // 0 مكتبة التطبيق، 1 ملف خارجي (استوديو/جهاز)
  final String? origPath; // مسار الأصل داخل التطبيق
  final String? mime;
  final String? relPath; // مجلد الأصل في الاستوديو (مثل DCIM/Camera)
  final Map<String, dynamic>? lib; // بيانات عنصر المكتبة الأصلي
  const VaultItem({
    required this.id,
    required this.title,
    required this.kind,
    required this.size,
    required this.encPath,
    required this.ext,
    required this.createdAt,
    this.originKind = 0,
    this.origPath,
    this.mime,
    this.relPath,
    this.lib,
  });

  Map<String, dynamic> toJson() =>
      {
        'id': id,
        'title': title,
        'kind': kind,
        'size': size,
        'encPath': encPath,
        'ext': ext,
        'createdAt': createdAt,
        'originKind': originKind,
        'origPath': origPath,
        'mime': mime,
        'relPath': relPath,
        'lib': lib,
      };

  factory VaultItem.fromJson(Map<String, dynamic> j) => VaultItem(
        id: j['id'] as String,
        title: (j['title'] ?? '') as String,
        kind: (j['kind'] as num?)?.toInt() ?? 2,
        size: (j['size'] as num?)?.toInt() ?? 0,
        encPath: j['encPath'] as String,
        ext: (j['ext'] ?? '') as String,
        createdAt: (j['createdAt'] as num?)?.toInt() ?? 0,
        originKind: (j['originKind'] as num?)?.toInt() ?? 0,
        origPath: j['origPath'] as String?,
        mime: j['mime'] as String?,
        relPath: j['relPath'] as String?,
        lib: j['lib'] == null ? null : Map<String, dynamic>.from(j['lib'] as Map),
      );
}

int vaultKindFor(String path) {
  final p = path.toLowerCase();
  if (RegExp(r'\.(jpg|jpeg|png|webp|gif|heic)$').hasMatch(p)) return 0;
  if (RegExp(r'\.(mp4|mkv|webm|mov|3gp|avi|m4v|ts|flv)$').hasMatch(p)) return 1;
  if (RegExp(r'\.(mp3|m4a|aac|wav|flac|ogg|opus|wma|amr)$').hasMatch(p)) return 2;
  return 3; // مستندات وأي صيغة أخرى
}

class VaultNotifier extends StateNotifier<List<VaultItem>> {
  VaultNotifier(this._p) : super(_load(_p));
  final SharedPreferences _p;
  static const _key = 'vault_v1';

  static List<VaultItem> _load(SharedPreferences p) {
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      return [for (final e in jsonDecode(raw) as List) VaultItem.fromJson(Map<String, dynamic>.from(e as Map))];
    } catch (_) {
      return [];
    }
  }

  void _save() => _p.setString(_key, jsonEncode([for (final i in state) i.toJson()]));

  Future<Directory> _dir() async {
    final d = Directory('${(await getApplicationDocumentsDirectory()).path}/vault');
    await d.create(recursive: true);
    return d;
  }

  /// يشفّر الملف إلى الخزنة ثم يحذف الأصل حذفًا آمنًا، مع تسجيل مكانه الأصلي لإعادته عند الاستعادة.
  Future<VaultItem?> addFile(
    String path,
    String title, {
    Map<String, dynamic>? lib,
    int originKind = 0,
    String? mime,
    String? relPath,
    String? extOverride,
  }) async {
    final f = File(path);
    if (!await f.exists()) return null;
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final enc = '${(await _dir()).path}/$id.enc';
    final size = await f.length();
    await VaultNative.encrypt(path, enc);
    final dot = path.lastIndexOf('.');
    final ext = extOverride ?? (dot > path.lastIndexOf('/') ? path.substring(dot + 1) : '');
    final item = VaultItem(
      id: id,
      title: title,
      kind: vaultKindFor('x.$ext'),
      size: size,
      encPath: enc,
      ext: ext,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      originKind: lib != null ? 0 : originKind,
      origPath: lib != null ? path : null,
      mime: mime,
      relPath: relPath,
      lib: lib,
    );
    state = [item, ...state];
    _save();
    await VaultNative.wipe(path);
    return item;
  }

  /// يفك التشفير إلى ملف مؤقت للعرض (يجب حذفه بعد الاستعمال).
  Future<String> decryptToTemp(VaultItem i) async {
    final tmp = Directory('${(await getTemporaryDirectory()).path}/vt');
    await tmp.create(recursive: true);
    final dest = '${tmp.path}/${i.id}${i.ext.isEmpty ? '' : '.${i.ext}'}';
    await VaultNative.decrypt(i.encPath, dest);
    return dest;
  }

  /// يفك التشفير إلى مسار محدد (ينشئ المجلدات اللازمة).
  Future<void> decryptTo(VaultItem i, String path) async {
    await File(path).parent.create(recursive: true);
    await VaultNative.decrypt(i.encPath, path);
  }

  /// مسار فارغ بجانب Sanad/Restored عند عدم توفر مكان الأصل.
  Future<String> fallbackPath(VaultItem i) async {
    final base = (await getExternalStorageDirectory()) ?? await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/Sanad/Restored');
    await dir.create(recursive: true);
    final safe = i.title.replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), ' ').trim();
    final ext = i.ext.isEmpty ? '' : '.${i.ext}';
    var path = '${dir.path}/${safe.isEmpty ? i.id : safe}$ext';
    var n = 2;
    while (await File(path).exists()) {
      path = '${dir.path}/$safe ($n)$ext';
      n++;
    }
    return path;
  }

  Future<void> remove(VaultItem i) async {
    await VaultNative.wipe(i.encPath);
    state = state.where((x) => x.id != i.id).toList();
    _save();
  }
}

final vaultProvider =
    StateNotifierProvider<VaultNotifier, List<VaultItem>>((ref) => VaultNotifier(ref.watch(prefsProvider)));

/// هل الخزنة مفتوحة في هذه الجلسة؟ (تُقفل عند مغادرة التبويب أو الخلفية).
final vaultUnlockedProvider = StateProvider<bool>((_) => false);
