#!/usr/bin/env python3
"""
يُشغَّل بعد `flutter create` (أو مع مجلد android موجود) ليضيف إلى مشروع أندرويد:
  • محرك yt-dlp + FFmpeg (youtubedl-android)
  • خدمة التنزيل في الخلفية + إشعار
  • استقبال الروابط من قائمة المشاركة
  • كود Kotlin (القنوات) وتعديلات Gradle والـ Manifest
الاستعمال: python3 native/apply_native.py <مجلد المشروع>
"""
import os
import re
import sys

YTDL = "0.18.1"
root = sys.argv[1] if len(sys.argv) > 1 else "."
here = os.path.dirname(os.path.abspath(__file__))
app = os.path.join(root, "android", "app")
if not os.path.isdir(app):
    sys.exit("android/app not found: run flutter create first")

gradle = next((p for p in (os.path.join(app, "build.gradle.kts"), os.path.join(app, "build.gradle")) if os.path.exists(p)), None)
if not gradle:
    sys.exit("app build.gradle not found")
kts = gradle.endswith(".kts")
g = open(gradle, encoding="utf-8").read()

# ---- namespace
m = re.search(r'namespace\s*=?\s*["\']([^"\']+)["\']', g)
pkg = m.group(1) if m else None
if not pkg:
    mf = open(os.path.join(app, "src/main/AndroidManifest.xml"), encoding="utf-8").read()
    m = re.search(r'package="([^"]+)"', mf)
    pkg = m.group(1) if m else "com.sanad.proplus"
print("package:", pkg)

# ---- Kotlin sources
kdir = os.path.join(app, "src", "main", "kotlin", *pkg.split("."))
os.makedirs(kdir, exist_ok=True)
for base, dirs, files in os.walk(os.path.join(app, "src", "main")):
    for f in files:
        if f in ("MainActivity.kt", "MainActivity.java"):
            os.remove(os.path.join(base, f))
for name in ("MainActivity", "Engine", "DownloadService", "AudioExtractor", "Vault", "StatusSaver", "Gallery", "Bridge", "MediaPicker", "ClipService", "ClipActivity", "BootReceiver"):
    src = open(os.path.join(here, "kotlin", name + ".kt.tmpl"), encoding="utf-8").read().replace("__PKG__", pkg)
    open(os.path.join(kdir, name + ".kt"), "w", encoding="utf-8").write(src)

# ---- AppCompat theme (مطلوب لـ local_auth) + تبعية appcompat
res_dirs = [os.path.join(app, "src", "main", "res", d) for d in ("values", "values-night")]
for d in res_dirs:
    sp = os.path.join(d, "styles.xml")
    if os.path.exists(sp):
        x = open(sp, encoding="utf-8").read()
        x = x.replace("@android:style/Theme.Light.NoTitleBar", "Theme.AppCompat.Light.NoActionBar")
        x = x.replace("@android:style/Theme.Black.NoTitleBar", "Theme.AppCompat.NoActionBar")
        x = x.replace("@android:style/Theme.DeviceDefault.Light.NoActionBar", "Theme.AppCompat.Light.NoActionBar")
        x = x.replace("@android:style/Theme.DeviceDefault.NoActionBar", "Theme.AppCompat.NoActionBar")
        open(sp, "w", encoding="utf-8").write(x)

# ---- Gradle
if kts:
    g = re.sub(r"minSdk\s*=\s*[^\n]+", "minSdk = 24", g)
else:
    g = re.sub(r"minSdk(Version)?\s*=?\s*[^\n]+", "minSdkVersion 24", g)

if "abiFilters" not in g:
    ndk = ('ndk { abiFilters += listOf("arm64-v8a") }' if kts
           else 'ndk { abiFilters "arm64-v8a" }')
    g, n = re.subn(r"(defaultConfig\s*\{)", r"\1\n        " + ndk, g, count=1)
    if n == 0:
        sys.exit("defaultConfig not found")

# ---- تقوية البناء: بدون R8/lint (أكثر سبب لفشل assembleRelease مع youtubedl-android)
if "sanad_hardening" not in g:
    if kts:
        hard = ('    // sanad_hardening\n'
                '    lint { checkReleaseBuilds = false; abortOnError = false }\n')
        g, n = re.subn(r"(^android\s*\{)", r"\1\n" + hard, g, count=1, flags=re.M)
        if n == 0:
            sys.exit("android block not found")
        g = re.sub(r"isMinifyEnabled\s*=\s*(true|false)", "isMinifyEnabled = false", g)
        g = re.sub(r"isShrinkResources\s*=\s*(true|false)", "isShrinkResources = false", g)
        if "isMinifyEnabled" not in g:
            g = re.sub(r"(buildTypes\s*\{\s*release\s*\{)", r"\1\n            isMinifyEnabled = false\n            isShrinkResources = false", g, count=1)
    else:
        hard = ('    // sanad_hardening\n'
                '    lintOptions { checkReleaseBuilds false; abortOnError false }\n')
        g, n = re.subn(r"(^android\s*\{)", r"\1\n" + hard, g, count=1, flags=re.M)
        if n == 0:
            sys.exit("android block not found")
        g = re.sub(r"minifyEnabled\s+(true|false)", "minifyEnabled false", g)
        g = re.sub(r"shrinkResources\s+(true|false)", "shrinkResources false", g)
        if "minifyEnabled" not in g:
            g = re.sub(r"(buildTypes\s*\{\s*release\s*\{)", r"\1\n            minifyEnabled false\n            shrinkResources false", g, count=1)

if "useLegacyPackaging" not in g:
    pk = "packaging { jniLibs { useLegacyPackaging = true } }"
    g, n = re.subn(r"(^android\s*\{)", r"\1\n    " + pk, g, count=1, flags=re.M)
    if n == 0:
        sys.exit("android block not found")

if "androidx.appcompat:appcompat" not in g:
    g += ('\ndependencies {\n    implementation("androidx.appcompat:appcompat:1.7.0")\n}\n' if kts
          else "\ndependencies {\n    implementation 'androidx.appcompat:appcompat:1.7.0'\n}\n")

if "youtubedl-android" not in g:
    if kts:
        deps = (f'\ndependencies {{\n    implementation("io.github.junkfood02.youtubedl-android:library:{YTDL}")\n'
                f'    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:{YTDL}")\n}}\n')
    else:
        deps = (f"\ndependencies {{\n    implementation 'io.github.junkfood02.youtubedl-android:library:{YTDL}'\n"
                f"    implementation 'io.github.junkfood02.youtubedl-android:ffmpeg:{YTDL}'\n}}\n")
    g += deps
open(gradle, "w", encoding="utf-8").write(g)

# ---- Manifest
mp = os.path.join(app, "src", "main", "AndroidManifest.xml")
mf = open(mp, encoding="utf-8").read()
perms = ["INTERNET", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_DATA_SYNC", "FOREGROUND_SERVICE_SPECIAL_USE", "POST_NOTIFICATIONS", "WAKE_LOCK",
         "SYSTEM_ALERT_WINDOW", "ACCESS_NETWORK_STATE", "RECEIVE_BOOT_COMPLETED", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"]
add = "".join(f'    <uses-permission android:name="android.permission.{p}"/>\n'
              for p in perms if f"android.permission.{p}" not in mf)
if add:
    mf = mf.replace("<application", add + "    <application", 1)
if "WRITE_EXTERNAL_STORAGE" not in mf:
    mf = mf.replace("<application", '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>\n    <application', 1)
if "ClipService" not in mf:
    extra = ('        <service android:name=".ClipService" android:exported="false" android:foregroundServiceType="specialUse">\n'
             '            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="clipboard_link_watcher"/>\n'
             '        </service>\n'
             '        <activity android:name=".ClipActivity" android:exported="false" android:theme="@android:style/Theme.Translucent.NoTitleBar"'
             ' android:excludeFromRecents="true" android:taskAffinity="" android:noHistory="true"/>\n'
             '        <receiver android:name=".BootReceiver" android:exported="true">\n'
             '            <intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/></intent-filter>\n'
             '        </receiver>\n')
    mf = mf.replace("</application>", extra + "    </application>", 1)
if "DownloadService" not in mf:
    svc = '        <service android:name=".DownloadService" android:exported="false" android:foregroundServiceType="dataSync"/>\n'
    mf = mf.replace("</application>", svc + "    </application>", 1)
if "android.intent.action.SEND" not in mf:
    flt = ('            <intent-filter>\n'
           '                <action android:name="android.intent.action.SEND"/>\n'
           '                <category android:name="android.intent.category.DEFAULT"/>\n'
           '                <data android:mimeType="text/plain"/>\n'
           '            </intent-filter>\n')
    mf = mf.replace("</activity>", flt + "        </activity>", 1)
if "android.intent.category.BROWSABLE" not in mf:
    br = ('            <intent-filter>\n'
          '                <action android:name="android.intent.action.VIEW"/>\n'
          '                <category android:name="android.intent.category.DEFAULT"/>\n'
          '                <category android:name="android.intent.category.BROWSABLE"/>\n'
          '                <data android:scheme="http"/>\n'
          '                <data android:scheme="https"/>\n'
          '            </intent-filter>\n'
          '            <intent-filter>\n'
          '                <action android:name="android.intent.action.MAIN"/>\n'
          '                <category android:name="android.intent.category.APP_BROWSER"/>\n'
          '            </intent-filter>\n')
    mf = mf.replace("</activity>", br + "        </activity>", 1)
# اسم التطبيق
mf = re.sub(r'(<application[^>]*?android:label=")[^"]*(")', r'\1سند\2', mf, count=1)
# أيقونة
mf = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ic_launcher"', mf, count=1)
open(mp, "w", encoding="utf-8").write(mf)
# موارد الأيقونة
import shutil
icons = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons")
if os.path.isdir(icons):
    res = os.path.join(app, "src", "main", "res")
    for d in os.listdir(icons):
        dst = os.path.join(res, d)
        os.makedirs(dst, exist_ok=True)
        for f in os.listdir(os.path.join(icons, d)):
            shutil.copy(os.path.join(icons, d, f), os.path.join(dst, f))
print("native overlay applied")
