import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../core/vault.dart';
import '../engine/gallery.dart';
import '../engine/sys_native.dart';
import 'design.dart';
import 'glass.dart';
import 'lock_screen.dart';
import 'player_page.dart';
import 'vault_flows.dart';

class VaultPage extends ConsumerStatefulWidget {
  const VaultPage({super.key});
  @override
  ConsumerState<VaultPage> createState() => _VaultPageState();
}

class _VaultPageState extends ConsumerState<VaultPage> {
  bool _autoBioTried = false;
  bool _busy = false;

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  void _unlock() => ref.read(vaultUnlockedProvider.notifier).state = true;

  Future<void> _biometricUnlock() async {
    if (await Biometric.authenticate('افتح الخزنة الآمنة')) _unlock();
  }

  Future<void> _createFlow() async {
    if (!await createVaultPin(context, ref)) return;
    if (!mounted) return;
    setState(() {});
    if (await Biometric.available() && mounted) {
      final yes = await confirmSheet(context,
          title: 'القفل بالبصمة أو الوجه',
          message: 'هل تريد فتح الخزنة ببصمة الإصبع أو الوجه بدل كتابة الرمز كل مرة؟ (يبقى الرمز احتياطيًا)',
          action: 'تفعيل');
      if (yes) {
        if (await Biometric.authenticate('تأكيد تفعيل القفل البيومتري')) {
          ref.read(settingsProvider.notifier).change(vaultBiometric: true);
        }
      }
    }
    _unlock();
  }

  Future<void> _forgot() async {
    if (await resetVaultPinByDevice(context, ref)) {
      _snack('تم تعيين رمز جديد للخزنة');
      if (mounted) setState(() {});
      _unlock();
    }
  }

  @override
  Widget build(BuildContext context) {
    final prefs = ref.watch(prefsProvider);
    final unlocked = ref.watch(vaultUnlockedProvider);
    final settings = ref.watch(settingsProvider);
    final hasPin = PinStore.has(prefs, vault: true);
    final tt = Theme.of(context).textTheme;

    if (!hasPin) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Glass(
            accent: kMint,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.shield_rounded, size: 60, color: kMint),
              const SizedBox(height: 12),
              Text('الخزنة الآمنة', style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text(
                'أنشئ رمزًا خاصًا بالخزنة. الصور والفيديوهات والملفات التي تضيفها تُشفَّر (AES-256) وتختفي من الاستوديو والمكتبة، وتعود إلى مكانها عند استعادتها.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 18),
              GradientButton(label: 'إنشاء رمز الخزنة', icon: Icons.password_rounded, onPressed: _createFlow),
            ]),
          ),
        ),
      );
    }
    if (!unlocked) {
      if (settings.vaultBiometric && !_autoBioTried) {
        _autoBioTried = true;
        WidgetsBinding.instance.addPostFrameCallback((_) => _biometricUnlock());
      }
      return LockPad(
        title: 'الخزنة الآمنة',
        subtitle: settings.vaultBiometric ? 'استخدم البصمة/الوجه أو أدخل الرمز' : 'أدخل رمز الخزنة',
        onBiometric: settings.vaultBiometric ? _biometricUnlock : null,
        onForgot: _forgot,
        onSubmit: (pin) async {
          if (await PinStore.verify(prefs, pin, vault: true)) {
            _unlock();
            return null;
          }
          return 'رمز غير صحيح';
        },
      );
    }
    _autoBioTried = false;
    return _content(settings);
  }

  Widget _content(AppSettings settings) {
    final items = ref.watch(vaultProvider);
    int count(int k) => items.where((i) => i.kind == k).length;
    final tt = Theme.of(context).textTheme;
    final n = ref.read(settingsProvider.notifier);

    Widget folder(int kind, String title, String desc, String unit, IconData ic, Color color) => Expanded(
          child: InkWell(
            borderRadius: BorderRadius.circular(24),
            onTap: () => _openFolder(kind, title),
            child: Glass(
              accent: color,
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                height: 150,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(ic, color: color, size: 34),
                  const Spacer(),
                  Text(title, style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                  Text(desc, style: tt.bodySmall, maxLines: 2),
                  const SizedBox(height: 8),
                  Text('${count(kind)} $unit • مشفرة', style: tt.bodyMedium),
                ]),
              ),
            ),
          ),
        );

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 120),
      children: [
        PageTitle('الخزنة الآمنة', sub: 'الملفات هنا مشفرة ومحمية بالكامل', icon: Icons.lock_rounded),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: ActionChip(
            avatar: const Icon(Icons.lock_outline_rounded, size: 18),
            label: const Text('قفل الآن'),
            onPressed: () => ref.read(vaultUnlockedProvider.notifier).state = false,
          ),
        ),
        const SizedBox(height: 12),
        GradientButton(label: 'إضافة ملفات للخزنة', icon: Icons.add_rounded, busy: _busy, onPressed: _addFlow),
        const SectionTitle('المجلدات الآمنة'),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          folder(0, 'مجلد الصور', 'الصور الخاصة', 'صورة', Icons.image_rounded, kBlue),
          const SizedBox(width: 12),
          folder(1, 'مجلد الفيديو', 'مقاطع الفيديو الخاصة', 'فيديو', Icons.videocam_rounded, kPurple),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          folder(2, 'ملفات أخرى', 'مستندات وصوتيات وغيرها', 'ملف', Icons.description_rounded, const Color(0xFFFF8A3D)),
          const SizedBox(width: 12),
          const Expanded(child: SizedBox()),
        ]),
        const SectionTitle('أمان الخزنة'),
        Glass(
          accent: const Color(0xFF34D399),
          child: Column(children: [
            FutureBuilder<bool>(
              future: Biometric.available(),
              builder: (_, snap) => SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.fingerprint_rounded, color: kMint, size: 30),
                title: const Text('القفل بالبصمة أو الوجه'),
                subtitle: Text(snap.data == false ? 'غير متاح على هذا الجهاز' : 'فتح الخزنة بالبيومترية (يبقى الرمز احتياطيًا)'),
                value: settings.vaultBiometric,
                onChanged: snap.data == true
                    ? (v) async {
                        if (!v || await Biometric.authenticate('تأكيد تفعيل القفل البيومتري')) n.change(vaultBiometric: v);
                      }
                    : null,
              ),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.password_rounded, color: kMint),
              title: const Text('تغيير رمز الخزنة'),
              subtitle: const Text('يتطلب الرمز الحالي'),
              onTap: () async {
                if (await changeVaultPin(context, ref)) _snack('تم تغيير رمز الخزنة');
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.phonelink_lock_rounded, color: kMint),
              title: const Text('إعادة تعيين الرمز (نسيته)'),
              subtitle: const Text('تحقق بقفل الهاتف ثم عيّن رمزًا جديدًا — ملفاتك لا تتأثر'),
              onTap: () async {
                if (await resetVaultPinByDevice(context, ref)) _snack('تم تعيين رمز جديد');
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.enhanced_encryption_rounded, color: kMint),
              title: const Text('تشفير التنزيلات تلقائيًا'),
              subtitle: const Text('تُنقل التنزيلات الجديدة مباشرة إلى الخزنة'),
              value: settings.autoVault,
              onChanged: (v) => n.change(autoVault: v),
            ),
          ]),
        ),
      ],
    );
  }

  // ───────────────────────── إضافة ملفات ─────────────────────────
  void _addFlow() {
    showGlassSheet<void>(context, (ctx) {
      Widget tile(IconData ic, String t, String sub, VoidCallback f) => ListTile(
            leading: Icon(ic, color: kMint, size: 30),
            title: Text(t),
            subtitle: Text(sub),
            onTap: () {
              Navigator.pop(ctx);
              f();
            },
          );
      return ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 8), child: Text('إضافة إلى الخزنة', style: Theme.of(ctx).textTheme.titleMedium)),
        tile(Icons.photo_library_rounded, 'من الاستوديو أو الهاتف', 'صور وفيديو وأي ملف — تختفي من مكانها وتعود عند الاستعادة', _fromDevice),
        tile(Icons.video_library_rounded, 'من مكتبة التطبيق', 'ملفاتك المحمّلة عبر نقي', _fromLibrary),
      ]);
    });
  }

  Future<void> _fromDevice() async {
    List<PickedFile> picked;
    try {
      picked = await Picker.pick();
    } catch (_) {
      _snack('تعذّر فتح منتقي الملفات');
      return;
    }
    if (picked.isEmpty || !mounted) return;
    setState(() => _busy = true);
    final tmpDir = Directory('${(await getTemporaryDirectory()).path}/pick');
    await tmpDir.create(recursive: true);
    final done = <String>[];
    var failed = 0;
    for (var k = 0; k < picked.length; k++) {
      final f = picked[k];
      final dot = f.name.lastIndexOf('.');
      final ext = dot > 0 ? f.name.substring(dot + 1) : '';
      final title = dot > 0 ? f.name.substring(0, dot) : f.name;
      final tmp = '${tmpDir.path}/p${DateTime.now().microsecondsSinceEpoch}_$k${ext.isEmpty ? '' : '.$ext'}';
      try {
        await Picker.copy(f.uri, tmp);
        final v = await ref.read(vaultProvider.notifier).addFile(tmp, title, originKind: 1, mime: f.mime, relPath: f.relPath, extOverride: ext);
        if (v == null) {
          failed++;
        } else {
          done.add(f.uri);
        }
      } catch (_) {
        failed++;
        try {
          File(tmp).deleteSync();
        } catch (_) {}
      }
    }
    // بعد نجاح التشفير نحذف الأصول (قد يطلب النظام تأكيدًا مرة واحدة).
    var removed = 0;
    try {
      removed = await Picker.deleteOriginals(done);
    } catch (_) {}
    if (!mounted) return;
    setState(() => _busy = false);
    final left = done.length - removed;
    _snack([
      'تم تشفير ${done.length} ملف',
      if (removed > 0) 'وحُذف الأصل من الهاتف ($removed)',
      if (left > 0) 'تعذّر حذف $left من أماكنها الأصلية (احذفها يدويًا)',
      if (failed > 0) 'فشل $failed',
    ].join(' • '));
  }

  void _fromLibrary() {
    final lib = ref.read(libraryProvider).where((i) => !i.trashed && File(i.filePath).existsSync()).toList();
    final sel = <String>{};
    showGlassSheet<void>(context, (ctx) {
      if (lib.isEmpty) return const Padding(padding: EdgeInsets.all(28), child: Text('لا توجد ملفات في المكتبة لإضافتها.'));
      return StatefulBuilder(builder: (ctx, setS) {
        return Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 8), child: Text('اختر الملفات (تُشفَّر وتُحذف من المكتبة والاستوديو)', style: Theme.of(ctx).textTheme.titleSmall)),
          Flexible(
            child: ListView(shrinkWrap: true, children: [
              for (final i in lib)
                CheckboxListTile(
                  value: sel.contains(i.id),
                  onChanged: (v) => setS(() => v == true ? sel.add(i.id) : sel.remove(i.id)),
                  secondary: Icon(i.audioOnly ? Icons.music_note_rounded : (i.isImage ? Icons.image_rounded : Icons.movie_rounded)),
                  title: Text(i.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${i.site} • ${fmtBytes(i.sizeBytes)}'),
                ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: GradientButton(
              label: sel.isEmpty ? 'اختر ملفًا' : 'نقل ${sel.length} إلى الخزنة',
              icon: Icons.lock_rounded,
              onPressed: sel.isEmpty
                  ? null
                  : () {
                      Navigator.pop(ctx);
                      _moveLibrary(lib.where((e) => sel.contains(e.id)).toList());
                    },
            ),
          ),
        ]);
      });
    });
  }

  Future<void> _moveLibrary(List<LibraryItem> l) async {
    setState(() => _busy = true);
    var ok = 0;
    for (final i in l) {
      try {
        await deleteFromGallery(i.galleryUri); // تختفي من الاستوديو أيضًا
        final v = await ref.read(vaultProvider.notifier).addFile(i.filePath, i.title, lib: i.toJson());
        if (v != null) {
          ref.read(libraryProvider.notifier).detachMany([i.id]);
          ok++;
        }
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(ok == l.length ? 'نُقل $ok ملف إلى الخزنة' : 'نُقل $ok من ${l.length} (تعذّر الباقي)');
  }

  // ───────────────────────── محتوى المجلد ─────────────────────────
  void _openFolder(int kind, String title) {
    showGlassSheet<void>(context, (ctx) => Consumer(builder: (ctx, ref, _) {
          final items = ref.watch(vaultProvider).where((i) => i.kind == kind).toList();
          if (items.isEmpty) {
            return const Padding(padding: EdgeInsets.all(28), child: Text('المجلد فارغ. أضف ملفات بزر "إضافة ملفات للخزنة".'));
          }
          return ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 12, 8),
              child: Row(children: [
                Expanded(child: Text(title, style: Theme.of(ctx).textTheme.titleMedium)),
                TextButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _restoreAll(items);
                  },
                  icon: const Icon(Icons.restore_rounded),
                  label: const Text('استعادة الكل'),
                ),
              ]),
            ),
            for (final i in items)
              ListTile(
                leading: const Icon(Icons.lock_rounded, color: kMint),
                title: Text(i.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${fmtBytes(i.size)} • ${i.originKind == 1 ? 'من الاستوديو/الهاتف' : 'من المكتبة'}'),
                trailing: PopupMenuButton<String>(
                  onSelected: (a) {
                    Navigator.pop(ctx);
                    if (a == 'view') _view(i);
                    if (a == 'restore') _restoreAll([i]);
                    if (a == 'delete') _delete(i);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'view', child: Text('عرض')),
                    PopupMenuItem(value: 'restore', child: Text('إظهار (إعادة لمكانه)')),
                    PopupMenuItem(value: 'delete', child: Text('حذف نهائي')),
                  ],
                ),
                onTap: () {
                  Navigator.pop(ctx);
                  _view(i);
                },
              ),
          ]);
        }));
  }

  Future<void> _view(VaultItem i) async {
    try {
      final tmp = await ref.read(vaultProvider.notifier).decryptToTemp(i);
      if (!mounted) return;
      final temp = LibraryItem(
        id: i.id,
        title: i.title,
        site: '',
        filePath: tmp,
        audioOnly: i.kind == 2,
        sizeBytes: i.size,
        label: '',
        createdAt: DateTime.fromMillisecondsSinceEpoch(i.createdAt),
      );
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerPage(item: temp)));
      await VaultNative.wipe(tmp); // لا نترك نسخة مفكوكة على الجهاز
    } catch (_) {
      _snack('تعذّر فتح الملف');
    }
  }

  /// يعيد العنصر إلى مكانه: ملفات المكتبة إلى المكتبة (والاستوديو إن كانت فيه)، والخارجية إلى مجلدها الأصلي.
  Future<bool> _restoreOne(VaultItem i) async {
    final vault = ref.read(vaultProvider.notifier);
    final lib = ref.read(libraryProvider.notifier);
    try {
      if (i.originKind == 0 && i.lib != null) {
        final path = i.origPath ?? await vault.fallbackPath(i);
        await vault.decryptTo(i, path);
        var item = LibraryItem.fromJson(i.lib!).copyWith(filePath: path, clearGallery: true);
        final hadGallery = (i.lib!['galleryUri'] as String?)?.isNotEmpty == true;
        if (hadGallery || ref.read(settingsProvider).autoGallery) {
          final uri = await saveToGallery(path);
          if (uri != null) item = item.copyWith(galleryUri: uri);
        }
        if (!ref.read(libraryProvider).any((x) => x.id == item.id)) lib.add(item);
      } else {
        final tmpDir = await getTemporaryDirectory();
        final ext = i.ext.isEmpty ? '' : '.${i.ext}';
        final tmp = '${tmpDir.path}/r_${i.id}$ext';
        await vault.decryptTo(i, tmp);
        final uri = await restoreToGallery(tmp, '${i.title}$ext', mime: i.mime, relPath: i.relPath);
        if (uri != null) {
          await VaultNative.wipe(tmp);
        } else {
          // لا يمكن الكتابة في الاستوديو: نضعه في مجلد التطبيق ونضيفه للمكتبة.
          final path = await vault.fallbackPath(i);
          await File(tmp).copy(path);
          await VaultNative.wipe(tmp);
          lib.add(LibraryItem(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            title: i.title,
            site: 'Other',
            filePath: path,
            audioOnly: i.kind == 2,
            sizeBytes: i.size,
            label: 'مستعاد',
            createdAt: DateTime.now(),
          ));
        }
      }
      await vault.remove(i);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _restoreAll(List<VaultItem> l) async {
    setState(() => _busy = true);
    var ok = 0;
    for (final i in List.of(l)) {
      if (await _restoreOne(i)) ok++;
    }
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(ok == l.length ? 'أُعيد $ok ملف إلى مكانه' : 'أُعيد $ok من ${l.length} (تعذّر الباقي)');
  }

  Future<void> _delete(VaultItem i) async {
    final ok = await confirmSheet(context,
        title: 'حذف نهائي', message: 'سيُحذف الملف المشفّر نهائيًا ولا يمكن استرجاعه.', action: 'حذف');
    if (!ok) return;
    final th = i.lib?['thumbPath'] as String?;
    if (th != null) {
      try {
        File(th).deleteSync();
      } catch (_) {}
    }
    await ref.read(vaultProvider.notifier).remove(i);
    _snack('تم الحذف');
  }
}
