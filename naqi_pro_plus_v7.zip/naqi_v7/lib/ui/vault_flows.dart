import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../core/vault.dart';
import 'glass.dart';
import 'lock_screen.dart';

Future<bool> _route(BuildContext context, Widget Function(BuildContext ctx) body) async {
  final r = await Navigator.of(context).push<bool>(MaterialPageRoute(
    fullscreenDialog: true,
    builder: (ctx) => Scaffold(
      appBar: AppBar(backgroundColor: Colors.transparent),
      extendBodyBehindAppBar: true,
      body: AppBackground(child: SafeArea(child: body(ctx))),
    ),
  ));
  return r ?? false;
}

/// إنشاء رمز خاص بالخزنة (إدخالان متطابقان).
Future<bool> createVaultPin(BuildContext context, WidgetRef ref) {
  final prefs = ref.read(prefsProvider);
  return _route(context, (ctx) => PinSetup(onCreate: (pin) async {
        await PinStore.set(prefs, pin, vault: true);
        if (ctx.mounted) Navigator.pop(ctx, true);
      }));
}

/// التحقق من رمز الخزنة الحالي.
Future<bool> verifyVaultPin(BuildContext context, WidgetRef ref, {String title = 'أدخل رمز الخزنة الحالي'}) {
  final prefs = ref.read(prefsProvider);
  return _route(context, (ctx) => LockPad(
        title: title,
        onSubmit: (pin) async {
          if (await PinStore.verify(prefs, pin, vault: true)) {
            if (ctx.mounted) Navigator.pop(ctx, true);
            return null;
          }
          return 'الرمز غير صحيح';
        },
      ));
}

/// تغيير الرمز: يتطلب الرمز القديم أولًا ثم رمزًا جديدًا مؤكدًا.
Future<bool> changeVaultPin(BuildContext context, WidgetRef ref) async {
  if (!await verifyVaultPin(context, ref)) return false;
  if (!context.mounted) return false;
  return createVaultPin(context, ref);
}

/// نسيان الرمز: التحقق بقفل الجهاز (بصمة/وجه/نمط/PIN الهاتف) ثم تعيين رمز جديد.
/// الملفات لا تضيع لأن مفتاح التشفير داخل الجهاز وليس مشتقًا من الرمز.
Future<bool> resetVaultPinByDevice(BuildContext context, WidgetRef ref) async {
  final ok = await Biometric.authenticate('تحقق من هويتك لتعيين رمز جديد للخزنة');
  if (!ok) {
    if (context.mounted) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('تعذّر التحقق. يجب أن يكون للهاتف قفل شاشة (بصمة/نمط/رمز).')));
    }
    return false;
  }
  if (!context.mounted) return false;
  return createVaultPin(context, ref);
}
