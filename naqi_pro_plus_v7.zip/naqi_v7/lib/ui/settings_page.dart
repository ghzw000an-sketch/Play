import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../core/vault.dart';
import '../engine/native_engine.dart';
import 'design.dart';
import '../engine/sys_native.dart';
import 'glass.dart';
import 'lock_screen.dart';

const _kVersion = '0.7.0';

class SettingsPage extends ConsumerStatefulWidget {
  const SettingsPage({super.key});
  @override
  ConsumerState<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends ConsumerState<SettingsPage> {
  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  static const _tabs = ['العامة', 'التنزيل', 'الأمان', 'عن التطبيق'];

  @override
  Widget build(BuildContext context) {
    final tab = ref.watch(settingsTabProvider);
    return Column(children: [
      const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 0), child: Align(alignment: AlignmentDirectional.centerStart, child: PageTitle('الإعدادات', icon: Icons.settings_rounded))),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          for (var i = 0; i < _tabs.length; i++)
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: ChoiceChip(
                label: Text(_tabs[i]),
                selected: tab == i,
                onSelected: (_) => ref.read(settingsTabProvider.notifier).state = i,
              ),
            ),
        ]),
      ),
      Expanded(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
          children: switch (tab) {
            0 => _general(),
            1 => _download(),
            2 => _security(),
            _ => _about(),
          },
        ),
      ),
    ]);
  }

  Widget _section(String title, List<Widget> children) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Glass(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
              child: Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            ),
            ...children,
          ]),
        ),
      );

  Widget _sw(String t, String? sub, bool v, ValueChanged<bool> f) => SwitchListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 4),
        title: Text(t),
        subtitle: sub == null ? null : Text(sub),
        value: v,
        onChanged: f,
      );

  // ───────── العامة ─────────
  List<Widget> _general() {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    final lib = ref.watch(libraryProvider);
    final total = lib.fold<int>(0, (a, i) => a + i.sizeBytes);
    final cs = Theme.of(context).colorScheme;
    return [
      ..._appearance(),
      _section('السلوك', [
        _sw('تحليل الروابط المنسوخة تلقائيًا', 'عند فتح التطبيق وفي الحافظة رابط مدعوم', s.autoAnalyze, (v) => n.change(autoAnalyze: v)),
        _sw('التشغيل التلقائي بعد الانتهاء', 'يفتح المشغّل فور اكتمال التنزيل', s.autoPlay, (v) => n.change(autoPlay: v)),
        _sw('إشعار التنزيل في الخلفية', 'يُبقي التنزيل يعمل عند مغادرة التطبيق', s.notify, (v) => n.change(notify: v)),
        _sw('الاهتزاز عند اللمس', null, s.haptics, (v) => n.change(haptics: v)),
      ]),
      _section('التخزين', [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: const Icon(Icons.storage_rounded),
          title: Text('${lib.length} ملف • ${fmtBytes(total)}'),
          subtitle: const Text('داخل مجلد التطبيق (Naqi)'),
        ),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: const Icon(Icons.cleaning_services_outlined),
          title: const Text('مسح الملفات المؤقتة'),
          onTap: _clearCache,
        ),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: Icon(Icons.delete_sweep_outlined, color: cs.error),
          title: Text('حذف كل الملفات المحمّلة', style: TextStyle(color: cs.error)),
          enabled: lib.isNotEmpty,
          onTap: () async {
            final yes = await confirmSheet(context,
                title: 'حذف الكل', message: 'سيتم حذف جميع الملفات المحمّلة من الجهاز نهائيًا.', action: 'حذف الكل');
            if (yes) await ref.read(libraryProvider.notifier).clearAll();
          },
        ),
      ]),
    ];
  }

  Widget _slider(String title, String value, double v, double min, double max, ValueChanged<double> f, {int? divisions}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(title)),
            Text(value, style: Theme.of(context).textTheme.labelLarge),
          ]),
          Slider(value: v.clamp(min, max), min: min, max: max, divisions: divisions, onChanged: f),
        ]),
      );

  List<Widget> _appearance() {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    final cs = Theme.of(context).colorScheme;
    final hue = HSVColor.fromColor(Color(s.seed)).hue;
    Widget swatch(Color c, bool sel, VoidCallback f) => GestureDetector(
          onTap: f,
          child: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: c,
              shape: BoxShape.circle,
              border: Border.all(color: sel ? cs.onSurface : Colors.white24, width: sel ? 3 : 1),
            ),
            child: sel ? Icon(Icons.check, color: c.computeLuminance() > 0.6 ? Colors.black : Colors.white) : null,
          ),
        );
    return [
      _section('معاينة', [
        Glass(
          accent: cs.primary,
          child: Row(children: [
            Icon(Icons.auto_awesome_rounded, color: cs.primary, size: 30),
            const SizedBox(width: 12),
            const Expanded(child: Text('هكذا ستبدو البطاقات والنصوص بعد التعديل')),
          ]),
        ),
      ]),
      _section('المظهر', [
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.system, label: Text('تلقائي')),
              ButtonSegment(value: ThemeMode.light, label: Text('فاتح')),
              ButtonSegment(value: ThemeMode.dark, label: Text('داكن')),
            ],
            selected: {s.themeMode},
            onSelectionChanged: (v) => n.change(themeMode: v.first),
          ),
        ),
        _sw('وضع AMOLED الأسود', 'خلفية سوداء خالصة في الوضع الداكن', s.amoled, (v) => n.change(amoled: v)),
      ]),
      _section('اللون الرئيسي', [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Wrap(spacing: 12, runSpacing: 12, children: [
            for (final c in accentSeeds) swatch(Color(c), s.seed == c, () => n.change(seed: c)),
          ]),
        ),
        _slider('درجة اللون (مخصص)', '${hue.round()}°', hue, 0, 360,
            (v) => n.change(seed: HSVColor.fromAHSV(1, v, 0.78, 0.95).toColor().value)),
      ]),
      _section('الزجاجية والحجم', [
        _slider('الضبابية', s.glassBlur.round().toString(), s.glassBlur, 0, 30, (v) => n.change(glassBlur: v), divisions: 30),
        _slider('شفافية الزجاج', '${(s.glassOpacity * 100).round()}%', s.glassOpacity, 0.02, 0.45, (v) => n.change(glassOpacity: v)),
        _slider('استدارة الحواف', s.radius.round().toString(), s.radius, 6, 40, (v) => n.change(radius: v), divisions: 34),
      ]),
      _section('النص', [
        _slider('حجم النص', '${(s.textScale * 100).round()}%', s.textScale, 0.8, 1.5, (v) => n.change(textScale: v), divisions: 14),
        const SizedBox(height: 4),
        const Text('لون النص'),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Wrap(spacing: 12, runSpacing: 12, children: [
            GestureDetector(
              onTap: () => n.change(textColor: 0),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: s.textColor == 0 ? cs.onSurface : Colors.white24, width: s.textColor == 0 ? 3 : 1)),
                child: const Center(child: Text('تلقائي', style: TextStyle(fontSize: 9))),
              ),
            ),
            for (final c in textColors) swatch(Color(c), s.textColor == c, () => n.change(textColor: c)),
          ]),
        ),
      ]),
      Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: OutlinedButton.icon(onPressed: n.resetAppearance, icon: const Icon(Icons.restart_alt_rounded), label: const Text('إعادة المظهر للافتراضي')),
      ),
    ];
  }

  // ───────── التحميل التلقائي من الحافظة ─────────
  Future<void> _toggleClip(bool v) async {
    final n = ref.read(settingsProvider.notifier);
    if (!v) {
      await Sys.stopClip();
      n.change(clipWatch: false);
      return;
    }
    if (!await Sys.canOverlay()) {
      if (!mounted) return;
      final go = await confirmSheet(context,
          title: 'إذن العرض فوق التطبيقات',
          message: 'لقراءة الرابط الذي تنسخه وأنت خارج التطبيق يحتاج نقي إلى إذن "العرض فوق التطبيقات" (يمنع أندرويد قراءة الحافظة من الخلفية). '
              'فعّل الإذن لنقي ثم ارجع واضغط المفتاح من جديد.',
          action: 'فتح الإعدادات');
      if (go) await Sys.requestOverlay();
      return;
    }
    await Sys.startClip();
    n.change(clipWatch: true);
    if (!await Sys.ignoringBattery() && mounted) {
      _snack('لضمان العمل في الخلفية: استثنِ نقي من توفير البطارية.');
      await Sys.requestIgnoreBattery();
    }
  }

  Future<void> _clearCache() async {
    try {
      final d = await getTemporaryDirectory();
      if (await d.exists()) {
        for (final e in d.listSync()) {
          try {
            e.deleteSync(recursive: true);
          } catch (_) {}
        }
      }
      _snack('تم مسح الملفات المؤقتة');
    } catch (_) {
      _snack('تعذّر المسح');
    }
  }

  // ───────── التنزيل ─────────
  List<Widget> _download() {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    final tt = Theme.of(context).textTheme;
    return [
      _section('السرعة', [
        Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text('عدد التنزيلات المتزامنة', style: tt.bodyLarge)),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<int>(
            segments: [for (final v in [1, 2, 3, 4, 5]) ButtonSegment(value: v, label: Text('$v'))],
            selected: {s.maxParallel},
            onSelectionChanged: (v) => n.change(maxParallel: v.first),
          ),
        ),
        const SizedBox(height: 12),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text('اتصالات لكل ملف', style: tt.bodyLarge)),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Text('الأعلى = أسرع غالبًا. يُطبَّق على التنزيلات الجديدة.', style: tt.bodySmall)),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<int>(
            segments: [for (final v in [4, 8, 16, 32]) ButtonSegment(value: v, label: Text('$v'))],
            selected: {s.connections},
            onSelectionChanged: (v) => n.change(connections: v.first),
          ),
        ),
      ]),
      _section('الخيارات', [
        _sw('تنزيل تلقائي بأعلى جودة', 'يبدأ التنزيل فور تحليل الرابط دون اختيار', s.bestQuality, (v) => n.change(bestQuality: v)),
        _sw('تفضيل الصوت في التنزيل التلقائي', 'ينزّل MP3 بدل الفيديو عند تفعيل "أعلى جودة"', s.preferAudio, (v) => n.change(preferAudio: v)),
        _sw('حفظ تلقائي في الاستوديو', 'كل تنزيل (فيديو/صورة/صوت) يُحفظ أيضًا في ألبوم Naqi', s.autoGallery, (v) => n.change(autoGallery: v)),
      ]),
      _section('التحميل التلقائي', [
        _sw('تحميل الروابط المنسوخة تلقائيًا', 'انسخ رابط فيديو من أي تطبيق فيبدأ تحميله دون فتح نقي', s.clipWatch, _toggleClip),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
              'يعمل بخدمة خلفية بإشعار دائم، ويحتاج إذن العرض فوق التطبيقات. يدعم يوتيوب وتيك توك وإنستغرام وفيسبوك وسناب وبنتريست وX. '
              'قد تمنعه بعض الأجهزة (شاومي/هواوي…) ما لم تسمح له بالتشغيل التلقائي وتستثنيه من توفير البطارية.',
              style: Theme.of(context).textTheme.bodySmall),
        ),
      ]),
      _section('محرك التنزيل (yt-dlp)', [
        const _EngineTile(),
        _sw('تحديث المحرك تلقائيًا', 'مرة كل يوم عند فتح التطبيق، لأن المنصات تتغيّر باستمرار', s.autoUpdateEngine, (v) => n.change(autoUpdateEngine: v)),
      ]),
    ];
  }

  // ───────── الأمان ─────────
  Future<bool> _ensurePin() async {
    final prefs = ref.read(prefsProvider);
    if (PinStore.has(prefs)) return true;
    var ok = false;
    await Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (ctx) => Scaffold(
        appBar: AppBar(backgroundColor: Colors.transparent),
        extendBodyBehindAppBar: true,
        body: AppBackground(
          child: SafeArea(
            child: PinSetup(onCreate: (pin) async {
              await PinStore.set(prefs, pin);
              ok = true;
              if (ctx.mounted) Navigator.pop(ctx);
            }),
          ),
        ),
      ),
    ));
    return ok;
  }

  List<Widget> _security() {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    final prefs = ref.read(prefsProvider);
    final hasPin = PinStore.has(prefs);
    return [
      _section('قفل التطبيق', [
        _sw('قفل التطبيق برمز', 'يُطلب الرمز عند فتح التطبيق أو العودة إليه', s.appLock, (v) async {
          if (v && !await _ensurePin()) return;
          n.change(appLock: v);
          if (mounted) setState(() {});
        }),
        FutureBuilder<bool>(
          future: Biometric.available(),
          builder: (_, snap) => _sw('البصمة / الوجه', snap.data == false ? 'غير متاحة على هذا الجهاز' : 'فتح سريع بدل الرمز', s.biometric,
              (snap.data == true && hasPin) ? (v) => n.change(biometric: v) : (_) => _snack(hasPin ? 'غير متاحة على هذا الجهاز' : 'أنشئ رمزًا أولًا')),
        ),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: const Icon(Icons.password_rounded),
          title: Text(hasPin ? 'تغيير الرمز' : 'إنشاء رمز'),
          onTap: () async {
            final yes = !hasPin || await _verifyOld();
            if (!yes) return;
            await prefs.remove('pinHash');
            await _ensurePin();
            if (mounted) setState(() {});
          },
        ),
      ]),
      _section('الخزنة المشفّرة', [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: const Icon(Icons.shield_rounded, color: kMint),
          title: const Text('فتح الخزنة'),
          subtitle: const Text('الرمز والبصمة وإضافة الملفات من تبويب الخزنة'),
          trailing: const Icon(Icons.chevron_left_rounded),
          onTap: () => ref.read(tabProvider.notifier).state = 3,
        ),
        _sw('القفل بالبصمة أو الوجه للخزنة', null, s.vaultBiometric, (v) async {
          if (!PinStore.has(prefs, vault: true)) {
            _snack('أنشئ رمز الخزنة أولًا من تبويب الخزنة');
            return;
          }
          if (!v || await Biometric.authenticate('تأكيد تفعيل القفل البيومتري')) n.change(vaultBiometric: v);
        }),
        _sw('تشفير التنزيلات تلقائيًا', 'تُنقل التنزيلات الجديدة مباشرة إلى الخزنة (AES-256)', s.autoVault, (v) {
          if (v && !PinStore.has(prefs, vault: true)) {
            _snack('أنشئ رمز الخزنة أولًا من تبويب الخزنة');
            return;
          }
          n.change(autoVault: v);
        }),
      ]),
      _section('النسخ الاحتياطي', [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: const Icon(Icons.backup_outlined),
          title: const Text('نسخ احتياطي للمكتبة والإعدادات'),
          subtitle: const Text('ملف JSON تحفظه أو تشاركه (الفيديوهات نفسها لا تُنسخ)'),
          onTap: _backup,
        ),
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: const Icon(Icons.restore_rounded),
          title: const Text('استعادة آخر نسخة احتياطية'),
          onTap: _restore,
        ),
      ]),
    ];
  }

  Future<bool> _verifyOld() async {
    final prefs = ref.read(prefsProvider);
    var ok = false;
    await Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (ctx) => Scaffold(
        appBar: AppBar(backgroundColor: Colors.transparent),
        extendBodyBehindAppBar: true,
        body: AppBackground(
          child: SafeArea(
            child: LockPad(
              title: 'أدخل الرمز الحالي',
              onSubmit: (pin) async {
                if (await PinStore.verify(prefs, pin)) {
                  ok = true;
                  if (ctx.mounted) Navigator.pop(ctx);
                  return null;
                }
                return 'الرمز غير صحيح';
              },
            ),
          ),
        ),
      ),
    ));
    return ok;
  }

  static const _secret = {'pinHash', 'pinSalt', 'vault_v1'};

  Future<File> _backupFile() async {
    final d = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    return File('${d.path}/naqi_backup.json');
  }

  Future<void> _backup() async {
    try {
      final prefs = ref.read(prefsProvider);
      final data = <String, dynamic>{};
      for (final k in prefs.getKeys()) {
        if (_secret.contains(k)) continue;
        data[k] = prefs.get(k);
      }
      final f = await _backupFile();
      await f.writeAsString(jsonEncode({'app': 'naqi', 'version': _kVersion, 'prefs': data}));
      _snack('تم الحفظ: ${f.path}');
      await Share.shareXFiles([XFile(f.path)], text: 'نسخة احتياطية - نقي Pro Plus');
    } catch (_) {
      _snack('تعذّر إنشاء النسخة الاحتياطية');
    }
  }

  Future<void> _restore() async {
    try {
      final f = await _backupFile();
      if (!await f.exists()) {
        _snack('لا توجد نسخة احتياطية محفوظة على هذا الجهاز');
        return;
      }
      final j = jsonDecode(await f.readAsString()) as Map;
      final data = Map<String, dynamic>.from(j['prefs'] as Map);
      final prefs = ref.read(prefsProvider);
      for (final e in data.entries) {
        if (_secret.contains(e.key)) continue;
        final v = e.value;
        if (v is bool) {
          await prefs.setBool(e.key, v);
        } else if (v is int) {
          await prefs.setInt(e.key, v);
        } else if (v is double) {
          await prefs.setDouble(e.key, v);
        } else if (v is String) {
          await prefs.setString(e.key, v);
        } else if (v is List) {
          await prefs.setStringList(e.key, v.map((x) => '$x').toList());
        }
      }
      ref.invalidate(settingsProvider);
      ref.invalidate(libraryProvider);
      _snack('تمت الاستعادة');
    } catch (_) {
      _snack('الملف غير صالح');
    }
  }

  // ───────── عن التطبيق ─────────
  List<Widget> _about() {
    final tt = Theme.of(context).textTheme;
    return [
      _section('نقي Pro Plus', [
        const ListTile(
          contentPadding: EdgeInsets.symmetric(horizontal: 4),
          leading: Icon(Icons.info_outline),
          title: Text('الإصدار $_kVersion'),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'المنصات: يوتيوب، تيك توك، إنستغرام، فيسبوك، سناب شات، بنتريست، إكس ومئات المواقع عبر yt-dlp (الروابط العامة فقط). '
            'إذا توقفت منصة عن العمل فحدّث المحرك من تبويب "التنزيل".',
            style: tt.bodyMedium,
          ),
        ),
      ]),
      _section('الشروط والخصوصية', [
        Text(
          '• يحمّل التطبيق المحتوى المتاح للعامة والمسموح بتنزيله فقط.\n'
          '• لا يتجاوز حماية DRM أو المحتوى الخاص ولا يزيل العلامات المائية من ملفات الغير؛ يطلب النسخة الأصلية النظيفة التي توفّرها المنصة.\n'
          '• أنت المسؤول عن احترام حقوق النشر وشروط المنصات وخصوصية الآخرين.\n'
          '• لا يجمع التطبيق أي بيانات عنك؛ المكتبة والإعدادات والخزنة تبقى على جهازك.',
          style: tt.bodyMedium,
        ),
      ]),
    ];
  }
}

class _EngineTile extends StatefulWidget {
  const _EngineTile();
  @override
  State<_EngineTile> createState() => _EngineTileState();
}

class _EngineTileState extends State<_EngineTile> {
  String _status = 'جارٍ الفحص…';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    if (!await NativeEngine.available) {
      if (mounted) setState(() => _status = 'غير متوفر في هذه النسخة (يعمل الوضع الاحتياطي)');
      return;
    }
    final (ready, err) = await NativeEngine.status();
    final v = ready ? await NativeEngine.version() : null;
    if (!mounted) return;
    setState(() => _status = err != null
        ? 'خطأ في التهيئة: $err'
        : ready
            ? 'جاهز${v != null ? ' • yt-dlp $v' : ''}'
            : 'قيد التهيئة… (أول تشغيل قد يستغرق دقيقة)');
  }

  Future<void> _update() async {
    setState(() {
      _busy = true;
      _status = 'جارٍ التحديث…';
    });
    try {
      await NativeEngine.update();
    } catch (e) {
      if (mounted) setState(() => _status = 'تعذّر التحديث: $e');
      if (mounted) setState(() => _busy = false);
      return;
    }
    if (mounted) setState(() => _busy = false);
    await _refresh();
  }

  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 4),
        leading: const Icon(Icons.memory_rounded),
        title: Text(_status),
        subtitle: const Text('يدعم تيك توك وإنستغرام وفيسبوك بالنسخة الأصلية بلا علامة مائية'),
        trailing: _busy
            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
            : IconButton(tooltip: 'تحديث المحرك', icon: const Icon(Icons.system_update_alt_rounded), onPressed: _update),
      );
}
