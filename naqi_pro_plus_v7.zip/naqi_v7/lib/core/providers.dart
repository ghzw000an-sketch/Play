import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../engine/download_manager.dart';
import '../engine/extractor.dart';
import '../engine/gallery.dart';
import 'library.dart';
import 'vault.dart';
import 'models.dart';
import 'settings.dart';

final extractorProvider = Provider((_) => ExtractorRegistry());

/// التبويب الحالي في الشريط السفلي (0 تنزيل، 1 الجارية، 2 المكتبة، 3 الإعدادات)
final tabProvider = StateProvider<int>((_) => 0);

final libraryProvider = StateNotifierProvider<LibraryNotifier, List<LibraryItem>>(
    (ref) => LibraryNotifier(ref.watch(prefsProvider)));

final foldersProvider = StateNotifierProvider<FolderNotifier, List<LibFolder>>((ref) => FolderNotifier(ref.watch(prefsProvider)));

/// تبويب الإعدادات الداخلي (0 عامة، 1 تنزيل، 2 أمان، 3 عن التطبيق)
final settingsTabProvider = StateProvider<int>((_) => 0);

/// آخر ملف اكتمل تنزيله (للتشغيل التلقائي)
final justFinishedProvider = StateProvider<LibraryItem?>((_) => null);

/// رابط وارد من قائمة المشاركة (يلتقطه تبويب التنزيل ويحلله).
final incomingLinkProvider = StateProvider<String?>((_) => null);

final downloadManagerProvider = StateNotifierProvider<DownloadManager, List<DownloadTask>>((ref) {
  return DownloadManager(
    maxParallel: () => ref.read(settingsProvider).maxParallel,
    connections: () => ref.read(settingsProvider).connections,
    notify: () => ref.read(settingsProvider).notify,
    onDone: (task, thumb) async {
      final path = task.filePath;
      if (path == null) return;
      final size = await File(path).length();
      var item = LibraryItem(
        id: task.id,
        title: task.info.title,
        site: siteName(task.info.site),
        filePath: path,
        audioOnly: task.option.audioOnly,
        sizeBytes: size,
        label: task.option.label,
        thumbPath: thumb,
        sourceUrl: task.info.sourceUrl,
        author: task.info.author,
        createdAt: DateTime.now(),
        durationSec: task.info.duration?.inSeconds,
      );
      final st = ref.read(settingsProvider);
      // تشفير التنزيلات: يُنقل الملف مباشرة إلى الخزنة بدل المكتبة العامة.
      if (st.autoVault && PinStore.has(ref.read(prefsProvider), vault: true)) {
        final v = await ref.read(vaultProvider.notifier).addFile(
              path,
              item.title,
              lib: item.toJson(),
            );
        if (v != null) {
          if (thumb != null) {
            try {
              File(thumb).deleteSync();
            } catch (_) {}
          }
          return;
        }
      }
      // حفظ تلقائي في الاستوديو (فيديو/صورة/صوت).
      if (st.autoGallery) {
        final uri = await saveToGallery(path);
        if (uri != null) item = item.copyWith(galleryUri: uri);
      }
      ref.read(libraryProvider.notifier).add(item);
      if (st.autoPlay) ref.read(justFinishedProvider.notifier).state = item;
    },
  );
});

final analysisProvider =
    StateNotifierProvider<AnalysisNotifier, AsyncValue<MediaInfo?>>((ref) => AnalysisNotifier(ref));

class AnalysisNotifier extends StateNotifier<AsyncValue<MediaInfo?>> {
  AnalysisNotifier(this.ref) : super(const AsyncData(null));
  final Ref ref;

  Future<void> analyze(String url) async {
    final u = url.trim();
    if (u.isEmpty) return;
    state = const AsyncLoading();
    try {
      state = AsyncData(await ref.read(extractorProvider).analyze(u));
    } catch (e, s) {
      state = AsyncError(
        e is ExtractorException ? e : ExtractorException('تعذّر التحليل. تحقق من الاتصال بالإنترنت ومن الرابط.'),
        s,
      );
    }
  }

  void clear() => state = const AsyncData(null);
}
