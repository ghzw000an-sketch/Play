import 'dart:convert';
import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class LibraryNotifier extends StateNotifier<List<LibraryItem>> {
  LibraryNotifier(this._p) : super(_load(_p));
  final SharedPreferences _p;
  static const _key = 'library_v1';

  static List<LibraryItem> _load(SharedPreferences p) {
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      final l = jsonDecode(raw) as List;
      return [for (final e in l) LibraryItem.fromJson(Map<String, dynamic>.from(e as Map))];
    } catch (_) {
      return [];
    }
  }

  void _save() => _p.setString(_key, jsonEncode([for (final i in state) i.toJson()]));

  void add(LibraryItem i) {
    state = [i, ...state];
    _save();
  }

  void update(LibraryItem i) {
    state = [for (final x in state) x.id == i.id ? i : x];
    _save();
  }

  Future<void> _deleteFiles(LibraryItem i) async {
    for (final p in [i.filePath, i.thumbPath]) {
      if (p == null) continue;
      try {
        final f = File(p);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  Future<void> removeMany(Iterable<String> ids) async {
    final set = ids.toSet();
    for (final i in state.where((x) => set.contains(x.id))) {
      await _deleteFiles(i);
    }
    state = state.where((x) => !set.contains(x.id)).toList();
    _save();
  }

  /// يزيل العناصر من المكتبة دون حذف ملفاتها (تُنقل إلى الخزنة مثلًا).
  void detachMany(Iterable<String> ids) {
    final set = ids.toSet();
    state = state.where((x) => !set.contains(x.id)).toList();
    _save();
  }

  Future<void> clearAll() async {
    for (final i in state) {
      await _deleteFiles(i);
    }
    state = [];
    _save();
  }

  /// نقل إلى السلة (الملفات تبقى حتى التفريغ).
  void trashMany(Iterable<String> ids) {
    final set = ids.toSet();
    state = [for (final x in state) set.contains(x.id) ? x.copyWith(trashed: true) : x];
    _save();
  }

  void restoreMany(Iterable<String> ids) {
    final set = ids.toSet();
    state = [for (final x in state) set.contains(x.id) ? x.copyWith(trashed: false) : x];
    _save();
  }

  void setFolder(Iterable<String> ids, String? folder) {
    final set = ids.toSet();
    state = [
      for (final x in state) set.contains(x.id) ? (folder == null ? x.copyWith(clearFolder: true) : x.copyWith(folder: folder)) : x
    ];
    _save();
  }

  void setGalleryUri(String id, String? uri) {
    state = [for (final x in state) x.id == id ? (uri == null ? x.copyWith(clearGallery: true) : x.copyWith(galleryUri: uri)) : x];
    _save();
  }

  Future<void> emptyTrash() => removeMany(state.where((x) => x.trashed).map((x) => x.id).toList());
}

/// مجلد مخصص ينشئه المستخدم.
class LibFolder {
  final String id;
  final String name;
  final int color;
  const LibFolder({required this.id, required this.name, required this.color});
  LibFolder copyWith({String? name, int? color}) => LibFolder(id: id, name: name ?? this.name, color: color ?? this.color);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'color': color};
  factory LibFolder.fromJson(Map<String, dynamic> j) =>
      LibFolder(id: j['id'] as String, name: (j['name'] ?? '') as String, color: (j['color'] as num?)?.toInt() ?? 0xFF22D3EE);
}

const folderColors = <int>[0xFF22D3EE, 0xFF3B82F6, 0xFFB620E0, 0xFFFF8A3D, 0xFF34D399, 0xFFFF4D6D, 0xFFFFD60A];

class FolderNotifier extends StateNotifier<List<LibFolder>> {
  FolderNotifier(this._p) : super(_load(_p));
  final SharedPreferences _p;
  static const _key = 'folders_v1';

  static List<LibFolder> _load(SharedPreferences p) {
    final raw = p.getString(_key);
    if (raw == null) return [];
    try {
      return [for (final e in jsonDecode(raw) as List) LibFolder.fromJson(Map<String, dynamic>.from(e as Map))];
    } catch (_) {
      return [];
    }
  }

  void _save() => _p.setString(_key, jsonEncode([for (final f in state) f.toJson()]));

  LibFolder create(String name, int color) {
    final f = LibFolder(id: DateTime.now().microsecondsSinceEpoch.toString(), name: name.trim(), color: color);
    state = [...state, f];
    _save();
    return f;
  }

  void update(String id, {String? name, int? color}) {
    state = [for (final f in state) f.id == id ? f.copyWith(name: name?.trim(), color: color) : f];
    _save();
  }

  void remove(String id) {
    state = state.where((f) => f.id != id).toList();
    _save();
  }
}
