import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../engine/extractor_base.dart';
import 'models.dart';
import 'providers.dart';
import 'settings.dart';

final _seen = <String, DateTime>{};

/// يحلّل الرابط ويبدأ تنزيله بأعلى جودة (أو MP3 حسب الإعداد). يرجع رسالة للمستخدم أو null.
Future<String?> autoDownloadLink(ProviderContainer c, String url) async {
  final now = DateTime.now();
  final last = _seen[url];
  if (last != null && now.difference(last).inSeconds < 30) return null;
  _seen[url] = now;
  if (detectSite(url) == Site.unknown) return null;
  try {
    final info = await c.read(extractorProvider).analyze(url);
    final st = c.read(settingsProvider);
    final audio = info.options.where((o) => o.audioOnly).toList();
    final opt = (st.preferAudio && audio.isNotEmpty) ? audio.first : info.best;
    c.read(downloadManagerProvider.notifier).enqueue(info, opt);
    return 'نقي: بدأ تحميل «${info.title}»';
  } catch (e) {
    return e is ExtractorException ? 'نقي: ${e.message}' : 'نقي: تعذّر تحليل الرابط';
  }
}
