import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/auto_download.dart';
import 'core/providers.dart';
import 'core/settings.dart';
import 'core/models.dart' show TaskState;
import 'core/vault.dart';
import 'ui/lock_screen.dart';
import 'ui/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [prefsProvider.overrideWithValue(prefs)],
    child: const NaqiApp(),
  ));
}

class NaqiApp extends ConsumerWidget {
  const NaqiApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);

    ThemeData theme(Brightness b) {
      var cs = ColorScheme.fromSeed(seedColor: Color(s.seed), brightness: b);
      if (b == Brightness.dark && s.amoled) cs = cs.copyWith(surface: Colors.black);
      final base = ThemeData(useMaterial3: true, colorScheme: cs, materialTapTargetSize: MaterialTapTargetSize.padded);
      // لون النص: تلقائي، أو لون يحدده المستخدم (يُطبَّق على الوضعين).
      final custom = s.textColor == 0 ? null : Color(s.textColor);
      final text = custom == null ? base.textTheme : base.textTheme.apply(bodyColor: custom, displayColor: custom);
      final onS = custom ?? cs.onSurface;
      final dark = b == Brightness.dark;
      final fill = (dark ? Colors.white : Colors.black).withOpacity(0.07);
      final rr = BorderRadius.circular(s.radius);
      return base.copyWith(
        textTheme: text,
        iconTheme: IconThemeData(color: onS),
        listTileTheme: ListTileThemeData(textColor: onS, iconColor: onS),
        chipTheme: base.chipTheme.copyWith(
          backgroundColor: fill,
          selectedColor: cs.primary.withOpacity(0.28),
          side: BorderSide(color: cs.primary.withOpacity(0.35)),
          shape: const StadiumBorder(),
          showCheckmark: false,
          labelStyle: TextStyle(color: onS, fontWeight: FontWeight.w600),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: fill,
          border: OutlineInputBorder(borderRadius: rr, borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: rr, borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(borderRadius: rr, borderSide: BorderSide(color: cs.primary, width: 1.5)),
        ),
        snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: rr)),
        segmentedButtonTheme: SegmentedButtonThemeData(
          style: ButtonStyle(
            shape: WidgetStatePropertyAll(RoundedRectangleBorder(borderRadius: rr)),
            backgroundColor: WidgetStateProperty.resolveWith((st) => st.contains(WidgetState.selected) ? cs.primary.withOpacity(0.28) : fill),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: rr))),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0, scrolledUnderElevation: 0),
      );
    }

    return MaterialApp(
      title: 'نقي Pro Plus',
      debugShowCheckedModeBanner: false,
      theme: theme(Brightness.light),
      darkTheme: theme(Brightness.dark),
      themeMode: s.themeMode,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (ctx, child) {
        final mq = MediaQuery.of(ctx);
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(mq.textScaler.scale(1.0) * s.textScale)),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const AppLockGate(child: Shell()),
    );
  }
}

/// يغطي التطبيق بشاشة القفل عند التشغيل والعودة من الخلفية (إن فُعّل القفل).
class AppLockGate extends ConsumerStatefulWidget {
  final Widget child;
  const AppLockGate({super.key, required this.child});
  @override
  ConsumerState<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends ConsumerState<AppLockGate> with WidgetsBindingObserver {
  bool _locked = false;
  DateTime? _pausedAt;

  bool get _enabled {
    final p = ref.read(prefsProvider);
    return ref.read(settingsProvider).appLock && PinStore.has(p);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _locked = _enabled;
    if (_locked) WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (s == AppLifecycleState.resumed && _enabled && !_locked) {
      // تجاهل التنقل القصير (منتقي ملفات، مشاركة…)
      if (_pausedAt != null && DateTime.now().difference(_pausedAt!).inSeconds > 20) {
        setState(() => _locked = true);
        _bio();
      }
    }
  }

  Future<void> _bio() async {
    if (!ref.read(settingsProvider).biometric) return;
    if (await Biometric.authenticate('افتح نقي Pro Plus') && mounted) setState(() => _locked = false);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      widget.child,
      if (_locked)
        Positioned.fill(
          child: AppLockScreen(
            onBiometric: ref.read(settingsProvider).biometric ? _bio : null,
            verify: (pin) async {
              if (await PinStore.verify(ref.read(prefsProvider), pin)) {
                if (mounted) setState(() => _locked = false);
                return null;
              }
              return 'الرمز غير صحيح';
            },
          ),
        ),
    ]);
  }
}

/// نقطة دخول المحرك الخفي: يعالج الروابط المنسوخة ويبدأ التنزيل دون واجهة.
@pragma('vm:entry-point')
Future<void> backgroundMain() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final c = ProviderContainer(overrides: [prefsProvider.overrideWithValue(prefs)]);
  const ch = MethodChannel('naqi/bg');
  c.read(downloadManagerProvider); // يبقى حيًّا حتى انتهاء التنزيل
  ch.setMethodCallHandler((call) async {
    if (call.method == 'link') {
      final msg = await autoDownloadLink(c, call.arguments as String);
      if (msg != null) await ch.invokeMethod('toast', msg);
    }
    return null;
  });
  Timer.periodic(const Duration(seconds: 8), (_) {
    final busy = c.read(downloadManagerProvider).any((t) =>
        t.state == TaskState.running || t.state == TaskState.queued || t.state == TaskState.paused);
    ch.invokeMethod(busy ? 'busy' : 'idle');
  });
  await ch.invokeMethod('ready');
}
