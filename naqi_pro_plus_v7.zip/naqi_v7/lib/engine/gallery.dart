import 'package:flutter/services.dart';
import 'package:gal/gal.dart';

const _c = MethodChannel('naqi/gallery');

/// يحفظ الملف في استوديو الهاتف (ألبوم Naqi) عبر MediaStore.
/// يرجع معرّف النسخة (uri) أو null عند الفشل. يدعم فيديو وصورة وصوت.
Future<String?> saveToGallery(String path, {bool image = false}) async {
  try {
    final r = await _c.invokeMethod<String>('save', {'path': path, 'album': 'Naqi'});
    if (r != null && r.isNotEmpty) return r;
  } catch (_) {}
  // احتياطي (مكتبة gal) للفيديو والصور فقط.
  try {
    final p = path.toLowerCase();
    final isImg = image || RegExp(r'\.(jpg|jpeg|png|webp|gif)$').hasMatch(p);
    final isVid = RegExp(r'\.(mp4|mkv|webm|mov|3gp)$').hasMatch(p);
    if (!isImg && !isVid) return null;
    if (!await Gal.hasAccess(toAlbum: true)) {
      if (!await Gal.requestAccess(toAlbum: true)) return null;
    }
    isImg ? await Gal.putImage(path, album: 'Naqi') : await Gal.putVideo(path, album: 'Naqi');
    return 'gal:'; // نجح الحفظ لكن بلا معرّف للحذف لاحقًا
  } catch (_) {
    return null;
  }
}

/// يحذف نسخة الاستوديو التي أنشأها التطبيق.
Future<bool> deleteFromGallery(String? uri) async {
  if (uri == null || uri.isEmpty || uri == 'gal:') return false;
  try {
    return (await _c.invokeMethod<bool>('delete', {'uri': uri})) ?? false;
  } catch (_) {
    return false;
  }
}

/// يعيد ملفًا إلى مجلده الأصلي في الاستوديو (relPath مثل DCIM/Camera).
Future<String?> restoreToGallery(String src, String name, {String? mime, String? relPath}) async {
  try {
    return await _c.invokeMethod<String>('restore', {'src': src, 'name': name, 'mime': mime, 'relPath': relPath});
  } catch (_) {
    return null;
  }
}
