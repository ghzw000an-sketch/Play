import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../engine/native_engine.dart';
import 'glass.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    final lib = ref.watch(libraryProvider);
    final total = lib.fold<int>(0, (a, i) => a + i.sizeBytes);
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    Widget section(String title, List<Widget> children) => Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Glass(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
                child: Text(title, style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              ),
              ...children,
            ]),
          ),
        );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('الإعدادات', style: tt.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        section('المظهر', [
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('تلقائي')),
                ButtonSegment(value: ThemeMode.light, label: Text('فاتح')),
                ButtonSegment(value: ThemeMode.dark, label: Text('داكن')),
              ],
              selected: {s.themeMode},
              onSelectionChanged: (v) => n.change(themeMode: v.first),
            ),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('وضع AMOLED الأسود'),
            subtitle: const Text('خلفية سوداء خالصة في الوضع الداكن'),
            value: s.amoled,
            onChanged: (v) => n.change(amoled: v),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
            child: Wrap(spacing: 12, runSpacing: 12, children: [
              for (final c in accentSeeds)
                GestureDetector(
                  onTap: () => n.change(seed: c),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Color(c),
                      shape: BoxShape.circle,
                      border: Border.all(color: s.seed == c ? cs.onSurface : Colors.transparent, width: 3),
                    ),
                    child: s.seed == c ? const Icon(Icons.check, color: Colors.white) : null,
                  ),
                ),
            ]),
          ),
        ]),
        section('التنزيل', [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text('عدد التنزيلات المتزامنة', style: tt.bodyLarge),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 1, label: Text('1')),
                ButtonSegment(value: 2, label: Text('2')),
                ButtonSegment(value: 3, label: Text('3')),
                ButtonSegment(value: 4, label: Text('4')),
                ButtonSegment(value: 5, label: Text('5')),
              ],
              selected: {s.maxParallel},
              onSelectionChanged: (v) => n.change(maxParallel: v.first),
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text('اتصالات لكل ملف (السرعة)', style: tt.bodyLarge),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text('الأعلى = أسرع غالبًا. يُطبَّق على التنزيلات الجديدة.', style: tt.bodySmall),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 4, label: Text('4')),
                ButtonSegment(value: 8, label: Text('8')),
                ButtonSegment(value: 16, label: Text('16')),
                ButtonSegment(value: 32, label: Text('32')),
              ],
              selected: {s.connections},
              onSelectionChanged: (v) => n.change(connections: v.first),
            ),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('إشعار التنزيل في الخلفية'),
            subtitle: const Text('يُبقي التنزيل يعمل عند مغادرة التطبيق'),
            value: s.notify,
            onChanged: (v) => n.change(notify: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('تنزيل تلقائي بأعلى جودة'),
            subtitle: const Text('يبدأ التنزيل فور تحليل الرابط دون اختيار'),
            value: s.bestQuality,
            onChanged: (v) => n.change(bestQuality: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('تفضيل الصوت في التنزيل التلقائي'),
            subtitle: const Text('ينزّل MP3 بدل الفيديو عند تفعيل "أعلى جودة"'),
            value: s.preferAudio,
            onChanged: (v) => n.change(preferAudio: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('تحليل الروابط المنسوخة تلقائيًا'),
            subtitle: const Text('عند فتح التطبيق وفي الحافظة رابط مدعوم'),
            value: s.autoAnalyze,
            onChanged: (v) => n.change(autoAnalyze: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('حفظ تلقائي في الاستوديو'),
            subtitle: const Text('ينسخ كل فيديو مكتمل إلى ألبوم Naqi'),
            value: s.autoGallery,
            onChanged: (v) => n.change(autoGallery: v),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('الاهتزاز عند اللمس'),
            value: s.haptics,
            onChanged: (v) => n.change(haptics: v),
          ),
        ]),
        section('محرك التنزيل (yt-dlp)', [
          const _EngineTile(),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: const Text('تحديث المحرك تلقائيًا'),
            subtitle: const Text('مرة كل يوم عند فتح التطبيق، لأن المنصات تتغيّر باستمرار'),
            value: s.autoUpdateEngine,
            onChanged: (v) => n.change(autoUpdateEngine: v),
          ),
        ]),
        section('التخزين', [
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: const Icon(Icons.storage_rounded),
            title: Text('${lib.length} ملف • ${fmtBytes(total)}'),
            subtitle: const Text('داخل مجلد التطبيق (Naqi)'),
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: Icon(Icons.delete_sweep_outlined, color: cs.error),
            title: Text('حذف كل الملفات المحمّلة', style: TextStyle(color: cs.error)),
            enabled: lib.isNotEmpty,
            onTap: () async {
              final yes = await confirmSheet(context,
                  title: 'حذف الكل',
                  message: 'سيتم حذف جميع الملفات المحمّلة من الجهاز نهائيًا.',
                  action: 'حذف الكل');
              if (yes) await ref.read(libraryProvider.notifier).clearAll();
            },
          ),
        ]),
        section('حول التطبيق', [
          const ListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 4),
            leading: Icon(Icons.info_outline),
            title: Text('نقي Pro Plus'),
            subtitle: Text('الإصدار 0.3.0'),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              'المنصات المدعومة: يوتيوب، تيك توك، إنستغرام، فيسبوك ومئات المواقع الأخرى عبر yt-dlp (الروابط العامة فقط). '
              'إذا توقفت منصة عن العمل فحدّث المحرك من الإعدادات. '
              'يُمنع استخدام التطبيق لانتهاك حقوق النشر أو خصوصية الآخرين.',
              style: tt.bodySmall,
            ),
          ),
        ]),
      ],
    );
  }
}

class _EngineTile extends StatefulWidget {
  const _EngineTile();
  @override
  State<_EngineTile> createState() => _EngineTileState();
}

class _EngineTileState extends State<_EngineTile> {
  String _status = 'جارٍ الفحص…';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    if (!await NativeEngine.available) {
      if (mounted) setState(() => _status = 'غير متوفر في هذه النسخة (يعمل الوضع الاحتياطي)');
      return;
    }
    final (ready, err) = await NativeEngine.status();
    final v = ready ? await NativeEngine.version() : null;
    if (!mounted) return;
    setState(() => _status = err != null
        ? 'خطأ في التهيئة: $err'
        : ready
            ? 'جاهز${v != null ? ' • yt-dlp $v' : ''}'
            : 'قيد التهيئة… (أول تشغيل قد يستغرق دقيقة)');
  }

  Future<void> _update() async {
    setState(() {
      _busy = true;
      _status = 'جارٍ التحديث…';
    });
    try {
      await NativeEngine.update();
    } catch (e) {
      if (mounted) setState(() => _status = 'تعذّر التحديث: $e');
      if (mounted) setState(() => _busy = false);
      return;
    }
    if (mounted) setState(() => _busy = false);
    await _refresh();
  }

  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 4),
        leading: const Icon(Icons.memory_rounded),
        title: Text(_status),
        subtitle: const Text('يدعم تيك توك وإنستغرام وفيسبوك بالنسخة الأصلية بلا علامة مائية'),
        trailing: _busy
            ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
            : IconButton(tooltip: 'تحديث المحرك', icon: const Icon(Icons.system_update_alt_rounded), onPressed: _update),
      );
}
