import 'dart:ui';
import 'package:flutter/material.dart';

/// Lightweight "liquid glass": backdrop blur + translucent gradient + hairline border.
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const Glass({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.radius = 24});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(dark ? 0.12 : 0.55),
                Colors.white.withOpacity(dark ? 0.04 : 0.25),
              ],
            ),
            border: Border.all(color: Colors.white.withOpacity(dark ? 0.18 : 0.6), width: 1),
          ),
          child: child,
        ),
      ),
    );
  }
}

/// خلفية التطبيق: تدرّج لوني، أو أسود خالص عند تفعيل AMOLED.
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final black = cs.surface == Colors.black;
    return Container(
      decoration: BoxDecoration(
        color: black ? Colors.black : null,
        gradient: black
            ? null
            : LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [cs.primaryContainer, cs.surface, cs.tertiaryContainer.withOpacity(0.5)],
              ),
      ),
      child: child,
    );
  }
}

/// كل النوافذ في التطبيق تُفتح من الأسفل.
Future<T?> showGlassSheet<T>(BuildContext context, WidgetBuilder builder) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      final cs = Theme.of(ctx).colorScheme;
      return Padding(
        padding: EdgeInsets.fromLTRB(10, 0, 10, 10 + MediaQuery.of(ctx).viewInsets.bottom),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(
              color: cs.surfaceContainerHigh.withOpacity(0.94),
              child: SafeArea(
                top: false,
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.85),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      margin: const EdgeInsets.only(top: 10, bottom: 6),
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(color: cs.onSurface.withOpacity(0.25), borderRadius: BorderRadius.circular(2)),
                    ),
                    Flexible(child: builder(ctx)),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

/// نافذة تأكيد سفلية. ترجع true عند التأكيد.
Future<bool> confirmSheet(BuildContext context, {required String message, required String action, String? title}) async {
  final r = await showGlassSheet<bool>(
    context,
    (ctx) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (title != null) Text(title, style: Theme.of(ctx).textTheme.titleLarge, textAlign: TextAlign.center),
        if (title != null) const SizedBox(height: 8),
        Text(message, style: Theme.of(ctx).textTheme.bodyLarge, textAlign: TextAlign.center),
        const SizedBox(height: 20),
        SizedBox(
          height: 48,
          child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Theme.of(ctx).colorScheme.error),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(action),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(height: 48, child: TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء'))),
      ]),
    ),
  );
  return r ?? false;
}

/// نافذة إدخال نص سفلية.
Future<String?> inputSheet(BuildContext context, {required String title, String initial = '', String action = 'حفظ'}) {
  final ctrl = TextEditingController(text: initial);
  return showGlassSheet<String>(
    context,
    (ctx) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(title, style: Theme.of(ctx).textTheme.titleMedium),
        const SizedBox(height: 12),
        TextField(controller: ctrl, autofocus: true, textInputAction: TextInputAction.done, onSubmitted: (v) => Navigator.pop(ctx, v)),
        const SizedBox(height: 16),
        SizedBox(height: 48, child: FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: Text(action))),
      ]),
    ),
  );
}
