import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import '../engine/native_engine.dart';
import 'downloads_page.dart';
import 'glass.dart';
import 'home_page.dart';
import 'library_page.dart';
import 'settings_page.dart';

class Shell extends ConsumerStatefulWidget {
  const Shell({super.key});
  @override
  ConsumerState<Shell> createState() => _ShellState();
}

class _ShellState extends ConsumerState<Shell> {
  @override
  void initState() {
    super.initState();
    // روابط تصل من "مشاركة" في أي تطبيق آخر.
    ShareIn.start((url) {
      if (!mounted) return;
      ref.read(tabProvider.notifier).state = 0;
      ref.read(incomingLinkProvider.notifier).state = url;
    });
    _maybeUpdateEngine();
  }

  /// تحديث yt-dlp مرة كل 24 ساعة (المنصات تغيّر نفسها باستمرار).
  Future<void> _maybeUpdateEngine() async {
    if (!ref.read(settingsProvider).autoUpdateEngine) return;
    final prefs = ref.read(prefsProvider);
    final last = prefs.getInt('engineUpdatedAt') ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - last < 24 * 3600 * 1000) return;
    if (!await NativeEngine.available) return;
    try {
      await NativeEngine.update();
      await prefs.setInt('engineUpdatedAt', now);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final index = ref.watch(tabProvider);
    final active = ref
        .watch(downloadManagerProvider)
        .where((t) => t.state == TaskState.running || t.state == TaskState.queued || t.state == TaskState.paused)
        .length;

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: index,
            children: const [HomePage(), DownloadsPage(), LibraryPage(), SettingsPage()],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => ref.read(tabProvider.notifier).state = i,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.search_rounded), label: 'بحث وتنزيل'),
          NavigationDestination(
            icon: Badge(isLabelVisible: active > 0, label: Text('$active'), child: const Icon(Icons.downloading_rounded)),
            label: 'الجارية',
          ),
          const NavigationDestination(icon: Icon(Icons.video_library_rounded), label: 'المكتبة'),
          const NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
