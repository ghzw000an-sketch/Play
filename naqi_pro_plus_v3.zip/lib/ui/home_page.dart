import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../core/settings.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart' as yt;
import '../engine/extractor_base.dart';
import 'glass.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> with WidgetsBindingObserver {
  final _ctrl = TextEditingController();
  final _bctrl = TextEditingController();
  String? _clipUrl;
  String? _lastHandled;
  bool _batchMode = false;
  bool _batchRunning = false;
  final Map<String, String> _batchStatus = {};
  final _yte = yt.YoutubeExplode();
  List<yt.Video>? _results;
  bool _searching = false;
  String? _searchErr;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkClipboard();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ctrl.dispose();
    _bctrl.dispose();
    _yte.close();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _checkClipboard();
  }

  Future<void> _checkClipboard() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim();
    if (t == null || !t.startsWith('http') || detectSite(t) == Site.unknown) return;
    if (t == _lastHandled || t == _ctrl.text) return;
    _lastHandled = t;
    if (!mounted || _batchMode) return;
    if (ref.read(settingsProvider).autoAnalyze) {
      _usePasted(t);
    } else {
      setState(() => _clipUrl = t);
    }
  }

  void _usePasted(String url) {
    haptic(ref);
    _ctrl.text = url;
    setState(() {
      _clipUrl = null;
      _results = null;
      _searchErr = null;
    });
    ref.read(analysisProvider.notifier).analyze(url);
  }

  /// رابط → تحليل مباشر، أي نص آخر → بحث في يوتيوب.
  void _submit(String raw) {
    final v = raw.trim();
    if (v.isEmpty) return;
    FocusScope.of(context).unfocus();
    if (v.startsWith('http')) {
      _usePasted(v);
    } else {
      _search(v);
    }
  }

  Future<void> _search(String q) async {
    haptic(ref);
    setState(() {
      _searching = true;
      _results = null;
      _searchErr = null;
    });
    ref.read(analysisProvider.notifier).clear();
    try {
      final r = await _yte.search.search(q);
      if (!mounted) return;
      setState(() => _results = r.take(20).toList());
    } catch (_) {
      if (mounted) setState(() => _searchErr = 'تعذّر البحث. تحقق من الإنترنت.');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim();
    if (t == null || t.isEmpty) return;
    if (_batchMode) {
      _bctrl.text = _bctrl.text.isEmpty ? t : '${_bctrl.text}\n$t';
    } else {
      _usePasted(t);
    }
  }

  void _enqueue(MediaInfo info, MediaOption opt) {
    haptic(ref, strong: true);
    ref.read(downloadManagerProvider.notifier).enqueue(info, opt);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: const Text('أُضيف إلى قائمة التنزيل'),
        action: SnackBarAction(label: 'عرض', onPressed: () => ref.read(tabProvider.notifier).state = 1),
      ));
  }

  Future<void> _runBatch() async {
    final urls = _bctrl.text
        .split(RegExp(r'\s+'))
        .where((u) => u.startsWith('http'))
        .toSet()
        .toList();
    if (urls.isEmpty) return;
    setState(() {
      _batchRunning = true;
      _batchStatus
        ..clear()
        ..addEntries(urls.map((u) => MapEntry(u, 'بالانتظار')));
    });
    for (final u in urls) {
      if (!mounted) return;
      setState(() => _batchStatus[u] = 'جارٍ التحليل…');
      try {
        final info = await ref.read(extractorProvider).analyze(u);
        ref.read(downloadManagerProvider.notifier).enqueue(info, info.best);
        if (mounted) setState(() => _batchStatus[u] = '✓ أُضيف: ${info.title}');
      } catch (e) {
        if (mounted) setState(() => _batchStatus[u] = '✗ ${e is ExtractorException ? e.message : 'تعذّر التحليل'}');
      }
    }
    if (mounted) {
      setState(() => _batchRunning = false);
      haptic(ref, strong: true);
    }
  }

  List<Widget> _resultTiles() {
    if (_results!.isEmpty) return [const Glass(child: Text('لا توجد نتائج'))];
    return [
      for (final v in _results!)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Glass(
            padding: const EdgeInsets.all(8),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => _usePasted(v.url),
              child: Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(v.thumbnails.mediumResUrl, width: 112, height: 64, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const SizedBox(width: 112, height: 64)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleSmall),
                    Text([v.author, fmtDuration(v.duration)].where((e) => e.isNotEmpty).join(' • '),
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                  ]),
                ),
              ]),
            ),
          ),
        ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<String?>(incomingLinkProvider, (prev, next) {
      if (next != null) {
        _usePasted(next);
        ref.read(incomingLinkProvider.notifier).state = null;
      }
    });
    final analysis = ref.watch(analysisProvider);
    final cs = Theme.of(context).colorScheme;

    ref.listen<AsyncValue<MediaInfo?>>(analysisProvider, (prev, next) {
      final info = next.valueOrNull;
      if (info != null && prev?.valueOrNull != info && ref.read(settingsProvider).bestQuality) {
        final audio = info.options.where((o) => o.audioOnly).toList();
        _enqueue(info, (ref.read(settingsProvider).preferAudio && audio.isNotEmpty) ? audio.first : info.best);
      }
    });

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SizedBox(height: 8),
        Text('نقي Pro Plus',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        Text('حمّل بنقاء… وبجودة احترافية', style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 12),
        const Wrap(spacing: 8, runSpacing: 8, children: [
          _SiteChip('YouTube', Icons.smart_display_rounded),
          _SiteChip('TikTok', Icons.music_note_rounded),
          _SiteChip('Instagram', Icons.camera_alt_rounded),
          _SiteChip('Facebook', Icons.facebook_rounded),
        ]),
        const SizedBox(height: 16),
        SegmentedButton<bool>(
          segments: const [
            ButtonSegment(value: false, label: Text('رابط واحد'), icon: Icon(Icons.link)),
            ButtonSegment(value: true, label: Text('دفعة روابط'), icon: Icon(Icons.playlist_add)),
          ],
          selected: {_batchMode},
          onSelectionChanged: (s) => setState(() => _batchMode = s.first),
        ),
        const SizedBox(height: 12),
        if (!_batchMode) ...[
          Glass(
            child: Column(children: [
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    keyboardType: TextInputType.url,
                    textInputAction: TextInputAction.go,
                    onSubmitted: _submit,
                    decoration: const InputDecoration(
                      hintText: 'الصق رابطًا أو ابحث في يوتيوب',
                      border: InputBorder.none,
                      prefixIcon: Icon(Icons.link),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'لصق من الحافظة',
                  constraints: const BoxConstraints(minWidth: 48, minHeight: 48),
                  icon: const Icon(Icons.content_paste_rounded),
                  onPressed: _paste,
                ),
              ]),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton.icon(
                  onPressed: () => _submit(_ctrl.text),
                  icon: const Icon(Icons.search),
                  label: const Text('تحليل / بحث'),
                ),
              ),
            ]),
          ),
          if (_clipUrl != null) ...[
            const SizedBox(height: 12),
            Glass(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(children: [
                Expanded(child: Text('رابط ${siteName(detectSite(_clipUrl!))} منسوخ — لصقه؟')),
                TextButton(onPressed: () => _usePasted(_clipUrl!), child: const Text('لصق')),
                IconButton(onPressed: () => setState(() => _clipUrl = null), icon: const Icon(Icons.close)),
              ]),
            ),
          ],
          const SizedBox(height: 16),
          if (_searching) const _Skeleton(),
          if (_searchErr != null) Glass(child: Text(_searchErr!)),
          if (_results != null) ..._resultTiles(),
          analysis.when(
            loading: () => const _Skeleton(),
            error: (e, _) => Glass(
              child: Row(children: [
                Icon(Icons.info_outline, color: cs.error),
                const SizedBox(width: 12),
                Expanded(child: Text('$e')),
              ]),
            ),
            data: (info) => info == null ? const SizedBox.shrink() : _InfoCard(info: info, onPick: _enqueue),
          ),
        ] else ...[
          Glass(
            child: Column(children: [
              TextField(
                controller: _bctrl,
                minLines: 4,
                maxLines: 8,
                keyboardType: TextInputType.multiline,
                decoration: const InputDecoration(
                  hintText: 'ألصق كل رابط في سطر مستقل',
                  border: InputBorder.none,
                ),
              ),
              Row(children: [
                IconButton(
                  tooltip: 'لصق من الحافظة',
                  icon: const Icon(Icons.content_paste_rounded),
                  onPressed: _paste,
                ),
                const Spacer(),
                FilledButton.icon(
                  onPressed: _batchRunning ? null : _runBatch,
                  icon: _batchRunning
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download_rounded),
                  label: const Text('تحميل الكل بأعلى جودة'),
                ),
              ]),
            ]),
          ),
          if (_batchStatus.isNotEmpty) ...[
            const SizedBox(height: 12),
            Glass(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final e in _batchStatus.entries)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(e.key, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                        Text(e.value, maxLines: 2, overflow: TextOverflow.ellipsis),
                      ]),
                    ),
                ],
              ),
            ),
          ],
        ],
        const SizedBox(height: 24),
        Text(
          'يحمّل التطبيق الملفات المتاحة للعامة والمسموح بها فقط، ولا يتجاوز الحماية أو المحتوى الخاص. '
          'أنت المسؤول عن احترام حقوق النشر وشروط المنصات.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}

class _SiteChip extends StatelessWidget {
  final String name;
  final IconData icon;
  const _SiteChip(this.name, this.icon);
  @override
  Widget build(BuildContext context) => Chip(avatar: Icon(icon, size: 18), label: Text(name));
}

class _Skeleton extends StatefulWidget {
  const _Skeleton();
  @override
  State<_Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<_Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context).colorScheme.onSurface;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        Widget bar(double w, double h) => Container(
            width: w,
            height: h,
            decoration: BoxDecoration(
                color: base.withOpacity(0.06 + 0.08 * _c.value), borderRadius: BorderRadius.circular(8)));
        return Glass(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            bar(double.infinity, 160),
            const SizedBox(height: 12),
            bar(240, 16),
            const SizedBox(height: 8),
            bar(140, 12),
          ]),
        );
      },
    );
  }
}

class _InfoCard extends StatelessWidget {
  final MediaInfo info;
  final void Function(MediaInfo, MediaOption) onPick;
  const _InfoCard({required this.info, required this.onPick});

  @override
  Widget build(BuildContext context) {
    return Glass(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (info.thumbnail != null && info.thumbnail!.isNotEmpty)
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.network(info.thumbnail!,
                  fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Colors.black12)),
            ),
          ),
        const SizedBox(height: 12),
        Text(info.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 4),
        Text([siteName(info.site), if (info.author != null && info.author!.isNotEmpty) info.author!, fmtDuration(info.duration)]
            .where((s) => s.isNotEmpty)
            .join(' • ')),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          height: 48,
          child: FilledButton.icon(
            onPressed: () => onPick(info, info.best),
            icon: const Icon(Icons.bolt_rounded),
            label: Text('تنزيل بأعلى جودة (${info.best.label})'),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          height: 48,
          child: OutlinedButton.icon(
            onPressed: () => showGlassSheet(context, (ctx) => _OptionsSheet(info: info, onPick: (o) {
                  Navigator.pop(ctx);
                  onPick(info, o);
                })),
            icon: const Icon(Icons.tune_rounded),
            label: const Text('كل الجودات والصوت'),
          ),
        ),
      ]),
    );
  }
}

/// قائمة الجودات والصوت كنافذة سفلية.
class _OptionsSheet extends StatelessWidget {
  final MediaInfo info;
  final void Function(MediaOption) onPick;
  const _OptionsSheet({required this.info, required this.onPick});

  @override
  Widget build(BuildContext context) {
    final videos = info.options.where((o) => !o.audioOnly).toList();
    final audios = info.options.where((o) => o.audioOnly).toList();
    Widget tile(MediaOption o) => ListTile(
          minVerticalPadding: 12,
          leading: Icon(o.audioOnly ? Icons.music_note_rounded : Icons.videocam_rounded),
          title: Text(o.label),
          subtitle: Text('${o.container.toUpperCase()} • ${fmtBytes(o.sizeBytes)}'),
          trailing: const Icon(Icons.download_rounded),
          onTap: () => onPick(o),
        );
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      children: [
        Text(info.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleSmall),
        const Divider(height: 24),
        if (videos.isNotEmpty) Text('فيديو', style: Theme.of(context).textTheme.labelLarge),
        for (final o in videos) tile(o),
        if (audios.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('صوت فقط', style: Theme.of(context).textTheme.labelLarge),
          for (final o in audios) tile(o),
        ],
      ],
    );
  }
}
