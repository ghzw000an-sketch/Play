import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/providers.dart';
import 'glass.dart';
import 'player_page.dart';

class DownloadsPage extends ConsumerWidget {
  const DownloadsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasks = ref.watch(downloadManagerProvider);
    final m = ref.read(downloadManagerProvider.notifier);
    final hasFinished = tasks.any((t) => t.state == TaskState.done || t.state == TaskState.cancelled);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          Expanded(
            child: Text('التنزيلات الجارية',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          ),
          if (hasFinished) TextButton.icon(onPressed: m.clearFinished, icon: const Icon(Icons.clear_all), label: const Text('مسح المنتهية')),
        ]),
        const SizedBox(height: 12),
        if (tasks.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 80),
            child: Column(children: [
              Icon(Icons.cloud_download_outlined, size: 72, color: Theme.of(context).colorScheme.outline),
              const SizedBox(height: 12),
              const Text('لا توجد تنزيلات حاليًا'),
            ]),
          ),
        for (final t in tasks.reversed) _TaskTile(task: t),
      ],
    );
  }
}

class _TaskTile extends ConsumerWidget {
  final DownloadTask task;
  const _TaskTile({required this.task});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final m = ref.read(downloadManagerProvider.notifier);
    final s = task.state;
    final pct = task.progress;

    String sub;
    if (s == TaskState.failed) {
      sub = (task.error == null || task.error!.isEmpty) ? 'فشل التنزيل' : task.error!;
    } else if (s == TaskState.done) {
      sub = 'اكتمل • ${fmtBytes(task.received)} — الملف في المكتبة';
    } else {
      final extra = (s == TaskState.running && task.speed > 1)
          ? ' • ${fmtSpeed(task.speed)}${task.etaSec != null ? ' • متبقي ${fmtDuration(Duration(seconds: task.etaSec!))}' : ''}'
          : '';
      sub = '${stateAr(s)} • ${fmtBytes(task.received)} / ${fmtBytes(task.total)}$extra';
    }

    Widget lead;
    if (s == TaskState.done) {
      lead = const Icon(Icons.check_circle, color: Colors.green, size: 36);
    } else if (s == TaskState.failed || s == TaskState.cancelled) {
      lead = Icon(Icons.error_outline, color: Theme.of(context).colorScheme.error, size: 36);
    } else {
      lead = Stack(alignment: Alignment.center, children: [
        SizedBox(width: 44, height: 44, child: CircularProgressIndicator(value: pct, strokeWidth: 4)),
        if (pct != null) Text('${(pct * 100).round()}', style: Theme.of(context).textTheme.labelSmall),
      ]);
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Glass(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        child: Row(children: [
          SizedBox(width: 44, height: 44, child: Center(child: lead)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(task.info.title, maxLines: 1, overflow: TextOverflow.ellipsis),
              Text('${siteName(task.info.site)} • ${task.option.label}',
                  style: Theme.of(context).textTheme.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
              Text(sub, style: Theme.of(context).textTheme.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
            ]),
          ),
          if (s == TaskState.running) IconButton(tooltip: 'إيقاف مؤقت', onPressed: () => m.pause(task.id), icon: const Icon(Icons.pause)),
          if (s == TaskState.paused || s == TaskState.failed)
            IconButton(tooltip: 'استئناف', onPressed: () => m.resume(task.id), icon: const Icon(Icons.play_arrow)),
          if (s == TaskState.done)
            IconButton(
              tooltip: 'تشغيل',
              icon: const Icon(Icons.play_circle_fill_rounded),
              onPressed: () {
                final items = ref.read(libraryProvider).where((i) => i.id == task.id);
                if (items.isNotEmpty) {
                  Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerPage(item: items.first)));
                }
              },
            ),
          if (s == TaskState.queued || s == TaskState.running || s == TaskState.paused)
            IconButton(
              tooltip: 'إلغاء',
              onPressed: () async {
                final ok = await confirmSheet(context, message: 'إلغاء هذا التنزيل وحذف الملف الجزئي؟', action: 'إلغاء التنزيل');
                if (ok) m.cancel(task.id);
              },
              icon: const Icon(Icons.close),
            ),
          if (s == TaskState.done || s == TaskState.failed || s == TaskState.cancelled)
            IconButton(tooltip: 'إزالة من القائمة', onPressed: () => m.remove(task.id), icon: const Icon(Icons.delete_outline)),
        ]),
      ),
    );
  }
}
