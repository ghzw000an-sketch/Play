import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import '../core/models.dart';
import '../core/providers.dart';
import '../engine/gallery.dart';
import '../engine/native_engine.dart';
import 'glass.dart';
import 'player_page.dart';

enum _Sort { newest, oldest, largest, name }

class LibraryPage extends ConsumerStatefulWidget {
  const LibraryPage({super.key});
  @override
  ConsumerState<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends ConsumerState<LibraryPage> {
  String _q = '';
  int _filter = 0; // 0 الكل، 1 فيديو، 2 صوت، 3 مفضلة
  _Sort _sort = _Sort.newest;
  final Set<String> _sel = {};

  bool get _selecting => _sel.isNotEmpty;

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  Future<bool> _exists(LibraryItem i) async {
    if (await File(i.filePath).exists()) return true;
    _snack('الملف غير موجود (ربما حُذف من الجهاز)');
    return false;
  }

  Future<void> _play(LibraryItem i) async {
    if (!await _exists(i) || !mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerPage(item: i)));
  }

  Future<void> _share(List<LibraryItem> l) async {
    final ok = <XFile>[];
    for (final i in l) {
      if (await File(i.filePath).exists()) ok.add(XFile(i.filePath));
    }
    if (ok.isEmpty) {
      _snack('لا توجد ملفات صالحة للمشاركة');
      return;
    }
    await Share.shareXFiles(ok, text: l.length == 1 ? l.first.title : null);
  }

  Future<void> _gallery(LibraryItem i) async {
    if (!await _exists(i)) return;
    final ok = await saveToGallery(i.filePath, image: i.isImage);
    _snack(ok ? 'تم الحفظ في الاستوديو (ألبوم Naqi)' : 'تعذّر الحفظ في الاستوديو (تحقق من الصلاحيات أو الصيغة)');
  }

  Future<void> _delete(List<LibraryItem> l) async {
    final yes = await confirmSheet(context,
        title: 'حذف',
        message: l.length == 1 ? 'سيُحذف الملف نهائيًا من الجهاز.' : 'سيتم حذف ${l.length} ملفات نهائيًا من الجهاز.',
        action: 'حذف');
    if (!yes) return;
    await ref.read(libraryProvider.notifier).removeMany(l.map((e) => e.id));
    if (mounted) setState(() => _sel.removeAll(l.map((e) => e.id)));
    _snack('تم الحذف');
  }

  Future<void> _rename(LibraryItem i) async {
    final name = await inputSheet(context, title: 'إعادة تسمية', initial: i.title);
    if (name == null) return;
    final clean = name.replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), ' ').trim();
    if (clean.isEmpty) return;
    var newPath = i.filePath;
    try {
      final f = File(i.filePath);
      if (await f.exists()) {
        final dot = i.filePath.lastIndexOf('.');
        final slash = i.filePath.lastIndexOf('/');
        final ext = dot > slash ? i.filePath.substring(dot) : '';
        final target = '${i.filePath.substring(0, slash + 1)}$clean$ext';
        if (target != i.filePath && !await File(target).exists()) {
          await f.rename(target);
          newPath = target;
        }
      }
    } catch (_) {}
    ref.read(libraryProvider.notifier).update(i.copyWith(title: clean, filePath: newPath));
  }

  void _details(LibraryItem i) {
    showGlassSheet<void>(
      context,
      (ctx) => ListView(shrinkWrap: true, padding: const EdgeInsets.all(20), children: [
        Text('التفاصيل', style: Theme.of(ctx).textTheme.titleMedium),
        const SizedBox(height: 12),
        SelectableText([
          'العنوان: ${i.title}',
          'المنصة: ${i.site}',
          if (i.author != null && i.author!.isNotEmpty) 'الناشر: ${i.author}',
          'الجودة: ${i.label}',
          'الحجم: ${fmtBytes(i.sizeBytes)}',
          if (i.durationSec != null) 'المدة: ${fmtDuration(Duration(seconds: i.durationSec!))}',
          'التاريخ: ${fmtDate(i.createdAt)}',
          'المسار: ${i.filePath}',
          if (i.sourceUrl != null) 'الرابط: ${i.sourceUrl}',
        ].join('\n\n')),
      ]),
    );
  }

  /// يستخرج مسار الصوت من الفيديو إلى M4A (بدون إعادة ترميز) ويضيفه للمكتبة.
  Future<void> _toAudio(LibraryItem i) async {
    if (!await _exists(i)) return;
    _snack('جارٍ استخراج الصوت…');
    try {
      final dot = i.filePath.lastIndexOf('.');
      final slash = i.filePath.lastIndexOf('/');
      final stem = dot > slash ? i.filePath.substring(0, dot) : i.filePath;
      var out = '$stem.m4a';
      var n = 2;
      while (await File(out).exists()) {
        out = '$stem ($n).m4a';
        n++;
      }
      await MediaTools.extractAudio(i.filePath, out);
      final size = await File(out).length();
      ref.read(libraryProvider.notifier).add(LibraryItem(
            id: DateTime.now().microsecondsSinceEpoch.toString(),
            title: i.title,
            site: i.site,
            filePath: out,
            audioOnly: true,
            sizeBytes: size,
            label: 'M4A • من الفيديو',
            thumbPath: i.thumbPath,
            sourceUrl: i.sourceUrl,
            author: i.author,
            createdAt: DateTime.now(),
            durationSec: i.durationSec,
          ));
      _snack('تم إنشاء ملف صوتي (M4A) في المكتبة');
    } catch (_) {
      _snack('تعذّر استخراج الصوت (ربما الفيديو بلا مسار صوت أو بصيغة غير مدعومة)');
    }
  }

  void _more(LibraryItem i) {
    showGlassSheet<void>(context, (ctx) {
      Widget tile(IconData ic, String t, VoidCallback f) => ListTile(
            leading: Icon(ic),
            title: Text(t),
            onTap: () {
              Navigator.pop(ctx);
              f();
            },
          );
      return ListView(shrinkWrap: true, padding: const EdgeInsets.only(bottom: 12), children: [
        tile(Icons.play_circle_outline, 'تشغيل', () => _play(i)),
        tile(Icons.share_outlined, 'مشاركة', () => _share([i])),
        if (!i.audioOnly && !i.isImage) tile(Icons.music_note_rounded, 'تحويل إلى صوت (M4A)', () => _toAudio(i)),
        if (!i.audioOnly) tile(Icons.photo_library_outlined, 'حفظ في الاستوديو', () => _gallery(i)),
        tile(i.favorite ? Icons.star : Icons.star_border, i.favorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة',
            () => ref.read(libraryProvider.notifier).update(i.copyWith(favorite: !i.favorite))),
        tile(Icons.drive_file_rename_outline, 'إعادة تسمية', () => _rename(i)),
        if (i.sourceUrl != null)
          tile(Icons.link, 'نسخ الرابط الأصلي', () {
            Clipboard.setData(ClipboardData(text: i.sourceUrl!));
            _snack('تم نسخ الرابط');
          }),
        tile(Icons.info_outline, 'التفاصيل', () => _details(i)),
        tile(Icons.delete_outline, 'حذف', () => _delete([i])),
      ]);
    });
  }

  @override
  Widget build(BuildContext context) {
    final all = ref.watch(libraryProvider);
    final cs = Theme.of(context).colorScheme;

    final items = all.where((i) {
      if (_q.isNotEmpty && !i.title.toLowerCase().contains(_q.toLowerCase())) return false;
      return switch (_filter) {
        1 => !i.audioOnly && !i.isImage,
        2 => i.audioOnly,
        3 => i.favorite,
        _ => true,
      };
    }).toList();
    items.sort((a, b) => switch (_sort) {
          _Sort.newest => b.createdAt.compareTo(a.createdAt),
          _Sort.oldest => a.createdAt.compareTo(b.createdAt),
          _Sort.largest => b.sizeBytes.compareTo(a.sizeBytes),
          _Sort.name => a.title.toLowerCase().compareTo(b.title.toLowerCase()),
        });
    final total = all.fold<int>(0, (s, i) => s + i.sizeBytes);
    final selected = all.where((i) => _sel.contains(i.id)).toList();

    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: _selecting
            ? Row(children: [
                IconButton(onPressed: () => setState(_sel.clear), icon: const Icon(Icons.close)),
                Expanded(child: Text('${_sel.length} محدد', style: Theme.of(context).textTheme.titleMedium)),
                IconButton(
                  tooltip: 'تحديد الكل',
                  onPressed: () => setState(() => _sel.addAll(items.map((e) => e.id))),
                  icon: const Icon(Icons.select_all),
                ),
                IconButton(tooltip: 'مشاركة', onPressed: () => _share(selected), icon: const Icon(Icons.share_outlined)),
                IconButton(tooltip: 'حذف', onPressed: () => _delete(selected), icon: const Icon(Icons.delete_outline)),
              ])
            : Row(children: [
                Expanded(
                  child: TextField(
                    onChanged: (v) => setState(() => _q = v),
                    decoration: InputDecoration(
                      hintText: 'ابحث في المكتبة',
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: cs.surface.withOpacity(0.5),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                      isDense: true,
                    ),
                  ),
                ),
                PopupMenuButton<_Sort>(
                  tooltip: 'ترتيب',
                  icon: const Icon(Icons.sort_rounded),
                  initialValue: _sort,
                  onSelected: (s) => setState(() => _sort = s),
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: _Sort.newest, child: Text('الأحدث')),
                    PopupMenuItem(value: _Sort.oldest, child: Text('الأقدم')),
                    PopupMenuItem(value: _Sort.largest, child: Text('الأكبر حجمًا')),
                    PopupMenuItem(value: _Sort.name, child: Text('الاسم')),
                  ],
                ),
              ]),
      ),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          for (final e in const [(0, 'الكل'), (1, 'فيديو'), (2, 'صوت'), (3, '⭐ المفضلة')])
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: ChoiceChip(label: Text(e.$2), selected: _filter == e.$1, onSelected: (_) => setState(() => _filter = e.$1)),
            ),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
        child: Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text('${all.length} عنصر • ${fmtBytes(total)}', style: Theme.of(context).textTheme.bodySmall),
        ),
      ),
      Expanded(
        child: items.isEmpty
            ? Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.video_library_outlined, size: 72, color: cs.outline),
                  const SizedBox(height: 12),
                  Text(all.isEmpty ? 'مكتبتك فارغة — ابدأ بتنزيل أول ملف' : 'لا توجد نتائج'),
                ]),
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                itemCount: items.length,
                itemBuilder: (_, k) => _card(items[k]),
              ),
      ),
    ]);
  }

  Widget _card(LibraryItem i) {
    final isSel = _sel.contains(i.id);
    final cs = Theme.of(context).colorScheme;

    Widget thumb;
    if (i.thumbPath != null && File(i.thumbPath!).existsSync()) {
      thumb = Image.file(File(i.thumbPath!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.movie_rounded));
    } else {
      thumb = Icon(i.audioOnly ? Icons.music_note_rounded : Icons.movie_rounded, size: 32, color: cs.outline);
    }

    void toggle() => setState(() => isSel ? _sel.remove(i.id) : _sel.add(i.id));

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Glass(
        padding: const EdgeInsets.all(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: _selecting ? toggle : () => _play(i),
          onLongPress: toggle,
          child: Column(children: [
            Row(children: [
              Stack(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox(width: 84, height: 84, child: ColoredBox(color: cs.surfaceContainerHighest, child: Center(child: thumb))),
                ),
                if (isSel)
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(color: cs.primary.withOpacity(0.55), borderRadius: BorderRadius.circular(14)),
                      child: const Icon(Icons.check_circle, color: Colors.white),
                    ),
                  ),
              ]),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(i.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 4),
                  Text('${i.site} • ${i.label}', maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                  Text('${fmtBytes(i.sizeBytes)} • ${fmtDate(i.createdAt)}', style: Theme.of(context).textTheme.bodySmall),
                ]),
              ),
              if (i.favorite) const Icon(Icons.star, color: Colors.amber, size: 20),
            ]),
            if (!_selecting)
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                IconButton(tooltip: 'تشغيل', onPressed: () => _play(i), icon: const Icon(Icons.play_arrow_rounded)),
                IconButton(tooltip: 'مشاركة', onPressed: () => _share([i]), icon: const Icon(Icons.share_outlined)),
                if (!i.audioOnly && !i.isImage)
                  IconButton(tooltip: 'تحويل إلى صوت', onPressed: () => _toAudio(i), icon: const Icon(Icons.music_note_rounded)),
                if (!i.audioOnly)
                  IconButton(tooltip: 'حفظ في الاستوديو', onPressed: () => _gallery(i), icon: const Icon(Icons.photo_library_outlined)),
                IconButton(tooltip: 'حذف', onPressed: () => _delete([i]), icon: const Icon(Icons.delete_outline)),
                IconButton(tooltip: 'المزيد', onPressed: () => _more(i), icon: const Icon(Icons.more_horiz)),
              ]),
          ]),
        ),
      ),
    );
  }
}
