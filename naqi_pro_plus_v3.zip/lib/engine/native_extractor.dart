import '../core/models.dart';
import 'extractor_base.dart';
import 'native_engine.dart';

/// رسالة عربية مفهومة من خطأ yt-dlp.
String friendlyEngineError(String raw) {
  final m = raw.toLowerCase();
  if (m.contains('login') || m.contains('log in') || m.contains('sign in') || m.contains('cookies') || m.contains('rate-limit') || m.contains('rate limit')) {
    return 'المنصة تطلب تسجيل الدخول لهذا المحتوى أو حدّت الطلبات مؤقتًا. جرّب رابطًا عامًا آخر أو أعد المحاولة بعد قليل.';
  }
  if (m.contains('private') || m.contains('not available') || m.contains('unavailable') || m.contains('removed') || m.contains('deleted')) {
    return 'المحتوى خاص أو محذوف أو غير متاح في منطقتك.';
  }
  if (m.contains('unsupported url')) return 'هذا الرابط غير مدعوم.';
  if (m.contains('requested format is not available') || m.contains('no video formats')) {
    return 'لا تتوفر نسخة مناسبة (أو لا توجد نسخة بدون علامة مائية) لهذا الرابط.';
  }
  if (m.contains('timed out') || m.contains('timeout') || m.contains('unable to download') || m.contains('network') || m.contains('connection')) {
    return 'تعذّر الاتصال بالمنصة. تحقق من الإنترنت وأعد المحاولة.';
  }
  if (m.contains('http error 403') || m.contains('http error 410')) return 'انتهت صلاحية الرابط، حلّله من جديد.';
  return 'تعذّر التنزيل: ${raw.length > 160 ? raw.substring(0, 160) : raw}';
}

const _noWatermark = '[format_note!*=?watermarked]';

int? _int(Object? v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}');

/// يحوّل JSON الخاص بـ yt-dlp إلى MediaInfo مع خيارات الجودة والصوت.
MediaInfo mediaInfoFromYtdlp(Map<String, dynamic> j, String url) {
  final formats = [
    for (final f in (j['formats'] as List? ?? const [])) if (f is Map) Map<String, dynamic>.from(f)
  ];
  bool isVideo(Map<String, dynamic> f) {
    final v = f['vcodec'];
    return v != null && v != 'none' && f['ext'] != 'mhtml';
  }

  bool isAudioOnly(Map<String, dynamic> f) {
    final v = f['vcodec'];
    final a = f['acodec'];
    return (v == null || v == 'none') && a != null && a != 'none';
  }

  int? sizeOf(Map<String, dynamic> f) => _int(f['filesize']) ?? _int(f['filesize_approx']);
  num tbrOf(Map<String, dynamic> f) => (f['tbr'] is num ? f['tbr'] as num : 0);

  final vids = formats.where(isVideo).toList();
  final auds = formats.where(isAudioOnly).toList()..sort((a, b) => tbrOf(b).compareTo(tbrOf(a)));
  final bestAudioSize = auds.isEmpty ? null : sizeOf(auds.first);

  final heights = <int>{
    for (final f in vids) if ((_int(f['height']) ?? 0) > 0) _int(f['height'])!
  }.toList()
    ..sort((a, b) => b.compareTo(a));

  final opts = <MediaOption>[];
  if (heights.isEmpty) {
    if (vids.isNotEmpty || formats.isEmpty) {
      opts.add(MediaOption(
        id: 'nbest',
        label: 'أفضل جودة',
        audioOnly: false,
        container: 'mp4',
        url: url,
        sizeBytes: vids.isEmpty ? null : sizeOf(vids.reduce((a, b) => tbrOf(a) >= tbrOf(b) ? a : b)),
        nativeSel: 'bv*$_noWatermark+ba/b$_noWatermark',
      ));
    }
  } else {
    for (final h in heights) {
      final at = vids.where((f) => _int(f['height']) == h).toList()..sort((a, b) => tbrOf(b).compareTo(tbrOf(a)));
      final top = at.first;
      var size = sizeOf(top);
      if (size != null && top['acodec'] == 'none' && bestAudioSize != null) size += bestAudioSize;
      opts.add(MediaOption(
        id: 'n$h',
        label: '${h}p',
        audioOnly: false,
        container: 'mp4',
        url: url,
        sizeBytes: size,
        nativeSel: 'bv*[height<=$h]$_noWatermark+ba/b[height<=$h]$_noWatermark',
      ));
    }
  }

  // صوت فقط (يُحوَّل بـ FFmpeg المضمّن)
  opts.add(MediaOption(
    id: 'amp3',
    label: 'MP3 • أفضل جودة',
    audioOnly: true,
    container: 'mp3',
    url: url,
    sizeBytes: bestAudioSize,
    nativeSel: 'ba/b',
    audioFmt: 'mp3',
  ));
  opts.add(MediaOption(
    id: 'am4a',
    label: 'M4A • AAC',
    audioOnly: true,
    container: 'm4a',
    url: url,
    sizeBytes: bestAudioSize,
    nativeSel: 'ba[ext=m4a]/ba/b',
    audioFmt: 'm4a',
  ));

  final title = ('${j['title'] ?? j['fulltitle'] ?? ''}').trim();
  final dur = j['duration'];
  return MediaInfo(
    sourceUrl: url,
    site: detectSite(url),
    title: title.isEmpty ? 'naqi' : (title.length > 120 ? title.substring(0, 120) : title),
    author: (j['uploader'] ?? j['channel'] ?? j['creator'])?.toString(),
    thumbnail: j['thumbnail']?.toString(),
    duration: dur is num ? Duration(seconds: dur.round()) : null,
    options: opts,
  );
}

/// المستخرج الرئيسي: محرك yt-dlp (يدعم مئات المواقع، ويختار النسخة الأصلية بلا علامة مائية).
class NativeExtractor implements Extractor {
  @override
  bool supports(Site s) => true;

  @override
  Future<MediaInfo> analyze(String url) async {
    try {
      final j = await NativeEngine.analyze(url);
      return mediaInfoFromYtdlp(j, url);
    } on EngineException catch (e) {
      throw ExtractorException(friendlyEngineError(e.message));
    }
  }
}
